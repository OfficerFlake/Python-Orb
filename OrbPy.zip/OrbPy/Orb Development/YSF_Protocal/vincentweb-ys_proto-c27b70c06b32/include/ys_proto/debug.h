#ifndef DEBUG
#define DEBUG



void debugHex(const char* buffer, int end);
void debugDec(const char* buffer, unsigned int end);
void debugChar(const char* buffer, unsigned int end);

#endif
