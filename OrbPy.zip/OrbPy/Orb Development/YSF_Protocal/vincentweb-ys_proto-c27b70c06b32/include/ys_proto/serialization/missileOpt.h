#ifndef MISSILEOPT
#define MISSILEOPT

#include "ys_proto/types/ys/tmissileOpt.h"

#endif
