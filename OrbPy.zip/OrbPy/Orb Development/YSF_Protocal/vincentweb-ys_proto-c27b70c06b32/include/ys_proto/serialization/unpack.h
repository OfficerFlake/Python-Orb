#ifndef UNPACK
#define UNPACK


int unpack_int(char* buffer, int pos);

short unpack_short(char* buffer, int pos);

void display_unpack(char* format, char* buffer);

#endif
