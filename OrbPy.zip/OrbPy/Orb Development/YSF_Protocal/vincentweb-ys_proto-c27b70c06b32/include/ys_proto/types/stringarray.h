#ifndef STRINGARRAY
#define STRINGARRAY


#include <stdio.h>


int sizeofsarray(char* array, int elements);
void printsarray(char* array, int elements);

#endif

