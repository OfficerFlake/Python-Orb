
struct tairList
{
    char  u1;
    char  nbOfAircraft; // ou short + char
    short u2;
    char* aircraft;
};
