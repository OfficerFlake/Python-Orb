struct tlogin
{
    char username[16];
    int  YSversion;
};
