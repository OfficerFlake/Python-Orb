struct tmap
{
	char map[60];
};
