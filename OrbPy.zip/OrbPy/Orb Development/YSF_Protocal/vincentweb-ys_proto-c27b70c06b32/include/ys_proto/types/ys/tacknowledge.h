#ifndef TACKNOWLEDGE
#define TACKNOWLEDGE

struct tacknowledge
{
    int id;
    int info;
};

#endif

