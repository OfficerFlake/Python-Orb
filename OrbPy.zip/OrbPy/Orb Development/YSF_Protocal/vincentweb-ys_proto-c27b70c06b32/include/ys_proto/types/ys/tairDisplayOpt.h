#ifndef TAIRDISPLAYOPT
#define TAIRDISPLAYOPT

struct tairDisplayOpt
{
    char  u[4];
    char* message;
};

#endif
