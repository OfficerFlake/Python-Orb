#ifndef TGROUND
#define TGROUND

// kind=5
struct tground
{
    int   type;
    int   id;
    int   iff;
    float x;
    float z;
    float y;
    float r1;
    float r2;
    float r3;
    char  name[64];
    int   gro_id;
    int   flag;
    int   u1;
    float u2;
    int   u3;
    int   u4;
    char  name2[56];
};
#endif
