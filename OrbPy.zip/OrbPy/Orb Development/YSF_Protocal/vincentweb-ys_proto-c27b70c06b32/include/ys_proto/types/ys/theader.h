#ifndef THEADER
#define THEADER

struct theader
{
    int size;
    int kind;
};

#endif
