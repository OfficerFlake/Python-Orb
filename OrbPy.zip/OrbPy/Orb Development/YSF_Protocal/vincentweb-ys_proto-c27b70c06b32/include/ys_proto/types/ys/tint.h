#ifndef TINT
#define TINT

struct tint
{
    int val;
};

#endif
