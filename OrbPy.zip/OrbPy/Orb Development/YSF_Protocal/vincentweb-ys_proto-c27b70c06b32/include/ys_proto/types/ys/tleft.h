#ifndef TLEFT
#define TLEFT

struct tleft
{
    int id;
    int u;
};

#endif

