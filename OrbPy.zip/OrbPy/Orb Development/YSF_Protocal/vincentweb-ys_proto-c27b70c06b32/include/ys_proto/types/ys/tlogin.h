#ifndef TLOGIN
#define TLOGIN

struct tlogin
{
    char username[16];
    int  YSversion;
};


#endif
