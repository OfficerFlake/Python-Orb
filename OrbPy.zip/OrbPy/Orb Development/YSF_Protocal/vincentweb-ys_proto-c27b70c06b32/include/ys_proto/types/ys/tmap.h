#ifndef TMAP
#define TMAP

struct tmap
{
	char map[60];
};

#endif
