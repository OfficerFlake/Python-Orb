#ifndef TMESSAGE
#define TMESSAGE

struct tmessage
{
    long  u;
    char* message;
};

#endif

