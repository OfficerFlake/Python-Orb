#ifndef TMISSILEOPT
#define TMISSILEOPT

struct tmissileOpt
{
    int  missileOn;
};

#endif
