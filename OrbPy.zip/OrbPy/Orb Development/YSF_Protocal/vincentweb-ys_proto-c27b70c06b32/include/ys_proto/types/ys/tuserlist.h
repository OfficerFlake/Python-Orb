#ifndef TUSERLIST
#define TUSERLIST

//kinf=37
struct tuserlist
{
    short action;
    short IFF;
    int ID;
    int u;
    char username[16];
};
#endif
