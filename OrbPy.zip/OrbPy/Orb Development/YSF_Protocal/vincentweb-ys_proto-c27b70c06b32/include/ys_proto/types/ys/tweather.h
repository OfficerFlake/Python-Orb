#ifndef TWEATHER
#define TWEATHER

// kind=33, size=32
struct tweather
{
    int day;
    int options;
    float windX;
    float windZ;
    float windY;
    float visibility;
};
#endif
