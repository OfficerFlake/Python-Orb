//#include <string.h>
//
//char test[14];
//test[0] = 'a';
//test[1] = 'b';
//test[2] = '0xa0';
