NAME
    netlog - log in the file log.xml everything happened on the server localhost:7915


SYNOPSIS
    netlog

EXAMPLE OF OUTPUT (log.xml) should be self-explicit
    <map>CRESCENT_ISLAND</map>
    <weather day='1' visibility='20000' windX='0' windY=0' windZ='0' />
    <groundjoin id='66061' name='HG03' name2='' iff='0' groID='0' />
    <message>vins took off (F-18E_SUPERHORNET)</message>
    <pilotjoin id='66064' name='F-18E_SUPERHORNET' name2='vins' iff='1' />
    <message>vins has left the airplane.</message>
    <pilotLeft id='66064' />
    <message>(vins)tadam</message>
