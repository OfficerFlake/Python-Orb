def Add(self, message_in):
        message_in = message_in.split(" ",3)
        if (len(message_in) < 3):
            SendCommandBackward(self, 'Not enough arguments! /Add requires at least a username and a group.')
            return 0
        ##0 = command
        ##1 = username
        try:
            test = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = group
        try:
            test = Group[message_in[2]]
        except:
            SendCommandBackward(self, 'Group not found: ' + message_in[2])
            return -2
        ##3 = rank
        try:
            rank = message_in[3]
        except:
            rank = 0
        User[message_in[1]].AddToGroup(message_in[2], rank, self)

def Remove(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 3):
            SendCommandBackward(self, 'Not enough arguments! /Remove requires at least a username and a group')
            return 0
        ##0 = command
        ##1 = username
        try:
            test = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = group
        try:
            test = Group[message_in[2]]
        except:
            SendCommandBackward(self, 'Group not found: ' + message_in[2])
            return -2
        User[message_in[1]].RemoveFromGroup(message_in[2], self)
