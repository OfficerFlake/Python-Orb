def Ban(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 3):
            SendCommandBackward(self, 'Not enough arguments! /ban requires at least a username and a reason.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = reason
        reason = message_in[2]
        ##3 = expires
        try:
            expires = message_in[3]
        except:
            expires = (-1, -1, -1)
        username.Ban(reason, self, expires)

def UnBan(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 3):
            SendCommandBackward(self, 'Not enough arguments! /unban requires at least a username and a reason.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = reason
        reason = message_in[2]
        ##3 = expires
        try:
            expires = message_in[3]
        except:
            expires = (-1, -1, -1)
        username.UnBan(reason, self, expires)
