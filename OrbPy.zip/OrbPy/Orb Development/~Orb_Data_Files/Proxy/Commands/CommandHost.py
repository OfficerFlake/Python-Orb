##ImportCommands:
execfile("Proxy/Commands/PromoteDemote.py")
execfile("Proxy/Commands/Information.py")
execfile("Proxy/Commands/Players.py")
execfile("Proxy/Commands/HideUnhide.py")
execfile("Proxy/Commands/AddRemoveUserToGroup.py")
execfile("Proxy/Commands/BanUnban.py")
execfile("Proxy/Commands/MuteUnMute.py")
execfile("Proxy/Commands/FreezeUnFreeze.py")
execfile("Proxy/Commands/Kick.py")
execfile("Proxy/Commands/Kill.py")
execfile("Proxy/Commands/Say.py")
execfile("Proxy/Commands/PrivateMessage.py")

def Type32(self, message_in, message_out):
    if (message_in.split(" ")[0].lower() == "/info") or (message_in.split(" ")[0].lower() == "/about"):
        Information(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/players") or (message_in.split(" ")[0].lower() == "/who") or (message_in.split(" ")[0].lower() == "/listuser") or (message_in.split(" ")[0].lower() == "/listusers"):
        Players(self)
    elif (message_in.split(" ")[0].lower() == "/hide") and not User[self.Username].Info["Muted"]:
        Hide(self)
    elif (message_in.split(" ")[0].lower() == "/unhide"):
        UnHide(self)
    elif (message_in.split(" ")[0].lower() == "/promote") and not User[self.Username].Info["Muted"]:
        Promote(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/demote") and not User[self.Username].Info["Muted"]:
        Demote(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/add") and not User[self.Username].Info["Muted"]:
        Add(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/remove") and not User[self.Username].Info["Muted"]:
        Remove(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/ban") and not User[self.Username].Info["Muted"]:
        Ban(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/unban") and not User[self.Username].Info["Muted"]:
        UnBan(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/mute") and not User[self.Username].Info["Muted"]:
        Mute(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/unmute") and not User[self.Username].Info["Muted"]:
        UnMute(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/freeze") or (message_in.split(" ")[0].lower() == "/stop") and not User[self.Username].Info["Muted"]:
        Freeze(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/unfreeze") or (message_in.split(" ")[0].lower() == "/thaw") and not User[self.Username].Info["Muted"]:
        UnFreeze(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/kick") or (message_in.split(" ")[0].lower() == "/boot") and not User[self.Username].Info["Muted"]:
        Kick(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/say") and not User[self.Username].Info["Muted"]:
        Say(self, message_in)
    #elif (message_in.split(" ")[0].lower() == "/kill") and not User[self.Username].Info["Muted"]:
    #    Kill(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/clear") or (message_in.split(" ")[0].lower() == "/cls"):
        i = 0
        x = datetime.datetime.now()
        y = datetime.timedelta(seconds=0.025)
        m = "Cleaning your screen!"
        SendCommandBackward(self, m)
        while i < 16:
            while (x+y > datetime.datetime.now()):
                pass
            x = datetime.datetime.now()
            i += 1
            m = "\n\n\n\n\n\n\n\n"
            SendCommandBackward(self, m)
    elif (message_in.split(" ")[0].lower()[0] == "/"):
        if not (message_in.split(" ")[0].lower()[1] == "/"):
            SendCommandBackward(self, "Command Not Recognised: \"" + message_in + "\"")
            
    if True:
        try:
            if User[self.Username].Info["Muted"]:
                print  '(' + self.Username + '[M] -> ' + self.other.Username + ')', message_in
                SendCommandBackward(self, "You are still muted!")
            else:
                ##Normal Chat Message!
                if (message_in[0] == "@"):
                    PrivateMessage(self, message_in)
                else:
                    #print "not a pm"
                    try:
                        usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
                    except:
                        ##The logging in user is not a member of the master group.
                        usersvalue = -1
                    #print usersvalue
                    if usersvalue >= 0:
                        tag = "[" + str(ServerInfo.MasterGroup) + "]"
                        tag += "["+ str(Group[ServerInfo.MasterGroup].Rank[int(User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"])].RankName) + "]"
                        #print tag
                    else:
                        if len(User[self.Username].Group.keys()) > 0:
                            group = User[self.Username].Group.keys()[0]
                            tag = "[" + group + "]"
                            tag += "["+ str(Group[group].Rank[int(User[self.Username].Group[group].Rank["Number"])].RankName) + "]"
                            #print tag
                        else:
                            tag = ""
                    if (message_in.split(" ")[0].lower()[0] == "/"):
                        if (message_in.split(" ")[0].lower()[1] == "/"):
                            print  '(' + self.Username + ' -> ' + self.other.Username + ') "' + message_in[1:] + "\""
                            m = "(" + tag + User[self.Username].Info["DisplayedName"] + ")" + message_in[1:]
                        else:
                            return True
                    else:
                        print  '(' + self.Username + ' -> ' + self.other.Username + ') "' + message_in + "\""
                        m = "(" + tag + User[self.Username].Info["DisplayedName"] + ")" + message_in
                    SendCommandForward(self, m)
        except:
            ##Normal Chat Message/ServerMessage.
            SendCommandForward(self, message_out)

def tupletodate(variable):
	try:
		return str(str(variable[0]) + "/" + str(variable[1]) + "/" + str(variable[2]))
	except:
		print 'tuple to date error'
		return variable
