def Freeze(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /freeze requires a username.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        username.Freeze(self)

def UnFreeze(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /unfreeze requires a username.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        username.UnFreeze(self)
