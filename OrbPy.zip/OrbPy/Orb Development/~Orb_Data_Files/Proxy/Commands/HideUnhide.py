def Hide(self):
    if (int(User[self.Username].Info["Hidden"]) == 1):
        SendCommandBackward(self, "You are already hidden.")
    else:
        try:
            usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The user is not a member of the master group.
            usersvalue = 0
        #print int(User[self.Username].Permission["CanHide"])
        #print int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanHide"])
        if (int(User[self.Username].Permission["CanHide"]) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanHide"]) >= 1):
            User[self.Username].Info["Hidden"] = 1
            WriteUserToDatabase(self.Username)
            SendCommandBackward(self, "You are now hidden")
            for username in ServerInfo.UsersOnline:
                try:
                    usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
                except:
                    ##The logging in user is not a member of the master group.
                    usersvalue = -1
                try:
                    targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
                except:
                    ##The target user is not a member of the master group.
                    targetsvalue = -1
                if not (username == self.Username):
                    if (int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"])  >= int(usersvalue)):
                        m = User[self.Username].Info["DisplayedName"] + ' is now HIDDEN.'
                        SendCommandBackward(User[username].Info["ClientID"], m)
                    else:
                        SendCommandBackward(User[username].Info["ClientID"], User[self.Username].Info["DisplayedName"] + ' left the server.')
        else:
            SendCommandBackward(self, "Your rank is not high enough to 'Hide'.")

def UnHide(self):
    ##All users should be able to unhide!
    if (int(User[self.Username].Info["Hidden"]) == 0):
        SendCommandBackward(self, "You are not currently hidden.")
    else:
        User[self.Username].Info["Hidden"] = 0
        WriteUserToDatabase(self.Username)
        SendCommandBackward(self, "You are no longer hidden.")
        for username in ServerInfo.UsersOnline:
            try:
                usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
            except:
                ##The logging in user is not a member of the master group.
                usersvalue = -1
            try:
                targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
            except:
                ##The target user is not a member of the master group.
                targetsvalue = -1
            if not (username == self.Username):
                if (int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"])  >= int(usersvalue)):
                    m = User[self.Username].Info["DisplayedName"] + ' is no longer Hidden.'
                    SendCommandBackward(User[username].Info["ClientID"], m)
                else:
                    SendCommandBackward(User[username].Info["ClientID"], User[self.Username].Info["DisplayedName"] + ' joined the server.')
