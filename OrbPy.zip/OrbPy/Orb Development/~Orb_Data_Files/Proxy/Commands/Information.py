def Information(self, message_in):
    try:
        #
        #
        #Permissions Test.
        #
        #
        message_in = message_in.split(" ", 1)
        if (len(message_in) < 2):
            target = self.Username
            #print 'uname ' + target
        else:
            target = message_in[1]
            if UserExists(target):
                pass
            else:
                m =  'User Not Found: "' + target + '"'
                SendCommandBackward(self, m)
                return -1
        if AdminOverride(self):
            print 'override'
            InformationOverride(self, target)
        elif PermissionsComparisonOffline(self.Username, target, ServerInfo.MasterGroup, "CanViewOthersInfo") or (self.Username != target):
            m =  'You can not look up information on user "' + User[target].Info["DisplayedName"] + '". Your rank is not able to view others info.'
            SendCommandBackward(self, m)
            return -2
        else:
            print 'Not override'
            InformationOverride(self, target)
    except:
        print sys.exc_info()


def InformationOverride(self, target):
    try:
        InformationOverride_UserOnline(self, target)
        InformationOverride_LoginInfo(self, target)
        InformationOverride_BanInfo(self, target)
        InformationOverride_KickInfo(self, target)
        InformationOverride_FreezeInfo(self, target)
        InformationOverride_KDRInfo(self, target)
        InformationOverride_MessagesTypedInfo(self, target)
        InformationOverride_FlightInfo(self, target)
        InformationOverride_MasterGroupInfo(self, target)
        InformationOverride_PlaytimeInfo(self, target)
    except:
        print sys.exc_info()

def InformationOverride_UserOnline(self, target):
    if (User[target].Info["Hidden"]): #User Is Hidden, We must see if they are able to be seen.
        if not PermissionsComparison(self, target, ServerInfo.MasterGroup, "CanHideFromRank") or not AdminOverride(self):
            m =  "About " + User[target].Info["DisplayedName"] + ": OFFLINE, last seen from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m) #Hidden, can't be seen.
        else: #See if they are online.
            found = False
            for i in ServerInfo.UsersOnline:
                if (i == target):
                    found = True
        if found: #online and can be seen.
            m =  "About " + User[target].Info["DisplayedName"] + ": HIDDEN, connected from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m)
        else: #offline but could be seen.
            m =  "About " + User[target].Info["DisplayedName"] + ": OFFLINE, last seen from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m)
    else: 
        found = False
        for i in ServerInfo.UsersOnline:
            if (i == target):
                found = True
        if found:
            m = "About " + User[target].Info["DisplayedName"] + ": ONLINE, connected from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m)
        else:
            m =  "About " + User[target].Info["DisplayedName"] + ": OFFLINE, last seen from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m)

def InformationOverride_LoginInfo(self, target):            
    if (User[target].Info["LoginCount"] > 0):
        try:
            if (User[target].Info["JoinDate"] == (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)):
                m = "Logged in " + str(User[target].Info["LoginCount"]) + " time(s), joining today."
            else:
                m = "Logged in " + str(User[target].Info["LoginCount"]) + " time(s) since " + tupletodate(User[target].Info["JoinDate"]) + "."
            SendCommandBackward(self, m)
        except:
            print sys.exc_info()
    else:
        try:
            #m = "Joined Today."
            #SendCommandBackward(self, m)
            print "Login Data Unnavailable"
            pass
        except:
            print sys.exc_info()

def InformationOverride_BanInfo(self, target): 
    if (User[target].Info["Banned"]):
        try:
            m = "BANNED by " + User[target].Info["BannedBy"] + " On " + tupletodate(User[target].Info["BanDate"]) + "."
            SendCommandBackward(self, m)
            m = "Ban Reason: " + User[target].Info["BanReason"]
            SendCommandBackward(self, m)
            m = "Ban Expires: " + tupletodate(User[target].Info["BanExpires"])
            SendCommandBackward(self, m)
        except:
            print sys.exc_info()

def InformationOverride_KickInfo(self, target): 
    if (User[target].Info["TimesKicked"] > 0):
        try:
            m = "Kicked " + str(User[target].Info["TimesKicked"]) + " Time(s). Last kick by " + User[target].Info["KickedBy"] + " On " + tupletodate(User[target].Info["KickDate"]) + "."
            SendCommandBackward(self, m)
            m = "Kick Reason: " + User[target].Info["KickReason"]
            SendCommandBackward(self, m)
        except:
            print sys.exc_info()

def InformationOverride_FreezeInfo(self, target): 
    if (User[target].Info["Frozen"] > 0):
        difference = datetime.datetime.now() - User[target].Info["FrozenDate"]
        try:
            weeks = difference.weeks
        except:
            weeks = 0
        try:
            days = difference.days
        except:
            days = 0
        try:
            hours = difference.hours
        except:
            hours = 0
        try:
            minutes = difference.minutes
        except:
            minutes = 0
        try:
            seconds = difference.seconds
        except:
            seconds = 0
        difference = ""
        if weeks > 0:
            difference = " " + str(weeks) + "w ago."
        elif days > 0:
            difference = " " + str(days) + "d ago."
        elif hours > 0:
            difference = " " + str(hours) + "h ago."
        elif minutes > 0:
            difference = " " + str(minutes) + "m ago."
        elif seconds > 0:
            difference = " " + str(seconds) + "s ago."
        elif weeks == 0 and days == 0 and hours == 0 and minutes == 0 and seconds == 0:
            difference = " now."
        else:
            difference = "."
        m = "Frozen by " + User[User[target].Info["FrozenBy"]].Info["DisplayedName"] + difference
        SendCommandBackward(self, m)

def InformationOverride_KDRInfo(self, target):            
    if (User[target].Info["Deaths"] > 0) or (User[target].Info["Kills"] > 0):
        if (User[target].Info["Deaths"] <= 0):
            m = "Killed " + str(User[target].Info["Kills"]) + " Player(s), Been Killed 0 Times. K:D Ratio: Perfect!"
            SendCommandBackward(self, m)
        else:
            m = "Killed " + str(User[target].Info["Kills"]) + " Player(s), Been Killed " + str(User[target].Info["Deaths"]) + " Times. K:D Ratio: " + str(float(User[target].Info["Kills"])/float(User[target].Info["Deaths"])) + "."
            SendCommandBackward(self, m)

def InformationOverride_MessagesTypedInfo(self, target): 
    if (User[target].Info["MessagesTyped"] > 0):
        m = "Typed " + str(User[target].Info["MessagesTyped"]) + " message(s) in total."
        SendCommandBackward(self, m)

def InformationOverride_FlightInfo(self, target): 
    if (User[target].Info["FlightsFlown"] > 0):
        try:
            hours = float(User[target].Info["FlightHours"].weeks) * 24 * 7
        except:
            hours = float(0)
        try:
            hours += float(User[target].Info["FlightHours"].days) * 24
        except:
            hours += float(0)
        #print hours
        try:
            hours += float(User[target].Info["FlightHours"].hours)
        except:
            pass
        #print hours
        try:
            hours += float(User[target].Info["FlightHours"].minutes)/60
        except:
            pass
        #print hours
        try:
            hours += float(User[target].Info["FlightHours"].seconds)/3600
        except:
            pass
        #print hours
        minutes = str(hours*60)[0:str(hours*60).find('.')+2]
        hours = str(hours)[0:str(hours).find('.')+2]
        m = "Joined Flight " + str(User[target].Info["FlightsFlown"]) + " Time(s), Flying " + str(hours) + " Hour(s) Total(" + str(minutes) + " minutes)."
        SendCommandBackward(self, m)

def InformationOverride_GroupInfo(self, target): 
    for i in User[target].Group.keys():
        #print i
        m = "Info for group: " + i
        SendCommandBackward(self, m)
        #print User[username].Group[i].Rank["Previous"]
        #print User[username].Group[i].Rank["Number"]
        #print len(Group[i].Rank)
        if (int(User[target].Group[i].Rank["Previous"]) > len(Group[i].Rank)-1):
            print "Database Error: Users Previous Rank Exceed The Group Limit!"
            User[target].Group[i].Rank["Previous"] = len(Group[i].Rank)-1
        elif (int(User[target].Group[i].Rank["Previous"]) < 0):
            print "Database Error: Users Previous Rank Less Then Zero!"
            User[target].Group[i].Rank["Previous"] = 0
        if (int(User[target].Group[i].Rank["Previous"]) == int(User[target].Group[i].Rank["Number"])):
            #print Group[i].Rank[int(User[target].Group[i].Rank["Number"])]
            m = "Rank: " + Group[i].Rank[int(User[target].Group[i].Rank["Number"])].RankName
            SendCommandBackward(self, m)
        elif(int(User[target].Group[i].Rank["Previous"]) < int(User[target].Group[i].Rank["Number"])):
            m = "Promoted from " + Group[i].Rank[int(User[target].Group[i].Rank["Previous"])].RankName + " to " + Group[i].Rank[int(User[target].Group[i].Rank["Number"])].RankName + " by " + User[target].Group[i].Rank["By"]+ " on " + tupletodate(User[target].Group[i].Rank["Date"]) + "."
            SendCommandBackward(self, m)
            if (len(User[target].Group[i].Rank["Reason"]) > 0):
                m = "Reason: " + User[target].Group[i].Rank["Reason"]
                SendCommandForward(host, m)
        elif (int(User[target].Group[i].Rank["Previous"]) > int(User[target].Group[i].Rank["Number"])):
            m = "Demoted from " + Group[i].Rank[int(User[target].Group[i].Rank["Previous"])].RankName + " to " + Group[i].Rank[int(User[target].Group[i].Rank["Number"])].RankName + " by " + User[target].Group[i].Rank["By"]+ " on " + tupletodate(User[target].Group[i].Rank["Date"]) + "."
            SendCommandBackward(self, m)
            m = "Reason: " + User[target].Group[i].Rank["Reason"]
            if (len(User[target].Group[i].Rank["Reason"]) > 0):
                m = "Reason: " + User[target].Group[i].Rank["Reason"]
                SendCommandForward(host, m)
        else:
            m = "Rank: " + Group[i].Rank[int(User[target].Group[i].Rank["Number"])].RankName
            SendCommandBackward(self, m)

def InformationOverride_MasterGroupInfo(self, target):
    if UserInGroupOffline(target, ServerInfo.MasterGroup):
        if (int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"]) > len(Group[ServerInfo.MasterGroup].Rank)-1):
            print "Database Error: Users Previous Rank Exceed The Master Groups Limit!"
            User[target].Group[ServerInfo.MasterGroup].Rank["Previous"] = len(Group[ServerInfo.MasterGroup].Rank)-1
        elif (int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"]) < 0):
            print "Database Error: Users Previous Rank Less Then Zero!"
            User[target].Group[ServerInfo.MasterGroup].Rank["Previous"] = 0
        if (int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"]) == int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])):
            #print Group[i].Rank[int(User[target].Group[i].Rank["Number"])]
            m = "Current Rank: " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])].RankName
            SendCommandBackward(self, m)
        elif(int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"]) < int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])):
            m = "Promoted from " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"])].RankName + " to " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])].RankName + " by " + User[User[target].Group[ServerInfo.MasterGroup].Rank["By"]].Info["DisplayedName"] + " on " + tupletodate(User[target].Group[ServerInfo.MasterGroup].Rank["Date"]) + "."
            SendCommandBackward(self, m)
            if (len(User[target].Group[ServerInfo.MasterGroup].Rank["Reason"]) > 0):
                m = "Reason: " + User[target].Group[ServerInfo.MasterGroup].Rank["Reason"]
                SendCommandBackward(self, m)
        elif (int(User[target].Group[SendCommandBackward(self, m)].Rank["Previous"]) > int(User[target].Group[SendCommandBackward(self, m)].Rank["Number"])):
            m = "Demoted from " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"])].RankName + " to " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])].RankName + " by " + User[User[target].Group[ServerInfo.MasterGroup].Rank["By"]].Info["DisplayedName"] + " on " + tupletodate(User[target].Group[ServerInfo.MasterGroup].Rank["Date"]) + "."
            SendCommandBackward(self, m)
            if (len(User[target].Group[ServerInfo.MasterGroup].Rank["Reason"]) > 0):
                m = "Reason: " + User[target].Group[ServerInfo.MasterGroup].Rank["Reason"]
                SendCommandBackward(self, m)
    else:
        m = User[target].Info["DisplayedName"] + " is not an inducted member of the server."
        SendCommandBackward(self, m)
    
        
def InformationOverride_PlaytimeInfo(self, target): 
    try:
        hours = float(User[target].Info["PlayTime"].weeks) * 24 * 7
    except:
        hours = float(0)
    try:
        hours += float(User[target].Info["PlayTime"].days) * 24
    except:
        hours += float(0)
    #print hours
    try:
        hours += float(User[target].Info["PlayTime"].hours)
    except:
        pass
    #print hours
    try:
        hours += float(User[target].Info["PlayTime"].minutes)/60
    except:
        pass
    #print hours
    try:
        hours += float(User[target].Info["PlayTime"].seconds)/3600
    except:
        pass
    #print hours
    minutes = str(hours*60)[0:str(hours*60).find('.')+2]
    hours = str(hours)[0:str(hours).find('.')+2]
    m = "Played for " + str(hours) + " hours in total(" + str(minutes) + " minutes)."
    SendCommandBackward(self, m)
