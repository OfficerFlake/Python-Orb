def Kick(self, message_in):
        #print message_in
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /kick requires at least a username.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = reason
        try:
                reason = message_in[2]
        except:
                reason = ""
        username.Kick(reason, self)
