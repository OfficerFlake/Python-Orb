from time import sleep

def Kill(self, message_in):
        #print message_in
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /kill requires an object ID.')
            return 0
        ##0 = command
        ##1 = targetID
        try:
            targetID = int(message_in[1])
        except:
            SendCommandBackward(self, 'Target ID not a number! ' + message_in[1])
            return -1
        ##2 = reason
        try:
                reason = message_in[2]
        except:
                reason = ""
        try:
            data = pack("IIIHHHI", 1, targetID, 1, 20, 1, 1, 11)
            ProcessPacket(self, len(data)+8, 22, data)
        except Exception, ex:
            print ex
            sleep(50000)
