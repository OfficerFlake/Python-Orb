def Logoff(self):
    #print 'in the log off script'
    try:
        found = False;
        for username in ServerInfo.UsersOnline:
            if (username == self.Username):
                #print 'found myself'
                found = True
    except:
        found = False;
        
    if found:
        for username in ServerInfo.UsersOnline:
            if (username != self.Username):
                try:
                    usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
                except:
                    ##The logging in user is not a member of the master group.
                    usersvalue = -1
                try:
                    targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
                except:
                    ##The target user is not a member of the master group.
                    targetsvalue = -1

                if (User[self.Username].Info["Hidden"]):
                    #print 'hidden'
                    if not (int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanHideFromRank"]) + int(User[self.Username].Permission["CanHideFromRank"])  >= int(targetsvalue)):
                        #print 'this user can see me'
                        m = User[self.Username].Info["DisplayedName"] + ' left the server.'
                        try:
                            SendCommandBackward(User[username].Info["ClientID"], m)
                        except:
                            #The user may have dc'd at the same time?
                            pass
                else:
                    #print 'not hidden'
                    try:
                        SendCommandBackward(User[username].Info["ClientID"], User[self.Username].Info["DisplayedName"] + ' left the server.')
                    except:
                        #The user may have dc'd at the same time?
                        pass

        #print 'deleted my client id.'
        del User[self.Username].Info["ClientID"]
            
        
