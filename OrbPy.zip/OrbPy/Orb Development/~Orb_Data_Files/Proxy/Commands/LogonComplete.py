def LogonComplete(self):
    if self.Username.lower() == 'php bot':
        return 0
    User[self.Username].Info["ClientID"] = self
    User[self.Username].Info["IPAddress"] = self.clientsock.getpeername()[0]
    for username in ServerInfo.UsersOnline:
        if (username == self.Username):
                if (User[username].Info["LoginCount"] > 0):
                    m = 'Welcome Back ' + User[username].Info["DisplayedName"] + '.'
                    m += '\nYour last visit was ' + tupletodate(User[username].Info["LastVisit"]) + '.'
                    SendCommandBackward(self, m)
                    User[username].Info["LoginCount"] += 1
                    if (User[username].Info["JoinDate"] == (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)):
                        m = "Logged in " + str(User[username].Info["LoginCount"]) + " time(s), joining today."
                    else:
                        m = "Logged in " + str(User[username].Info["LoginCount"]) + " time(s) since " + tupletodate(User[username].Info["JoinDate"]) + "."
                    if (User[username].Info["LoginCount"] == 2):
                        m += "\nThis is your 2nd Login! Glad to see you come back! :D"
                    if (User[username].Info["LoginCount"] == 10):
                        m += "\nThis is your 10th Login! Keep coming back and you can earn a PRIZE! (maybe)"
                    if (User[username].Info["LoginCount"] == 100):
                        m += "\nThis is your 100th Login! Let's all drink and party! YEAHHHHH!"
                    elif (User[username].Info["LoginCount"] == 500):
                        m += "\nThis is your 500th Login! Dude time to go play with the other  kids in your neighbourhood... right?"
                    elif (User[username].Info["LoginCount"] == 1000):
                        m += "\nMOTHER OF GOD! THIS IS YOUR 1000th LOGIN! CRAWL OUT OF YOUR MOTHERS BASEMENT MAN!"
                    elif (User[username].Info["LoginCount"] == 2000):
                        m += "\nThat's 2000 logins. Holy sheet."
                    elif (User[username].Info["LoginCount"] == 3000):
                        m += "\nThis is your 3000th Login! Congratulations?"
                    elif (User[username].Info["LoginCount"] == 4000):
                        m += "\nThis is your 4000th Login!!! PLEASE ENJOY THIS JOKE:"
                        m += "\nHow did the hipster burn his hand? He changed the lightbulb before it was cool!"
                        m += "\nHAHAHAHAHHA! THAT'S FUNNY, RIGHT?"
                    elif (User[username].Info["LoginCount"] == 5000):
                        m += "\nThis is your 5000th Login!!! You will now receive a complimentary login gift each time you rejoin! Cool huh?"
                    elif (User[username].Info["LoginCount"] > 5000 and User[username].Info["LoginCount"] < 9000):
                        m += "\nI logged in over 5000 times and all I got was this crappy login message."
                    elif (User[username].Info["LoginCount"] == 9000):
                        m += "\nThis is your 9000th Login!!! YOU'VE WON A PRIZE! NOW, EVERY TIME YOU LOG IN,  EVERYONE WILL KNOW YOUR POWER LEVEL IS OVER9000!"
                        m += "\n(By the way, this is the LAST login bonus based prize.)"
                    elif (User[username].Info["LoginCount"] > 9000):
                        m += "\nYour power level is OVER NINE THOUSSSSAAAAAAAAAAAAAAAAAAAAAAAAND!"
                        if not (User[self.Username].Info["Hidden"]):
                            a = "Vegeta! What's the scouter say about " + User[self.Username].Info["DisplayedName"] + "'s Power Level?"
                            a += "\nIT'S OVER NINE THOUUUUSSSAAAAAAAAAAAAAAAAAAANNNNND!!!!111ONE"
                            a += "\nWHAT!? OVER NINE THOUSAND!?"
                            SendCommandForward(self, a)
                    User[username].Info["LastVisit"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
                    WriteUserToDatabase(self.Username)
                else:
                    m = 'Welcome ' + User[username].Info["DisplayedName"] + '.'
                    User[username].Info["LoginCount"] += 1
                    User[username].Info["JoinDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
                    User[username].Info["LastVisit"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
                    WriteUserToDatabase(self.Username)
                if (User[username].Info["Hidden"]):
                    m += "\nYou've logged in HIDDEN. Use '/unhide' to show up to everyone else!"
                SendCommandBackward(self, m)
                Players(self)
        else:
            try:
                usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
            except:
                ##The logging in user is not a member of the master group.
                usersvalue = -1
            try:
                targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
            except:
                ##The target user is not a member of the master group.
                targetsvalue = -1
            #print User[username].Info["Hidden"]
            #print int(targetsvalue)
            #print int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"])
            #print int(User[username].Permission["CanHideFromRank"])
            #print int(usersvalue)
            #print int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"])
            if (User[self.Username].Info["Hidden"]):
                if (int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"]) >= int(usersvalue)):
                    m = User[self.Username].Info["DisplayedName"] + ' Logged in HIDDEN.'
                    SendCommandBackward(User[username].Info["ClientID"], m)
                else:
                    ##Do nothing! THE USER is HIDDEN!
                    pass;
            else:
                SendCommandBackward(User[username].Info["ClientID"], User[self.Username].Info["DisplayedName"] + ' joined the server.')
            
        
