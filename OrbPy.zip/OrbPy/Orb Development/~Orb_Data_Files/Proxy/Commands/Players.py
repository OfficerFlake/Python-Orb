def Players(self):
    m = ""
    for username in ServerInfo.UsersOnline:
        try:
            usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The logging in user is not a member of the master group.
            usersvalue = 0
        #print usersvalue
        try:
            targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The target user is not a member of the master group.
            targetsvalue = 0
        #print targetsvalue
        if (User[username].Info["Hidden"]):
            if not (int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"])  >= int(usersvalue)):
                if (len(m) == 0):
                    m += User[username].Info["DisplayedName"]
                else:
                    m += ", " + User[username].Info["DisplayedName"]
            else:
                #print "hidden user: " + User[username].Info["DisplayedName"]
                pass
        else:
            ##USER IS NOT HIDDEN:
                if (len(m) == 0):
                    m += User[username].Info["DisplayedName"]
                else:
                    m += ", " + User[username].Info["DisplayedName"]
    ##finally,
    SendCommandBackward(self, "Users Online:\n" + m)
