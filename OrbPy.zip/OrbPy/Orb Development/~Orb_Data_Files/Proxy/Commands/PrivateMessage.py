from random import choice

def PrivateMessage(self, message_in):
    target = message_in.split(" ", 1)[0][1:]
    found = False
    for username in ServerInfo.UsersOnline:
        if username == target:
            found = True
    if not found:
        m = 'User not found: "' + target + '".'
        SendCommandBackward(self, m)
        return -1
    if (target == self.Username):
        m = ['Trying to talk to ourselves are we? Tut tut tut...',
             "I love me... I love me... I'm the best friend I can be...",
             "HAHA LONER!",
             "Stop talking to yourself. It's the first sign of madness.",
             "All work and no play makes jack a dullboy",
             "FOREVERALONE.JPG",
             "FOREVERALONE. LEVEL: YSFLIGHT",
             "You're talking to yourself again. Perhaps It's time for a break?\nPlease enjoy this refreshing beverage!",
             "Mr. T pities the fool whom talks to themselves...",
             "PM From " + User[self.Username].Info["DisplayedName"] + ": Hello? Hello? ... Why doesn't anyone talk to me...",
             "We're Gunna Be Late! WHY WON'T YOU TALK TO ME!?",
             "SUCESS! You talk to yourself! Your shallow lifeless words echo off the servers lifeless empty ears, lost in a pile of 1's and 0's...",
             "ACHIVEMENT GET: BE A COMPLETE NOOB AND TALK TO YOURSELF VIA PRIVATE MESSAGE."]
        print  '(' + self.Username + ' -> ' + target + ')', message_in.split(" ", 1)[1]
        SendCommandBackward(self, choice(m))
        return 0
    for username in ServerInfo.UsersOnline:
        if (username == self.Username):
                print  '(' + self.Username + ' -> ' + target + ')', message_in.split(" ", 1)[1]
                m = "PM To " + User[target].Info["DisplayedName"] + ": " + message_in.split(" ", 1)[1]
                SendCommandBackward(self, m)
        elif (username == target):
                m = "PM From " + User[self.Username].Info["DisplayedName"] + ": " + message_in.split(" ", 1)[1]
                SendCommandBackward(User[target].Info["ClientID"], m)
            
        
