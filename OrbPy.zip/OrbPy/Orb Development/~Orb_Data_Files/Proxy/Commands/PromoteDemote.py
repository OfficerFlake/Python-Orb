def Promote(self, message_in):
        message_in = message_in.split(" ",4)
        if (len(message_in) < 4):
            SendCommandBackward(self, 'Not enough arguments! /Promote requires at least a username, a group and a rank.')
            return 0
        ##0 = command
        ##1 = username
        try:
            target = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = group
        try:
            group = Group[message_in[2]]
            group = message_in[2]
        except:
            SendCommandBackward(self, 'Group not found: ' + message_in[2])
            return -2
        ##3 = rank
        try:
            rank = message_in[3]
        except:
            try:
                rank = User[message_in[1]].Group[message_in[2]].Rank["Number"] - 1
            except:
                rank = 0
                #will result in the script denying the demote, as the user isn't part of the group anyway.
        ##4 = reason                                    
        try:
            reason = message_in[4]
        except:
            reason = ""
        User[message_in[1]].Promote(self, group, rank, reason)

def Demote(self, message_in):
        message_in = message_in.split(" ",4)
        if (len(message_in) < 4):
            SendCommandBackward(self, 'Not enough arguments! /Demote requires at least a username, a group and a rank.')
            return 0
        ##0 = command
        ##1 = username
        try:
            target = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = group
        try:
            group = Group[message_in[2]]
            group = message_in[2]
        except:
            SendCommandBackward(self, 'Group not found: ' + message_in[2])
            return -2
        ##3 = rank
        try:
            rank = message_in[3]
        except:
            try:
                rank = User[message_in[1]].Group[message_in[2]].Rank["Number"] - 1
            except:
                rank = 0
                #will result in the script denying the demote, as the user isn't part of the group anyway.
        ##4 = reason                                    
        try:
            reason = message_in[4]
        except:
            reason = ""
        User[message_in[1]].Demote(self, group, rank, reason)
