def Say(self, message_in):
        #print message_in
        message_in = message_in.split(" ",1)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /say requires at least a message.')
            return 0
        ##0 = command
        ##2 = message
        try:
                message = message_in[1]
        except:
                message = ""
        User[self.Username].Say(message)
