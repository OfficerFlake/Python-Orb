def ClientLogin(self):
    """
    This will be hard, we need to get the packet data...
    """
    #we need to receive the packets still!
    self.LoginPacket = -1
    while (str(self.LoginPacket) == '-1'):
        self.LoginPacket = RecvPacket2Data(self)
    datalength = self.LoginPacket[0]
    datatype = self.LoginPacket[1]
    if (datatype == 1): #1 == loginpacket
        self.Username = unpack("16sI",self.LoginPacket[2])[0]
        self.version = unpack("16sI",self.LoginPacket[2])[1]
        ##Take Action on username here...
        #print self.username.lower()
        #print self.clientsock.getsockname()[0]
        self.Username = self.Username.strip("\0")
        print "New Client '" + self.Username + "' Connected From IP Address: " + self.clientsock.getpeername()[0]
        for username in ServerInfo.UsersOnline:
            if (username == self.Username):
                SendCommandBackward(self, 'User "' + self.Username + '" is already on the server. Your login has been denied.')
                print "New Client '" + self.Username + "' Was Rejected, Shared Username."
                self.closing = True
                self.sock.close()
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Client Socket Cleaned."
                del self
                return -1
        loginreturn = LoginUser(self.Username, self)
        if loginreturn:
            try:
                int(User[self.Username].Info["Banned"])
            except:
                print "Error with Users 'ban' info, not an integer: " + User[self.Username].Info["Banned"]
                User[self.Username].Info["Banned"] = 0
            if (User[self.Username].Info["Banned"] >= 1):
                print "New Client '" + self.Username + "' Was Rejected."
                SendCommandBackward(self, 'A ban has been placed on your username by: "' + User[self.Username].Info["BannedBy"] + '".\nReason: ' + User[self.Username].Info["BanReason"]+ '\nYou can not log in.')
                self.closing = True
                self.sock.close()
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Client Socket Cleaned."
                del self
                return -1
            print "New Client '" + self.Username + "' Was Accepted."
            Authorised(self)
            return 0
        else:
            print "New Client '" + self.Username + "' Was Rejected."
            #SendString(self.clientsock,"Username Not Authenticated. Please Log Into YSFHQ First, Then Rejoin This Server With Your YSFHQ Username.")
            self.clientsock.close()
            #self.serversock.close()
    else:
        #The initial packet is NOT a log in packet:
        print 'Orb received a ping from some server, somewhere.\nIgnoring.'
        try:
            SendCommandBackward(self, "Hello There! Nice to meet you! My Name is ORB, and I am the gatekeeper for this YSFlight server.\n\nIt sems you've tried to connect to my server, but have not sent the correct log on data packet.\n\nIf you're a YSFlight client, that probably means that your connection is damaged, or the server has broken.\nTry again? Sorry about this! D:")
        except:
            pass
        return -1

def Authorised(self):
    if self.Username.lower() != 'php bot' and self.Username.lower() != ServerInfo.ConsoleName.lower() :
        ServerInfo.UsersOnline.append(self.Username)
    self.authenticated = True
    ServerAddress = (Settings.ServerIP, Settings.ServerPort)
    self.serversock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    self.serversock.connect(ServerAddress)
    #self.serversock.settimeout(0) ##The server does not send response packets! It only listens for a keep alive!
    self.serversock.send(pack("II" + str(self.LoginPacket[0]-4) + "s", self.LoginPacket[0], self.LoginPacket[1], self.LoginPacket[2]))
