import urllib
def LoginYSFHQ(self, username, password):
    self.result = 'Null'
    #print "Username: " + username
    #print "Password: " + "*" * len(password)
    url = "http://ysfhq.com/phpbb3/orblogin.php?user=" + username + "&pass=" + password
    try:
        urlfileobject = urllib.urlopen(url)
        try:
            response = urlfileobject.read()
            urlfileobject.close()
        except:
            response = "THE SERVER DID NOT REPLY IN TIME."
            urlfileobject.close()
    except:
        response = "FAILED TO OPEN THE URL. PERHAPS THE DOMAIN IS DOWN?"
    if (response == "INVALID"):
        #print "User NOT Authenticated."
        self.result = False
        print self.result
        return False
    else:
        try:
            int(response)
            if (response > 0):
                #print "Logged in as " + username
                self.result = True
                print self.result
                return True
        except:
            SendCommandBackward(self, "YSFHQ Userbase Lookup has broken! (Reply: '" + str(response[:64]) + "')")
            SendCommandBackward(self, "Please let Flake or EricT-15 know what the reply message above was!")
            self.result = False
            print self.result
            return False

def LoginUser(Username, self):
    try:
        test = User[self.Username]
    except:
        User[self.Username] = SpawnUser(self.Username)
        #print User
    if (self.Username.lower() == ServerInfo.ConsoleName.lower()) or (self.Username.lower() == ServerInfo.AdminName.lower()):
        return Administrator_Script(self)
    elif not Settings.UseYSFHQAuthentication:
        User[self.Username].Info['FeedName'] = self.Username
        return True
    if self.Username.lower() == 'php bot':
        SendCommandBackward(self, "You've joined the server as a bot: " + str(self.Username) + "\n\nThe bot aims to get information about the server, and then disconnects.\nTo avoid spy issues:\n    You will be AUTOMATICALLY DISCONNECTED once the server finishes sending the aircraft list\n    You will be denied the ability to send text messages, or receive them.\n\nHave a nice day! :D\n    - Orb")
        return True
    if (Settings.AlwaysAllowLocalHost) and (self.clientsock.getpeername()[0] == "127.0.0.1" or self.clientsock.getpeername()[0] == "localhost"):
        loggedin = True
        return True
    else:
        return YSFHQ_Script(self)

def YSFHQ_Script(self):
    SendCommandBackward(self, "Welcome to the Orb YSFHQ Login System!")
    SendCommandBackward(self, "To join the server, log in with your YSFHQ Username (Case Sensitive!)")
    SendCommandBackward(self, "You are currently attempting to log in as:" + self.Username)
    SendCommandBackward(self, "Please Enter your YSFHQ Password (Case Sensitive!). If this was 'lol' just type 'lol' then send, for example.")
    loggedin = False
    while not loggedin:
        SendCommandBackward(self, "Please Enter Password:")
        received32 = False
        while not received32:
            data = RecvPacket2Data(self)
            datalength = data[0]
            if datalength == -1:
                SendCommandBackward(self, "The Internet Broke Your Shit! I Didn't Understand That... Try Again Please?")
            if datalength == -2:
                SendCommandBackward(self, "It seems that your connection sucks, or this servers connection sucks, or you've deliberatly dc'd (I hope!), if not the latter, then we have an issue. Please speak to the server admin about the lag/packet jumbling.")
            datatype = data[1]
            datapayload = data[2]
            if (datatype == 32):
                received32 = True
                print "got a password from user: " + self.Username
                message_in = Message2String(datapayload)
                self.password = message_in[message_in.find(')')+1:]
                print "password from user " + self.Username + ": " + "*" * 16 #(16 WAS ORIGINALLY PASSWORD LENGTH, BUT THAT COULD PROVE PROBLEMATIC IF IT'S A SHORT PASSWORD!)
                SendCommandBackward(self, "Polling YSFHQ to see if your password matches...\nThis CAN take some time. Please be patient.:")
                self.result = 'Null'
                thread.start_new_thread(LoginYSFHQ, (self, self.Username, self.password,))
                while str(self.result) == 'Null':
                    time.sleep(5)
                    if str(self.result) == 'Null':
                        SendCommandBackward(self, 'Still waiting...')
                del self.password ##FOR PROTECTION ONCE THIS PROGRAM BECOMES SEMI-OPEN SOURCE!
                #PLEASE DO THE RIGHT THING AND *NOT* HACK THIS PROGRAM TO GATHER PEOPLES PASSWORDS! THANKS!
                if not self.result:
                    SendCommandBackward(self, "Password or username not recognised! BOTH ARE CASE SENSITIVE. Please try again.")
                elif self.result:
                    SendCommandBackward(self, "Sucessfully logged in as: " + self.Username)
                    loggedin = True
                    del self.result
    if loggedin:
        User[self.Username].Info['FeedName'] = message_in[1:message_in.find(')')]
        print str(self.Username) + "'s FeedName:" + User[self.Username].Info['FeedName']
        if User[self.Username].Info["DisplayedName"] == self.Username:
            User[self.Username].Info["DisplayedName"] = User[self.Username].Info['FeedName']
        return True
    else:
        User[self.Username].Info['FeedName'] = self.Username
        return False

def Administrator_Script(self):
    loggedin = False
    if ServerInfo.AdminPass == "":
        SendCommandBackward(self, "Sucessfully logged in as Administrator: " + self.Username)
        SendCommandBackward(self, "Consider setting a Server Password to protect your server, otherwise any user could log on under your name and have admin power!")
        loggedin = True
        message_in = "(" + str(self.Username) + ")"
    else:
        SendCommandBackward(self, "Welcome to the Orb Login System!")
        SendCommandBackward(self, "You Are Attempting To Log In As Administrator: " + self.Username)
    while not loggedin:
        SendCommandBackward(self, "Please Enter The Server Admin Password To Continue:")
        received32 = False
        while not received32 and not self.closing:
            data = RecvPacket2Data(self)
            datalength = data[0]
            try:
                if datalength == -1:
                    SendCommandBackward(self, "The Internet Broke Your Shit! I Didn't Understand That... Try Again Please?")
                if datalength == -2:
                    SendCommandBackward(self, "It seems that your connection sucks, or this servers connection sucks, or you've deliberatly dc'd (I hope!), if not the latter, then we have an issue. Please speak to the server admin about the lag/packet jumbling.")
            except:
                if not self.closing:
                    self.sock.close()
                    self.closing = True
                    return False
            datatype = data[1]
            datapayload = data[2]
            if (datatype == 32):
                received32 = True
                print "got a password from user: " + self.Username
                message_in = Message2String(datapayload)
                self.password = message_in[message_in.find(')')+1:]
                print "password from user " + self.Username + ": " + "*" * 16 #(16 WAS ORIGINALLY PASSWORD LENGTH, BUT THAT COULD PROVE PROBLEMATIC IF IT'S A SHORT PASSWORD!)
                if self.password == ServerInfo.AdminPass:
                    self.result = True
                else:
                    self.result = False
                del self.password ##FOR PROTECTION ONCE THIS PROGRAM BECOMES SEMI-OPEN SOURCE!
                #PLEASE DO THE RIGHT THING AND *NOT* HACK THIS PROGRAM TO GATHER PEOPLES PASSWORDS! THANKS!
                if not self.result:
                    SendCommandBackward(self, "Password Incorrect. Please try again.")
                elif self.result:
                    SendCommandBackward(self, "Sucessfully logged in as: " + self.Username)
                    loggedin = True
                    del self.result
    if loggedin:
        User[self.Username].Info['FeedName'] = message_in[1:message_in.find(')')]
        print str(self.Username) + "'s FeedName:" + User[self.Username].Info['FeedName']
        if User[self.Username].Info["DisplayedName"] == self.Username:
            User[self.Username].Info["DisplayedName"] = User[self.Username].Info['FeedName']
        return True
    else:
        User[self.Username].Info['FeedName'] = self.Username
        return False 
