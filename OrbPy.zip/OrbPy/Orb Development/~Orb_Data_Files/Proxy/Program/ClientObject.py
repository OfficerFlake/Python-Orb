import sys, os

execfile('Proxy/Commands/Logoff.py')

class Client:
    def CreatePlugs(self, newclient):
        #Absolute
        self.server = self #place holder

        #Relative Others
        self.other = self

        #Absolute Sockets
        self.clientsock = newclient
        self.serversock = newclient #place holder

        #Relative Sockets
        self.sock = newclient
        self.other.sock = newclient
        
        self.Username = "USERNAME"
        self.other.Username = self.Username

        self.closing = False
        self.other.closing = False
    def __init__(self, newclient): #Need to send the socket to get data from, and socket to send it to.
        self.CreatePlugs(newclient)
        self.timeouttime = 120
        self.sock.settimeout(self.timeouttime)
        self.closing = False
        self.Flying = False
        self.connect()
        
    def connect(self):
        response = ClientLogin(self)
        if response >= 0:
            self.server = Server(self)
        else:
            return -1

    def sendserver(self, data):
        self.serversock.send(data)

    def sendclient(self, data):
        self.clientsock.send(data)

    def recvserver(self, size):
        return self.serversock.recv(size)

    def recvclient(self, size):
        return self.clientsock.recv(size)

    def close(self):
        self.server.closing = True
        self.closing = True
        #print '(' + self.Username + ' -> ' + self.other.Username + ')', 'told to die'
        #SendCommandForward(self, self.Username + ' has left the server.') #DO NOT ENABLE THIS! THE LOG OFF SCRIPT SUPERCEDES IT!
        print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Logging off'
        Logoff(self)
        try:
            ServerInfo.UsersOnline.remove(self.Username)
            print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Removed self from online user list.'
            ServerInfo.UpdateOnlinePlayers = True
        except:
            pass;
        self.sock.shutdown(2)
        self.sock.close()
        print '(' + self.Username + ' -> ' + self.other.Username + ')', "Client Socket Cleaned."
        self.server.close()
        

    def program(self, null):
        if (Settings.VerboseDebug):
            while not self.closing:
                data = RecvPacket2Data(self)
                if (data[0] == -1) and not self.closing:
                    #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Dropped A Bugged Packet."
                    pass
                elif (data[0] == -2) and not self.closing:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Socket Closed. Cleaning."
                    self.close()
                elif not self.closing:
                    datalength = data[0]
                    datatype = data[1]
                    datapayload = data[2]
                    ProcessPacket(self, datalength, datatype, datapayload);
            print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Thread closed'
        else:
            try:
                while not self.closing:
                    data = RecvPacket2Data(self)
                    if (data[0] == -1) and not self.closing:
                        #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Dropped A Bugged Packet."
                        pass
                    elif (data[0] == -2) and not self.closing:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', "Socket Closed. Cleaning."
                        self.close()
                    elif not self.closing:
                        datalength = data[0]
                        datatype = data[1]
                        datapayload = data[2]
                        ProcessPacket(self, datalength, datatype, datapayload);
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Thread closed'
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]      
                print '''
                WARNING!There has been a bug in the program! (OH NOES!)
                Please submit the following bug report via the bug report page:
                    http://sourceforge.net/p/orbforysflight/tickets/new/
                If you can accuratly reproduce the error, please reperform the error with 'Graceful Debug' turned OFF,
                    then submit the error produced via the same link above.

                Thanks for your report!

                Bug Data:'''
                print "    ", (exc_type, fname, exc_tb.tb_lineno)
                print "\nBecause of this bug, The client:", self.client.Username, "has been disconnected."
                self.close()
