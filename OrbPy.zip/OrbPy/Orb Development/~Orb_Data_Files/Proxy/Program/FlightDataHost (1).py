def FlightDataHost(self, datalength, datatype, datapayload):
##    if True: #Comment This Entire Area Out To Avoid Flight Data Displays.
##        try:
##            test = self.LastFlightTimerID
##        except:
##            self.LastFlightTimerID = 0
##        if unpack("I",datapayload[0:4])[0] - 500000 < self.LastFlightTimerID:
##            return 0
##        else:
##            self.LastFlightTimerID = unpack("I",datapayload[0:4])[0]
    ##Flight Data?
    ##print datapayload
    #print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Flight Data.'
    timer = unpack("I",datapayload[0:4])[0]
    #print 'Timer:', timer
    pilotID = unpack("I",datapayload[4:8])[0]
    #print 'ID:', pilotID
    flightrecordtype = unpack("H",datapayload[8:10])[0]
    #print 'RecordType:', flightrecordtype
    if flightrecordtype != 3:
        if User[self.client.Username].Flight["BeginFlag"] == True:
            User[self.client.Username].FlightStart["xpos"] = unpack("f",datapayload[10:14])[0]
            User[self.client.Username].FlightStart["ypos"] = unpack("f",datapayload[14:18])[0]
            User[self.client.Username].FlightStart["zpos"] = unpack("f",datapayload[18:22])[0]
            User[self.client.Username].FlightStart["yrot"] = unpack("H",datapayload[22:24])[0]
            User[self.client.Username].FlightStart["xrot"] = unpack("H",datapayload[24:26])[0]
            User[self.client.Username].FlightStart["zrot"] = unpack("H",datapayload[26:28])[0]
            User[self.client.Username].FlightStart["xspd"] = unpack("H",datapayload[28:30])[0]
            User[self.client.Username].FlightStart["yspd"] = unpack("H",datapayload[30:32])[0]
            User[self.client.Username].FlightStart["zspd"] = unpack("H",datapayload[32:34])[0]
            User[self.client.Username].Flight["BeginFlag"] = False
            self.other.sock.send(Data2Packet(datatype, datapayload))
            return 0
        if User[self.client.Username].Info["Frozen"]:
            datapayload = datapayload[0:10] + pack("f",User[self.client.Username].Flight["xpos"]) +  pack("f",User[self.client.Username].Flight["ypos"]) +  pack("f",User[self.client.Username].Flight["zpos"]) + pack("H",User[self.client.Username].Flight["yrot"]) + pack("H",User[self.client.Username].Flight["xrot"]) + pack("H",User[self.client.Username].Flight["zrot"]) + "\0\0\0\0\0\0" + datapayload[34:]
            self.other.sock.send(Data2Packet(datatype, datapayload))
            self.sock.send(Data2Packet(datatype, datapayload))
            return 0
        User[self.client.Username].Flight["xpos"] = unpack("f",datapayload[10:14])[0]
        #print 'xPos:', xpos
        User[self.client.Username].Flight["ypos"] = unpack("f",datapayload[14:18])[0]
        #print 'yPos:', ypos
        User[self.client.Username].Flight["zpos"] = unpack("f",datapayload[18:22])[0]
        #print 'zPos:', zpos
        User[self.client.Username].Flight["yrot"] = unpack("H",datapayload[22:24])[0]
        #print 'Heading:', hdg
        User[self.client.Username].Flight["xrot"] = unpack("H",datapayload[24:26])[0]
        #print 'Pitch:', pitch
        User[self.client.Username].Flight["zrot"] = unpack("H",datapayload[26:28])[0]
        #print 'Bank:', bank
        User[self.client.Username].Flight["xspd"] = unpack("H",datapayload[28:30])[0]
        #print 'xSpeed:', xspeed
        User[self.client.Username].Flight["yspd"] = unpack("H",datapayload[30:32])[0]
        #print 'ySpeed:', yspeed
        User[self.client.Username].Flight["zspd"] = unpack("H",datapayload[32:34])[0]
        self.other.sock.send(Data2Packet(datatype, datapayload))
        return 0
        #print 'zSpeed:', zspeed
        accel_pitch = unpack("h",datapayload[34:36])[0]
        #print 'Accel_Pitch:', float(accel_pitch)/32767*360
        accel_yaw = unpack("h",datapayload[36:38])[0]
        return 0
        #print 'Accel_Yaw:', float(accel_yaw)/32767*360
        accel_roll = unpack("h",datapayload[38:40])[0]
        #print 'Accel_Roll:', float(accel_roll)/32767*360
        unknown1 = unpack("H",datapayload[40:42])[0]
        #print 'Unknown1:', unknown1
        fuel = unpack("H",datapayload[42:44])[0]
        #print 'Fuel:', fuel
        unknown2 = unpack("H",datapayload[44:46])[0]
        #print 'Unknown2:', unknown2
        unknown3 = unpack("H",datapayload[46:48])[0]
        #print 'Unknown3:', unknown3
        VGW = unpack("H",datapayload[48:50])[0]
        #print 'VGW:', VGW
        flightdata = unpack("B",datapayload[50:51])[0]
        boards = float(flightdata / 16)/15 * 100
        gear = (flightdata - (flightdata / 16)*16)
        #print 'Boards:', str(boards) + '%'
        if gear > 15 or gear < 0:
            pass
            #print 'Gear: ??? (' + str(gear) + ')'
        elif gear == 15:
            pass
            #print 'Gear: Down (' + str(gear) + ')'
        elif gear >= 10 and gear < 15:
            pass
            #print 'Gear: ### (' + str(gear) + ')'
        elif gear >= 5 and gear < 10:
            pass
            #print 'Gear: ## (' + str(gear) + ')'
        elif gear >= 1 and gear < 5:
            pass
            #print 'Gear: # (' + str(gear) + ')'
        elif gear == 0:
            pass
            #print 'Gear: Up (' + str(gear) + ')'
        flightdata = unpack("B",datapayload[51:52])[0]
        flaps = float(flightdata / 16)/15 * 100
        brake = (flightdata - (flightdata / 16)*16)/15
        #print 'Flaps:', str(flaps) + '%'
        if brake:
            pass
            #print 'Brake: On'
        else:
            pass
            #print 'Brake: Off'
        flightdata = unpack("B",datapayload[52:53])[0]
        #0 - Landing Lights
        #1 - Strobe
        #2 - Nav
        #3 - Beacon
        #4 - Guns
        #5 - Contrails
        #6 - Smoke
        #7 - Burners
        #print 'Raw FlighData:', flightdata
        flightdata = bin(flightdata)
        #print 'Raw FlighData:', flightdata
        if int(flightdata[0]) or int(flightdata[1]) or int(flightdata[2]) or int(flightdata[3]):
            #print 'lights are on.'
            m = 'Lights: On ('
            if int(flightdata[0]):
                m += 'Landing'
            if int(flightdata[1]):
                if len(m) > 12:
                    m += '|'
                m += 'Strobe'
            if int(flightdata[2]):
                if len(m) > 12:
                    m += '|'
                m += 'Nav'
            if int(flightdata[3]):
                if len(m) > 12:
                    m += '|'
                m += 'Beacon'
            #print m + ')'
        else:
            pass
            #print 'Lights: Off'
        if int(flightdata[4]):
            pass
            #print 'Guns: On'
        else:
            pass
            #print 'Guns: Off'
        if int(flightdata[5]):
            #print 'Contrails: On'
            pass
        else:
            #print 'Contrails: Off'
            pass
        if int(flightdata[6]):
            #print 'Smoke: On'
            pass
        else:
            #print 'Smoke: Off'
            pass
        if int(flightdata[7]):
            pass
            #print 'Burners: On'
        else:
            pass
            #print 'Burners: Off'
        unknown = unpack("B",datapayload[53:54])[0]
        #print 'Unknown:', unknown
        gunammo = unpack("H",datapayload[54:56])[0]
        #print 'Gun Ammo:', gunammo
        rockets = unpack("H",datapayload[56:58])[0]
        #print 'Rockets:', rockets
        aam = unpack("B",datapayload[58:59])[0]
        #print 'AAM:', aam
        agm = unpack("B",datapayload[59:60])[0]
        #print 'AGM:', agm
        bombs = unpack("B",datapayload[60:61])[0]
        #print 'Bombs:', bombs
        strength = unpack("B",datapayload[61:62])[0]
        #print 'Strength:', strength
        gforce = unpack("b",datapayload[62:63])[0]
        #print 'gForce:', float(gforce)/10
        throttle = unpack("b",datapayload[63:64])[0]
        #print 'Throttle:', str(float(throttle)/99*100) + '%'
        elevator = unpack("b",datapayload[64:65])[0]
        #print 'Elevator:', str(float(elevator)/99*100) + '%'
        aileron = unpack("b",datapayload[65:66])[0]
        #print 'Aileron:', str(float(aileron)/99*100) + '%'
        rudder = unpack("b",datapayload[66:67])[0]
        #print 'Rudder:', str(float(rudder)/99*100) + '%'
        trim = unpack("b",datapayload[67:68])[0]
        #print 'Trim:', str(float(trim)/99*100) + '%'
        last = unpack("B",datapayload[68:69])[0]
        #print 'Last:', last
        remaining = datapayload[69:]
        if len(remaining) > 0:
            pass
            #print 'Remaining Length:', len(remaining)
            #print 'Remaining:', remaining
    elif flightrecordtype == 3:
        if User[self.client.Username].Flight["BeginFlag"] == True:
            User[self.client.Username].FlightStart["xpos"] = unpack("f",datapayload[12:16])[0]
            User[self.client.Username].FlightStart["ypos"] = unpack("f",datapayload[16:20])[0]
            User[self.client.Username].FlightStart["zpos"] = unpack("f",datapayload[20:24])[0]
            User[self.client.Username].FlightStart["yrot"] = unpack("H",datapayload[24:26])[0]
            User[self.client.Username].FlightStart["xrot"] = unpack("H",datapayload[26:28])[0]
            User[self.client.Username].FlightStart["zrot"] = unpack("H",datapayload[28:30])[0]
            User[self.client.Username].FlightStart["xspd"] = unpack("H",datapayload[30:32])[0]
            User[self.client.Username].FlightStart["yspd"] = unpack("H",datapayload[32:34])[0]
            User[self.client.Username].FlightStart["zspd"] = unpack("H",datapayload[34:36])[0]
            User[self.client.Username].Flight["BeginFlag"] = False
            self.other.sock.send(Data2Packet(datatype, datapayload))
            return 0
        if User[self.client.Username].Info["Frozen"]:
            datapayload = datapayload[0:12] + pack("f",User[self.client.Username].Flight["xpos"]) +  pack("f",User[self.client.Username].Flight["ypos"]) +  pack("f",User[self.client.Username].Flight["zpos"]) + pack("H",User[self.client.Username].Flight["yrot"]) + pack("H",User[self.client.Username].Flight["xrot"]) + pack("H",User[self.client.Username].Flight["zrot"]) + "\0\0\0\0\0\0" + datapayload[36:]
            self.other.sock.send(Data2Packet(datatype, datapayload))
            #self.sock.send(Data2Packet(datatype, datapayload)) #THIS IS NOT WORKING?
            return 0
        PivotZX = unpack("h",datapayload[10:12])[0]
        #print 'PivotZX:', PivotZX
        User[self.client.Username].Flight["xpos"] = unpack("f",datapayload[12:16])[0]
        #print 'xPos:', xpos
        User[self.client.Username].Flight["ypos"] = unpack("f",datapayload[16:20])[0]
        #print 'yPos:', ypos
        User[self.client.Username].Flight["zpos"] = unpack("f",datapayload[20:24])[0]
        #print 'zPos:', zpos
        User[self.client.Username].Flight["yrot"] = unpack("H",datapayload[24:26])[0]
        #print 'Heading:', hdg
        User[self.client.Username].Flight["xrot"] = unpack("H",datapayload[26:28])[0]
        #print 'Pitch:', pitch
        User[self.client.Username].Flight["zrot"] = unpack("H",datapayload[28:30])[0]
        #print 'Bank:', bank
        User[self.client.Username].Flight["xspd"] = unpack("H",datapayload[30:32])[0]
        #print 'xSpeed:', xspeed
        User[self.client.Username].Flight["yspd"] = unpack("H",datapayload[32:34])[0]
        #print 'ySpeed:', yspeed
        User[self.client.Username].Flight["zspd"] = unpack("H",datapayload[34:36])[0]
        #print 'zSpeed:', zspeed
        self.other.sock.send(Data2Packet(datatype, datapayload))
        return 0
        accel_pitch = unpack("h",datapayload[36:38])[0]
        #print 'Accel_Pitch:', float(accel_pitch)/32767*360
        accel_yaw = unpack("H",datapayload[38:40])[0]
        #print 'Accel_Yaw:', float(accel_yaw)/32767*360
        accel_roll = unpack("H",datapayload[40:42])[0]
        #print 'Accel_Roll:', float(accel_roll)/32767*360
        gForce = unpack("h",datapayload[42:44])[0]
        #print 'gForce:', float(gForce)/32767*360
        GunAmmo = unpack("H",datapayload[44:46])[0]
        #print 'GunAmmo:', GunAmmo
        AAM = unpack("H",datapayload[46:48])[0]
        #print 'AAM:', AAM
        AGM = unpack("H",datapayload[48:50])[0]
        #print 'AGM:', AGM
        B500 = unpack("H",datapayload[50:52])[0]
        #print 'B500:', B500
        Smoke = unpack("H",datapayload[52:54])[0]
        #print 'Smoke:', Smoke
##        boards = float(flightdata / 16)/15 * 100
##        gear = (flightdata - (flightdata / 16)*16)
##        #print 'Boards:', str(boards) + '%'
##        return 0
##        if gear > 15 or gear < 0:
##            #print 'Gear: ??? (' + str(gear) + ')'
##        elif gear == 15:
##            #print 'Gear: Down (' + str(gear) + ')'
##        elif gear >= 10 and gear < 15:
##            #print 'Gear: ### (' + str(gear) + ')'
##        elif gear >= 5 and gear < 10:
##            #print 'Gear: ## (' + str(gear) + ')'
##        elif gear >= 1 and gear < 5:
##            #print 'Gear: # (' + str(gear) + ')'
##        elif gear == 0:
##            #print 'Gear: Up (' + str(gear) + ')'
##        throttle = unpack("b",datapayload[72:73])[0]
##        #print 'Throttle:', str(float(throttle)/99*100) + '%'
##        elevator = unpack("b",datapayload[73:74])[0]
##        #print 'Elevator:', str(float(elevator)/99*100) + '%'
##        aileron = unpack("b",datapayload[74:75])[0]
##        #print 'Aileron:', str(float(aileron)/99*100) + '%'
##        rudder = unpack("b",datapayload[75:76])[0]
##        #print 'Rudder:', str(float(rudder)/99*100) + '%'
##        trim = unpack("b",datapayload[76:77])[0]
##        #print 'Trim:', str(float(trim)/99*100) + '%'
##        flightdata = unpack("H",datapayload[77:79])[0]
##        #print 'SHIT NIGGA:', flightdata
##        #print 'lol:', datapayload[77:81]
##        #x = chr(255)
##        #y = chr(255)
##        #datapayload = datapayload[0:54] + x + y + datapayload[56:]
##        remaining = datapayload[81:]
##        if len(remaining) > 0:
##            #print 'Remaining Length:', len(remaining)
##            #print 'Remaining:', remaining
##        self.other.sock.send(Data2Packet(datatype, datapayload))
##        return 0
##        flaps = float(flightdata / 16)/15 * 100
##        brake = (flightdata - (flightdata / 16)*16)/15
##        #print 'Flaps:', str(flaps) + '%'
##        if brake:
##            #print 'Brake: On'
##        else:
##            #print 'Brake: Off'
        flightdata = unpack("B",datapayload[54:55])[0]
        #0 - Landing Lights
        #1 - Strobe
        #2 - Nav
        #3 - Beacon
        #4 - Guns
        #5 - Contrails
        #6 - Smoke
        #7 - Burners
        ##print 'Raw Flight Data:', flightdata
        flightdata = bin(flightdata)
        ##print 'Raw Flight Data:', flightdata
        if int(flightdata[0]) or int(flightdata[1]) or int(flightdata[2]) or int(flightdata[3]):
            ##print 'lights are on.'
            m = 'Lights: On ('
            if int(flightdata[0]):
                m += 'Landing'
            if int(flightdata[1]):
                if len(m) > 12:
                    m += '|'
                m += 'Strobe'
            if int(flightdata[2]):
                if len(m) > 12:
                    m += '|'
                m += 'Nav'
            if int(flightdata[3]):
                if len(m) > 12:
                    m += '|'
                m += 'Beacon'
            #print m + ')'
        else:
            #print 'Lights: Off'
            pass
        if int(flightdata[4]):
            #print 'Guns: On'
            pass
        else:
            #print 'Guns: Off'
            pass
        if int(flightdata[5]):
            #print 'Contrails: On'
            pass
        else:
            #print 'Contrails: Off'
            pass
        if int(flightdata[6]):
            #print 'Smoke: On'
            pass
        else:
            #print 'Smoke: Off'
            pass
        if int(flightdata[7]):
            #print 'Burners: On'
            pass
        else:
            #print 'Burners: Off'
            pass
        PivotXY = unpack("B",datapayload[55:56])[0]
        #print 'PivotXY:', PivotXY
        gunammo = unpack("H",datapayload[56:58])[0]
        #print 'Gun Ammo:', gunammo
        rockets = unpack("H",datapayload[58:60])[0]
        #print 'Rockets:', rockets
        aam = unpack("B",datapayload[60:61])[0]
        #print 'AAM:', aam
        agm = unpack("B",datapayload[61:62])[0]
        #print 'AGM:', agm
        bombs = unpack("B",datapayload[62:63])[0]
        #print 'Bombs:', bombs
        strength = unpack("H",datapayload[63:65])[0]
        #print 'Strength:', strength
        gforce = unpack("b",datapayload[65:66])[0]
        #print 'gForce:', float(gforce)/10
        throttle = unpack("b",datapayload[66:67])[0]
        #print 'Throttle:', str(float(throttle)/99*100) + '%'
        elevator = unpack("b",datapayload[67:68])[0]
        #print 'Elevator:', str(float(elevator)/99*100) + '%'
        aileron = unpack("b",datapayload[68:69])[0]
        #print 'Aileron:', str(float(aileron)/99*100) + '%'
        rudder = unpack("b",datapayload[69:70])[0]
        #print 'Rudder:', str(float(rudder)/99*100) + '%'
        trim = unpack("b",datapayload[70:71])[0]
        #print 'Trim:', str(float(trim)/99*100) + '%'
        last = unpack("B",datapayload[71:72])[0]
        #print 'Last:', last
        remaining = datapayload[72:]
        if len(remaining) > 0:
            #print 'Remaining Length:', len(remaining)
            #print 'Remaining:', remaining
            pass
    self.other.sock.send(Data2Packet(datatype, datapayload))
