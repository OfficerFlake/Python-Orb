import random
import math

def FlightDataHostTest(self, datalength, datatype, datapayload):
    if unpack("H",datapayload[8:10])[0] != 3:
        self.other.sock.send(Data2Packet(datatype, datapayload))
        return 0
    else:
        datapayload = datapayload[0:55] + chr(math.floor(random.random()*255)) + datapayload[56:]
        self.other.sock.send(Data2Packet(datatype, datapayload))
        return 0
                                                
