def SendCommandConfirmation(self, message_in):
    ##Function Not Used?
    try:
        self.sock.send(Data2Packet(datatype, String2Message("*(" + self.username + ")" + message_in)))
    except:
        pass #socket closed.

def SendCommandForward(self, message_out):
    try:
        self.other.sock.send(Data2Packet(32, String2Message(message_out)))
    except:
        pass #socket closed.
    
def SendCommandBackward(self, message_out):
    try:
        self.sock.send(Data2Packet(32, String2Message(message_out)))
    except:
        pass #socket closed.
    
def String2Message(data):
    try:
        return pack("8s" + str(len(data)) + "s" + "1s", "\0", data, "\0")
    except:
        return pack("8s" + str(len("\0")) + "s" + "1s", "\0", "\0", "\0")
        pass #socket closed.
    
def String2Data(data):
    try:
        return len(pack("8s" + str(len(data)) + "s" + "1s", "\0", data, "\0"))+4, 32, pack("8s" + str(len(data)) + "s" + "1s", "\0", data, "\0")
    except:
        return len(pack("8s" + str(len("\0")) + "s" + "1s", "\0", "\0", "\0"))+4, 32, pack("8s" + str(len("\0")) + "s" + "1s", "\0", "\0", "\0")
        pass #socket closed.
    
def Message2String(data):
    try:
        data = unpack(str(len(data)) + "s", data)[0]
        return data.strip("\0")
    except:
        return ""
        pass #socket closed.

def SendString(self, data):
    try:
        self.sock.send(Data2Packet(32,String2Message(data)))
    except:
        pass #socket closed.

def RecvString(self, data):
    try:
        return Message2String(RecvPacket2Data(self.sock)[2])
    except:
        return ""
        pass #socket closed.
