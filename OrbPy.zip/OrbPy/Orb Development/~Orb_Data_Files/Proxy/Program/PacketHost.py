import imp

execfile('./Proxy/Program/FlightDataHost.py')
execfile('./Proxy/Program/FlightDataTester.py')

def ProcessPacket(self, datalength, datatype, datapayload):
    try:
        if datalength < 0:
            return -1
        #print "in the process system"
        if (datatype == 0):
            return 0, "" 
        elif (datatype == 4):
            try:
                ##Map.
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Map Name."
                #print "    Load:", unpack(str(len(datapayload)) + "s",datapayload)[0]
                #print "    Hex:", Packet2Hex(datapayload)
                #print 'End Map Name'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 5):
            try:
                ##Entity Joins.
    ##            print 'got some sort of reply packet?'
    ##            print "Length: " + str(datalength)
    ##            print "Type: " + str(datatype)
    ##            print "Load: " + str(datapayload)
    ##            print "length of load:", str(len(datapayload))
    ##            try:
    ##                print "int 1:", str(unpack("I",datapayload[0:4])[0])
    ##                print "int 2:", str(unpack("I",datapayload[4:8])[0])
    ##            except:
    ##                pass
                try:
                    #print 'Spawn Entity'
                    #print 'Loadout for Aircraft/Ground Spawn'
                    #print 'Full Packet: $' + str(datapayload) + '$'
                    entitytype = unpack("I",datapayload[0:4])[0]
                    #print 'type: $' + str(entitytype) + '$'
                    entityid = unpack("I",datapayload[4:8])[0]
                    #print 'id: $' + str(entityid) + '$'
                    entityiff = unpack("I",datapayload[8:12])[0]
                    #print 'iff: $' + str(entityiff) + '$'
                    entityspawnxpos = unpack("f",datapayload[12:16])[0]
                    #print 'xpos: $' + str(entityspawnxpos) + '$'
                    entityspawnypos = unpack("f",datapayload[16:20])[0]
                    #print 'ypos: $' + str(entityspawnypos) + '$'
                    entityspawnzpos = unpack("f",datapayload[20:24])[0]
                    #print 'zpos: $' + str(entityspawnzpos) + '$'
                    entityspawnxrot = unpack("f",datapayload[24:28])[0]
                    #print 'xrot: $' + str(entityspawnxrot) + '$'
                    entityspawnyrot = unpack("f",datapayload[28:32])[0]
                    #print 'yrot: $' + str(entityspawnyrot) + '$'
                    entityspawnzrot = unpack("f",datapayload[32:36])[0]
                    #print 'zrot: $' + str(entityspawnzrot) + '$'
                    entityname = unpack("64s",datapayload[36:100])[0]
                    entityname = entityname.strip('\0')
                    #print 'name: $' + str(entityname) + '$'
                    entitygroid = unpack("I",datapayload[100:104])[0]
                    #print 'groid: $' + str(entitygroid) + '$'
                    entitygroflag = unpack("I",datapayload[104:108])[0]
                    #print 'flag: $' + str(entitygroflag) + '$'
                    entityunknown1 = unpack("16s",datapayload[108:124])[0]
                    #print '???: $' + str(entityunknown1) + '$'
                    entityusername = unpack(str(len(datapayload[124:])) + "s",datapayload[124:])[0]
                    entityusername = entityusername.strip('\0')
                    #print 'username: $' + str(entityusername) + '$'
                    if entitytype == 0:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', 'joined flight in aircraft:', entityname, '\n    with ID:', entityid, 'IFF:', entityiff+1
                        User[self.client.Username].Flight["ID"] = entityid
                        User[self.client.Username].Flight["IFF"] = entityIFF
                        User[self.client.Username].Flight["xpos"] = 0.0
                        User[self.client.Username].Flight["ypos"] = 0.0
                        User[self.client.Username].Flight["zpos"] = 0.0
                        User[self.client.Username].Flight["xrot"] = 0.0
                        User[self.client.Username].Flight["yrot"] = 0.0
                        User[self.client.Username].Flight["zrot"] = 0.0
                        User[self.client.Username].Flight["xspd"] = 0.0
                        User[self.client.Username].Flight["yspd"] = 0.0
                        User[self.client.Username].Flight["zspd"] = 0.0
                        User[self.client.Username].Flight["Aircraft"] = entityname
                        User[self.client.Username].Flight["GroundID"] = 0
                        User[self.client.Username].Flight["Flag"] = 0
                        User[self.client.Username].Info["FlightsFlown"] += 1
                        User[self.client.Username].Flight["BeginFlag"] = True
                        self.client.Flying = True
                    elif entitytype == 65537:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Spawned ground object:', entityname, '\n    with ID:', entityid, 'IFF:', entityiff+1
                    #print str(len(datapayload[124:]))
                except:
                    pass
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 6):
            try:
                ##Reply?        
                #print 'got some sort of reply packet?'
                #print "Length: " + str(datalength)
                #print "Type: " + str(datatype)
                #print "Load: " + str(datapayload)
                #print "length of load:", str(len(datapayload))
                try:
                    ack1 = unpack("I",datapayload[0:4])[0]
                    ack2 = unpack("I",datapayload[4:8])[0]
                except:
                    pass
##                if ack1 == 9:
##                    print ack2
##                    print ServerInfo.WeaponsEnabledDefault
##                    ack2 == ServerInfo.WeaponsEnabledDefault
                #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Acknowledge:", str(ack1) + ',', str(ack2)
                #print Packet2Hex(datapayload)
                #print Packet2Hex(pack("I", ack1) + pack("I", ack2))
                self.other.sock.send(Data2Packet(datatype, pack("I", ack1) + pack("I", ack2)))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 7):
            try:
                ##Reply?
    ##            print 'got some sort of reply packet?'
    ##            print "Length: " + str(datalength)
    ##            print "Type: " + str(datatype)
    ##            print "Load: " + str(datapayload)
    ##            print "length of load:", str(len(datapayload))
    ##            try:
    ##                print "int 1:", str(unpack("I",datapayload[0:4])[0])
    ##                print "int 2:", str(unpack("I",datapayload[4:8])[0])
    ##            except:
    ##                pass
                entityid = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Acknowledges The Join Of ID:', str(entityid)
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 8):
            try:
                ##Join Flight Packet.
                if (User[self.Username].Info["Frozen"] >= 1):
                    m = "You are frozen and thus unable to join flight."
                    SendCommandBackward(User[self.Username].Info["ClientID"], m)
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sent A Join Request.'
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Join Request Rejected: Frozen.'
                    #self.other.sock.send(Data2Packet(datatype, datapayload))
                    self.sock.send(Data2Packet(6, pack("II",5,0)))
                    self.sock.send(Data2Packet(10, ''))
                else:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sent A Join Request.'
                    #print datapayload
                    self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 9):
            try:
                ##Approve Flight?
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Join Request Approved.'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 10):
            try:
                ##Deny Flight/Reject Request?
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Join Request Rejected.'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 11):
            try:
                FlightDataHost(self, datalength, datatype, datapayload)
            except:
                print 'Error'
                print sys.exc_info()
                pass;
        elif (datatype == 12):
            try:
                ##Self Terminate Flight?
                ident = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', ident, 'Ends Own Flight.'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 13):
            try:
                ##Aircraft Leaves Flight.
                endid = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', endid, 'Ends Flight.'
                for username in ServerInfo.UsersOnline:
                    #print username
                    #print User[username].Flight['ID']
                    #print endid
                    if (User[username].Flight['ID'] == endid) and (self.other == self.client):
                        #print "Matching"
                        #print '    Assist List: ', User[username].Kills["Assist"]
                        #print '    Last Assist: ', User[username].Kills["LastAssist"]
                        try:
                            test = User[User[username].Kills["LastAssist"]].Info["Kills"]
                            test = User[User[username].Kills["LastAssist"]].Info['DisplayedName']
                            if User[username].Kills["LastAssist"] == username:
                                m = 'You Commited Suicide!'
                                #print m
                                SendCommandBackward(User[username].Info["ClientID"], m)
                            User[User[username].Kills["LastAssist"]].Info["Kills"] += 1
                            m = 'Killed: ' + User[username].Info['DisplayedName'] + '. +100'
                            #print m
                            SendCommandBackward(User[User[username].Kills["LastAssist"]].Info["ClientID"], m)
                            m = 'Killed By: ' + User[User[username].Kills["LastAssist"]].Info['DisplayedName']
                            print m
                            SendCommandBackward(User[username].Info["ClientID"], m)
                            print '"' + username + '"Kills "' + User[username].Kills["LastAssist"] + '".'
                        except:
                            pass #list is empty.
                        for username2 in ServerInfo.UsersOnline:
                            if (username2 != User[username].Kills["LastAssist"]):
                                try:
                                    test = User[username].Kills["Assist"].index(username2)
                                    if User[username].Kills["Assist"].index(username2) == self.client.Username:
                                        pass
                                    else:
                                        m = 'Kill Assist:' + User[username].Info['DisplayedName'] + '. +20'
                                        #print m
                                        SendCommandBackward(User[username2].Info["ClientID"], m)
                                except:
                                    pass #not in the list
                        if not len(User[username].Kills["Assist"]) == 0 and len(User[username].Kills["LastAssist"]) == 0:
                            User[username].Info["Deaths"] += 1
##                        elif 0: #0 -> TotalSpeed(self) > 0:
##                            if 0: #0 -> Ejected(self):
##                                pass #pass -> spawn paratrooper
##                            else:
##                                User[self.client.Username].Info["Deaths"] += 1
                        #print "Wiping Data"
                        User[username].Kills["Assist"] = []
                        User[username].Kills["LastAssist"] = ''
                        User[username].FlightStart["ID"] = 0
                        User[username].FlightStart["IFF"] = 0
                        User[username].FlightStart["xpos"] = 0.0
                        User[username].FlightStart["ypos"] = 0.0
                        User[username].FlightStart["zpos"] = 0.0
                        User[username].FlightStart["xrot"] = 0.0
                        User[username].FlightStart["yrot"] = 0.0
                        User[username].FlightStart["zrot"] = 0.0
                        User[username].FlightStart["xspd"] = 0.0
                        User[username].FlightStart["yspd"] = 0.0
                        User[username].FlightStart["zspd"] = 0.0
                        User[username].FlightStart["Aircraft"] = ""
                        User[username].FlightStart["GroundID"] = 0
                        User[username].FlightStart["Flag"] = 0
                        User[username].Flight["ID"] = 0
                        User[username].Flight["IFF"] = 0
                        User[username].Flight["xpos"] = 0.0
                        User[username].Flight["ypos"] = 0.0
                        User[username].Flight["zpos"] = 0.0
                        User[username].Flight["xrot"] = 0.0
                        User[username].Flight["yrot"] = 0.0
                        User[username].Flight["zrot"] = 0.0
                        User[username].Flight["xspd"] = 0.0
                        User[username].Flight["yspd"] = 0.0
                        User[username].Flight["zspd"] = 0.0
                        User[username].Flight["Aircraft"] = ""
                        User[username].Flight["GroundID"] = 0
                        User[username].Flight["Flag"] = 0
                        User[username].Flying = False
                        #print '    Data Reset For:', username
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 16):
            ##End Aircraft List
            print '(' + self.Username + ' -> ' + self.other.Username + ')', "End Aircraft List"
            if self.client.Username.lower() == 'php bot':
                #PHP Bot does NOT need anything else. We force it to DC to avoid players joining as 'PHP Bot' and sneaking in. ;)
                m = 'As previously arranged, You have been automatically disconnected from the server now that you have completed downloading the server list.\nThanks for visiting the server, anonymous robot-san! :3\n\n    - Orb'
                SendCommandForward(self, m)
                self.client.close()
            else:
                try:
                    #SendCommandForward(self, ServerInfo.LogonMessage) #LogonComplete message here!
                    self.other.sock.send(Data2Packet(datatype, datapayload))
                except:
                    pass;
        elif (datatype == 17):
            try:
                ##Keep Alive Packet.
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 18):
            try:
                ##Locked Target.
                KillerID = unpack("I",datapayload[0:4])[0]
                KillerType =  unpack("I",datapayload[4:8])[0]
                VictimID = unpack("I",datapayload[8:12])[0]
                if VictimID == 4294967295: #returns ff:ff:ff:ff is NOTHING is locked.
                    VictimID = 'null'
                VictimType = unpack("I",datapayload[12:16])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', KillerID, "Locks onto", VictimID
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 19):
            try:
                ##Ground Destroyed.
                groid = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Ground Destroyed:', groid
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 20):
            try:
                ##Explosion/Flare Packet.
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sent An Explosion, Flare or Ordinance Packet."
                #print "    Load: " + str(datapayload)
                #print "    Hex: " + Packet2Hex(datapayload)
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 21):
            try:
                ##Acknowledge Packet?
                #print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sent An Acknowledgement/Keepalive.'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 22):
            try:
                if self.Username == self.client.Username:
                    if User[self.Username].Info["Frozen"] >= 1:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', "Damage Signal Rejected (Frozen)"
                        return 0
                ##Damage Packet.
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sent A Damage Signal"
                #print datapayload
                victimtype = unpack("I",datapayload[0:4])[0]
                print 'Victim Type:', victimtype
                victimid = unpack("I",datapayload[4:8])[0]
                print 'Victim ID:', victimid
                killertype = unpack("I",datapayload[8:12])[0]
                print 'Killer Type', killertype
                damageammount = unpack("H",datapayload[12:14])[0]
                print 'Damage Amount:', damageammount
                damagetype = unpack("H",datapayload[14:16])[0]
                print 'Damage Type:', damagetype
                weaponused = unpack("H",datapayload[16:18])[0]
                print 'Weapon Used', weaponused
                unknown = unpack("I",datapayload[18:22])[0]
                print '???:', unknown, datapayload[18:22]
                victimname = ''
                killername = ''
                #print self.Username
                #print self.client.Username
                if (self == self.client):
                    for username in ServerInfo.UsersOnline:
                        #print username
                        if (str(User[username].Flight['ID']) == str(victimid)):
                            victimname = username
                            #print 'Victim:', username
                        if (username == self.client.Username):
                            killername = username
                            #print 'Killer:', username
                    if (victimname != '') and (killername != ''):
                        try:
                            test = User[victimname].Kills["Assist"].index(killername)
                        except:
                            User[victimname].Kills["Assist"].append(killername)
                            #print 'Added the killer,', killername, ', to the assist list of:', victimname
                        User[victimname].Kills["LastAssist"] = killername
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 29):
            try:
                ##YSFVersion.
                version = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "YSFlight Version:", version
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 30):
            #Set Air Commands
            try:
                #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sent An Air Command"
                #print datapayload
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 31):
            try:
                ##Missile Rules
                missilesenabled = unpack("I",datapayload[0:4])[0]
                if missilesenabled == 1:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Missiles Enabled"
                else:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Missiles Disabled"
                try:
                    test = ServerInfo.MissilesEnabledDefault
                except:
                    ServerInfo.MissilesEnabledDefault = missilesenabled
                if self.other.sock == self.client.sock:
                    print "    Setting Was: " + str(missilesenabled) + ", Replaced with: " + str(ServerInfo.MissilesEnabled)
                    self.other.sock.send(Data2Packet(31, pack("I", ServerInfo.MissilesEnabled)))
                else:
                    self.other.sock.send(Data2Packet(31, pack("I", ServerInfo.MissilesEnabledDefault)))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 32):
            try:
                if self.client.Username.lower() == 'php bot':
                    #PHP bot does NOT need to hear anything from the server. We stop the server sending it info to avoid spy issues.
                    return 0
                if self == self.server:
                    message_in = Message2String(datapayload)
                    message_out = message_in
                    message_in = message_in[len(self.Username)+2:]
                    Type32(self, message_in, message_out);
                    return 0
                #print "got type 32"
                message_in = Message2String(datapayload)
                #print message_in
                #print User[self.Username].Info['FeedName']
                #print len(User[self.Username].Info['FeedName'])
                #print len(User[self.Username].Info['FeedName'])+2
                message_out = message_in
                message_in = message_in[len(User[self.Username].Info['FeedName'])+2:]
                #print self.Username
                #print str((len(User[self.Username].Info['FeedName'])+2))
                #print "command: '" + message_in + "'"
                #print message_in
                Type32(self, message_in, message_out);
                #print "ready to return"
            except Exception, ex:
                print 'Error Parsing Message.\n'
                print ex
        elif (datatype == 33):
            ##Weather.
            try:
                if self == self.client:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weather Request."
                elif self == self.server:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weather."
                    daynight = unpack("I",datapayload[0:4])[0]
                    options = unpack("I",datapayload[4:8])[0]
                    options = bin(options)
                    windx = unpack("f",datapayload[8:12])[0]
                    windy = unpack("f",datapayload[12:16])[0]
                    windz = unpack("f",datapayload[16:20])[0]
                    fog = unpack("f",datapayload[20:24])[0]
                    print '    DayEnabled:', daynight
                    print '    BlackoutEnabled:', options[5]
                    print '    LandEverywhere:', options[1]
                    print '    CollisionsEnabled:', options[3]
                    print '    WindX:', windx
                    print '    WindY:', windy
                    print '    WindZ:', windz
                    print '    Fog:', fog
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass
        elif (datatype == 36):
            try:
                ##Weapon Loading
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weapon Loadout:"
                try:
                    entityid = unpack("I",datapayload[0:4])[0]
                    unknown = unpack("H",datapayload[4:6])[0]
                    #print "ID: $" + str(entityid) + "$"
                    #print "Unknown(2?): $" + str(unknown) + "$"
                    i = 6
                    while i <= len(datapayload)-4:
                        entitytype = unpack("H",datapayload[i:i+2])[0]
                        #print entitytype
                        entityload = unpack("H",datapayload[i+2:i+4])[0]
                        #print entityload
                        if (entitytype == 1):
                            print "    AAM(Short): " + str(entityload)
                        elif (entitytype == 2):
                            print "    AGM: " + str(entityload)
                        elif (entitytype == 3):
                            print "    Bomb(500lb): " + str(entityload)
                        elif (entitytype == 4):
                            print "    Rocket: " + str(entityload)
                        elif (entitytype == 6):
                            print "    AAM(Mid): " + str(entityload)
                        elif (entitytype == 7):
                            print "    Bomb(250lb): " + str(entityload)
			elif (entitytype == 8):
                            print "    Smoke: " + str(entityload)
                        elif (entitytype == 9):
                            print "    Bomb-HD(500lb): " + str(entityload)
                        elif (entitytype == 10):
                            print "    A-AAM(Short): " + str(entityload)
                        elif (entitytype == 12):
                            print "    Fuel Tank: " + str(entityload)
                        elif (entitytype == 200):
                            print "    Flare: " + str(entityload)
                        else:
                            print "    Unknown Type(" + str(entitytype) + "): " + str(entityload)
                        i += 4
                except:
                    print sys.exc_info()
                    pass
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 37):
            ##User List
            if (self == self.client):
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sends A List Request.'
                if self.client.Username.lower() == 'php bot':
                    self.other.sock.send(Data2Packet(datatype, datapayload))
                else:
                    #self.other.sock.send(Data2Packet(datatype, datapayload))
                    Players(self)
            elif (self == self.server):
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sends User Data.'
                try:
                    if (len(datapayload) >= 12):
                        temp = unpack("hhII" + str((len(datapayload)-12)) + "s", datapayload)
                        if temp[4].strip('\0') == self.server.Username:
                            self.other.sock.send(Data2Packet(datatype, datapayload))
                        self.other.sock.send(Data2Packet(datatype, datapayload))
                        #elif not User[temp[4].strip('\0')].Info["Hidden"]:
                            #self.other.sock.send(Data2Packet(datatype, datapayload))
                    else:
                        pass
                        #empty packet?
                except Exception, ex:
                    print ex
                    pass
        elif (datatype == 38):
            try:
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Query Airstate:'
                number = unpack("I",datapayload[0:4])[0]
                print "    Load: " + str(datapayload)
                print "    Hex: " + Packet2Hex(datapayload)
                print '    Number Of Aircraft:', number
            except:
                print sys.exc_info()
            try:
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
        elif (datatype == 39):
            try:
                ##Weapon Rules.
                state = unpack("I",datapayload[0:4])[0]
                if state == 0:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weapons Disabled" 
                elif state == 1:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weapons Enabled"
                try:
                    test = ServerInfo.WeaponsEnabledDefault
                except:
                    ServerInfo.WeaponsEnabledDefault = state
                if self.other.sock == self.client.sock:
                    print "    Was: " + str(state) + ", Replaced with: "  + str(ServerInfo.WeaponsEnabled)
                    self.other.sock.send(Data2Packet(39, pack("I", ServerInfo.WeaponsEnabled)))
                else:
                    self.other.sock.send(Data2Packet(39, pack("I", ServerInfo.WeaponsEnabledDefault)))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 40):
            try:
                ##Rotatable Turret Data.
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 41):
            try:
                ##Username Distance.
                distance = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Set Username Distance:", distance
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 43):
            ##Misc Command.
            try:
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sends a Misc Command"
                print '    ', datapayload[4:]
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 44):
            ##Aircraft List
            try:
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sends Aircraft List"
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 46):
            #Kill Confirmation
            try:
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Earned A Kill.'
                print 'VictimType:', unpack("I",datapayload[0:4])[0]
                print 'KillerType:', unpack("I",datapayload[4:8])[0]
                print '???:', unpack("I",datapayload[8:12])[0], datapayload[8:12], Packet2Hex(datapayload[8:12])
                print '???:', unpack("I",datapayload[12:16])[0], datapayload[12:16], Packet2Hex(datapayload[12:16])
                print 'UniqueKillID:', unpack("I",datapayload[16:20])[0], datapayload[16:20], Packet2Hex(datapayload[16:20])
                print 'Junk:', unpack("I",datapayload[20:24])[0]
                print 'KillerID:', unpack("I",datapayload[24:28])[0]
                print 'KillerName:', unpack("32s",datapayload[28:60])[0]
                print 'KillerObject:', unpack("32s",datapayload[60:92])[0]
                print 'Junk:', unpack("I",datapayload[92:96])[0]
                print 'VictimID:', unpack("I",datapayload[96:100])[0]
                print 'VictimName:', unpack("32s",datapayload[100:132])[0]
                print 'VictimObject:', unpack("32s",datapayload[132:164])[0]
                #self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
            # aircraft list
        #print self.other
        #print self.self
        else:
            try:
                print "Undeclared Packet Type. No action taken on packet:"
                print "Length: " + str(datalength)
                print "Type: " + str(datatype)
                print "Load: " + str(datapayload)
                print "Hex: " + Packet2Hex(datapayload)
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        #print "send the data away"
    except:
        print sys.exc_info()
        pass
