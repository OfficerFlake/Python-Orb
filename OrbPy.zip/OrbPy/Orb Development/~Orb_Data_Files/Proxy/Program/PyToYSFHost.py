import select
import errno

def RecvPacket2Data(self):
    try:
        test = overflow
    except:
        overflow = ''
    try:
        test = error
    except:
        error = 0
    try:
        datalength = 0
        if len(overflow) == 0:
            buffer_data = self.sock.recv(4)
        else:
            buffer_data = overflow[0:4]
            overflow = overflow[4:]
        #print buffer_data
        #print len(buffer_data)
        if (len(buffer_data) <= 0) and not self.closing:
            #print "Data error: socket returns no data. Client Dc'd?"
            error += 1
            if error > 1:
                error = 0
                print "Something went wrong twice in a row. This probably means the client has disconnected, or the internet is really crap today... Sorry if I'm wrong!"
                return -2, -2, -2
            else:
                return -1, -1, -1
        if self.closing:
            return -2, -2, -2
        datalength = unpack("I",buffer_data[0:4])[0]
        #print "Expected length: " + str(datalength)
        #buffer_data = overflow
        if len(overflow) == 0:
            buffer_data = self.sock.recv(datalength)
        else:
            buffer_data = self.sock.recv(datalength - len(overflow))
            overflow = ''
        #print "Length received: " + str(len(buffer_data))
        #print Packet2Hex(buffer_data)
        while len(buffer_data) < datalength and not self.closing:
            if Settings.VerboseDebug:
                print "TCP/IP Protocal broke a Packet into pieces. Reconstructing..."
            #print len(buffer_data)
            #print datalength
            buffer_data += self.sock.recv(datalength - len(buffer_data))
        if len(buffer_data) > datalength and not self.closing:
            if Settings.VerboseDebug:
                print "TCP/IP Protocal broke a Packet into pieces. Reconstructing..."
            overflow = buffer_data[datalength:]
        #overflow = buffer_data[datalength:]
        #buffer_data = buffer_data[0:datalength]
        #if len(buffer_data) != datalength and not self.closing:
        #    print "data error: packet size received is not the correct size expected."
        #    error += 1
        #    if error > 1:
        #        print 'The overflow is causing an error... Flushing It.'
        #        #flush the buffer!
        #        try:
        #            overflow = self.sock.recv(8192)
        #        except:
        #            print 'Buffer Flush Overflow'
        #        overflow = ''
        #    return -1, -1, -1
        #print buffer_data
        #print len(buffer_data)
        #print buffer_data[0:4]
        #print len(buffer_data[0:4])
        if not self.closing and len(buffer_data) >= 4:
            datatype = unpack("I",buffer_data[0:4])[0]
            #print "type: " + str(datatype)
            datapayload = unpack(str(datalength-4) + "s",buffer_data[4:])[0]
            #print "load: " + datapayload
            #print "loadsize: " + str(len(datapayload))
            return datalength, datatype, datapayload
        else:
            return -1, -1, -1
    except socket.error, ex:
        (error_number, error_message) = ex
        if (error_number == errno.ECONNABORTED):
            #print "Socket Has Been Closed."
            return -2, -2, -2
        if (error_number == errno.EBADF):
            #print "Socket Has Been Closed."
            return -2, -2, -2
        if (error_number == errno.ECONNRESET):
            #print "Socket Has Been Closed."
            return -2, -2, -2
        elif Settings.VerboseDebug:
            print Settings.BugReportMessage
            print "Traceback Location: PytoYSFHost: RecvPacket2Data: Sockets"
            print error_number
            print error_message
        return -2, -2, -2
    except Exception, ex:
        print Settings.BugReportMessage
        print "Traceback Location: PytoYSFHost: RecvPacket2Data: Other"
        try:
            (error_number, error_message) = ex
            print error_number
            print error_message
            print "Buffer: " + buffer_data
            print "Buffer Size: " + str(len(buffer_data))
        except:
            print ex
            print "Buffer: " + buffer_data
            print "Buffer Size: " + str(len(buffer_data))
        return -2, -2, -2

def Packet2Data(databuffer):
    try:
        datalength = unpack("I",databuffer[0:3])[0]
        datatype = unpack("I",databuffer[4:7])[0]
        datapayload = unpack(str(datalength-4) + "s",len(databuffer[8:]))[0]
        return datalength, datatype, datapayload
    except:
        print self.Username, "Sent A Bugged Packet."
        return 4, 17, "\0\0\0\0"

def Data2Packet(datatype, data):
    try:
        return pack("II" + str(len(data)) + "s", 4+len(data), datatype, data)
    except:
        return pack("II4s", 4, 17, "\0\0\0\0")

def Packet2Hex(databuffer):
    try:
        i = 0
        m = ''
        while i < len(databuffer):
            temp = ord(databuffer[i])
            first = temp/16
            if (first == 0):
                first = '0'
            elif (first == 1):
                first = '1'
            elif (first == 2):
                first = '2'
            elif (first == 3):
                first = '3'
            elif (first == 4):
                first = '4'
            elif (first == 5):
                first = '5'
            elif (first == 6):
                first = '6'
            elif (first == 7):
                first = '7'
            elif (first == 8):
                first = '8'
            elif (first == 9):
                first = '9'
            elif (first == 10):
                first = 'A'
            elif (first == 11):
                first = 'B'
            elif (first == 12):
                first = 'C'
            elif (first == 13):
                first = 'D'
            elif (first == 14):
                first = 'E'
            elif (first == 15):
                first = 'F'
            second = temp - (temp/16)*16
            if (second == 0):
                second = '0'
            elif (second == 1):
                second = '1'
            elif (second == 2):
                second = '2'
            elif (second == 3):
                second = '3'
            elif (second == 4):
                second = '4'
            elif (second == 5):
                second = '5'
            elif (second == 6):
                second = '6'
            elif (second == 7):
                second = '7'
            elif (second == 8):
                second = '8'
            elif (second == 9):
                second = '9'
            elif (second == 10):
                second = 'A'
            elif (second == 11):
                second = 'B'
            elif (second == 12):
                second = 'C'
            elif (second == 13):
                second = 'D'
            elif (second == 14):
                second = 'E'
            elif (second == 15):
                second = 'F'
            if len(m) > 0:
                m += ":"
            m += str(first) + str(second)
            i += 1
        return m
    except:
        return -1
