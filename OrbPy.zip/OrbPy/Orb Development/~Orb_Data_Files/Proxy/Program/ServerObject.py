execfile('Proxy/Commands/LogonComplete.py')

class Server:
    def JoinPlugs(self, client):
        #Absolute
        self.client = client
        self.server = self
        self.client.client = client
        self.client.server = self

        #Relative Others
        self.other = client
        self.client.other = self

        #Absolute Sockets
        self.client.clientsock = client.sock
        self.client.serversock = client.serversock
        self.clientsock = client.sock
        self.serversock = client.serversock

        #Relative Sockets
        self.sock = self.serversock
        self.other.sock = client.sock
        
        self.Username = "(Console Server)"
        self.other.Username = client.Username

        self.closing = False
        self.other.closing = False
    
    def __init__(self, client): #Need to send the socket to get data from, and socket to send it to.
        self.JoinPlugs(client) #Link the relatives and absolute references between the client and server objects.
        LogonComplete(self.client) #Client has been fully established, let everyone know the client has joined.
        self.serverthread = thread.start_new_thread(self.program, (self,))
        self.clientthread = thread.start_new_thread(client.program, (client,))
        client.serverthread = self.serverthread
        client.clientthread = self.clientthread
        

    def send(self, data):
        self.s.send(data)

    def recv(self, size):
        return self.s.recv(size)

    def close(self):
        self.closing = True
        self.sock.shutdown(2)
        self.sock.close()

    def program(self, null):
        if (Settings.VerboseDebug):
            while not self.closing:
                #print "Server Talking To Client"
                data = RecvPacket2Data(self)
                if (data[0] == -1) and not self.closing:
                    pass
                    #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Dropped A Bugged Packet."
                elif (data[0] == -2) and not self.closing:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Socket Closed. Cleaning."
                    self.close()
                elif not self.closing:
                    datalength = data[0]
                    datatype = data[1]
                    datapayload = data[2]
                    ProcessPacket(self, datalength, datatype, datapayload);
            print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Thread closed'
        else:
            try:
                while not self.closing:
                    #print "Server Talking To Client"
                    data = RecvPacket2Data(self)
                    if (data[0] == -1) and not self.closing:
                        #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Dropped A Bugged Packet."
                        pass
                    elif (data[0] == -2) and not self.closing:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', "Socket Closed. Cleaning."
                        self.close()
                    elif not self.closing:
                        datalength = data[0]
                        datatype = data[1]
                        datapayload = data[2]
                        ProcessPacket(self, datalength, datatype, datapayload);
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Thread closed'
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print '''
                WARNING!There has been a bug in the program! (OH NOES!)
                Please submit the following bug report via the bug report page:
                    http://sourceforge.net/p/orbforysflight/tickets/new/
                If you can accuratly reproduce the error, please reperform the error with 'Graceful Debug' turned OFF,
                    then submit the error produced via the same link above.

                Thanks for your report!

                Bug Data:'''
                print "    ", (exc_type, fname, exc_tb.tb_lineno)
                print "\nBecause of this bug, The client:", self.client.Username, "has been disconnected."
                self.client.close()
