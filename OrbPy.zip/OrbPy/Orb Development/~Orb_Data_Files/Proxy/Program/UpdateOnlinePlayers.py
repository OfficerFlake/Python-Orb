import datetime
def UpdateOnlinePlayers(null):
    try:
        test = ServerInfo.UpdateOnlinePlayers
    except:
        ServerInfo.UpdateOnlinePlayers = False
    while True:
        try:
            test = last
        except:
            last = datetime.datetime.now()
        time.sleep(5)
        if ServerInfo.UpdateOnlinePlayers == True:
            if len(ServerInfo.UsersOnline) == 0:
                print "Still Listening For Clients... No-One Online..."
            ServerInfo.UpdateOnlinePlayers = False
        for username in ServerInfo.UsersOnline:
            try:
                #print User[username].Info["PlayTime"]
                User[username].Info["PlayTime"] += (datetime.datetime.now() - last)
                if User[username].Info["ClientID"].Flying:
                    try:
                        User[username].Info["FlightHours"] += (datetime.datetime.now() - last)
                    except:
                        print username, 'Flight Not Read Correcty?'
                        print User[username].Info["FlightHours"]
                WriteUserToDatabase(username)
                #print 'Updated', username, 'Playtime:', User[username].Info["PlayTime"]
            except:
                print username, 'Time Not Read Correcty?'
                print User[username].Info["PlayTime"]
                #User[username].Info["PlayTime"] = (datetime.datetime.now() - last)
        last = datetime.datetime.now()

def bin(n):
    if n > 255:
        return n
    i = 7
    m = ''
    while i >= 0:
        m += str(n/pow(2, i))
        n = n - (n/pow(2, i)*pow(2, i))
        i -= 1
    return m

