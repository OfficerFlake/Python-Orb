def AddToGroup(target, group, rank, host):
    if not UserExists(host.Username):
        SendCommandBackward(host, 'User not found: "' + str(host.Username) + '".')
        return -1
    if not UserExists(target.Username):
        SendCommandBackward(host, 'User not found: "' + str(target.Username) + '".')
        return -1
    if GroupExists(group):
        if UserInGroup(target, group):
            SendCommandBackward(host, '"' + target.Username + '" is already a member of group "' + group + '"')
            return -2
        rankold = rank
        rank = GroupGetRank(group, rank)
        if rank < 0:
            SendCommandBackward(host, 'Rank not found: ' + rankold + '')
            return -1
        if AdminOverride(host):
            User[target.Username].AddToGroupOverride(group, rank, host)
            return 0
        if not UserInGroup(host, group):
            SendCommandBackward(host, 'You cannot add "' + target.Username + '" to the group "' + group + '" because you are not a member of that group to begin with.')
            return -1
        if PermissionsTest(host, group, "CanAddToGroup") >= 1:
            if GroupRelativePower(host, group, "MaxPromote") >= rank:
                User[target.Username].AddToGroupOverride(group, rank, host)
            else:
                #print 'failed to induct due to rank'
                SendCommandBackward(host, 'Cannot add "' + target.Username + '" to group "' + str(group) + '" at rank "' + Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName + "]. You Can't Promote members to that rank.")
        else:
            #print 'failed to induct due to no permission'
            SendCommandBackward(host, 'Cannot add "' + target.Username + '". Your rank is unable to induct users to the group')
    else:
        SendCommandBackward(host, 'Group not found: "' + str(group) + '".')

def AddToGroupOverride(target, group, rank, host):
    target.Group[group] = SpawnUserGroupObject();
    target.Group[group].Rank["Number"] = rank
    target.Group[group].Rank["Previous"] = rank
    WriteUserToDatabase(target.Username)
    m = str(User[target.Username].Info["DisplayedName"]) + ' was added to Group "' + str(group) + '" at rank "' + str(Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName) + '" by ' + str(User[host.Username].Info["DisplayedName"]) + "."
    SendCommandForward(host, m)
