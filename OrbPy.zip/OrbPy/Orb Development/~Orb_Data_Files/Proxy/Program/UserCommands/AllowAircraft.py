def AllowAircraft(self, name):
        self.Permission.AllowAircraft[name] = 1
        self.Permission.DenyAircraft[name] = 0
