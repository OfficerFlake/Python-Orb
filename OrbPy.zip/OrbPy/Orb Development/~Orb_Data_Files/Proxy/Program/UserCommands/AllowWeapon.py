def AllowWeapon(self, name):
        self.Permission.AllowWeapon[name] = 1
        self.Permission.DenyWeapon[name] = 0
