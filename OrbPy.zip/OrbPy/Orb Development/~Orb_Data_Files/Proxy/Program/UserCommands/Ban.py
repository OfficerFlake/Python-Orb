def Ban(target, reason, host, expiry):
    if (target.Username == host.Username):
        SendCommandBackward(host, "You cannot ban yourself!")
        return -1
    if AdminOverride(host):
        try:
            User[target.Username].BanOverride(reason, host, expiry)
        except:
            print sys.exc_info()
    if PermissionsTest(host, ServerInfo.MasterGroup, "CanBan"):
        #print 'test1'
        if PermissionsComparison(host, target, ServerInfo.MasterGroup, "CanBanRank"):
            BanOverride(target, reason, host, expiry)
        else:
            SendCommandBackward(host, 'Cannot ban "' + target.Username + '". You rank is not high enough to ban theirs.')
    else:
        SendCommandBackward(host, 'Cannot ban "' + target.Username + '". You rank is not able to ban.')

def BanOverride(self, reason, host, expiry):
    if not InfoTest(self, "Banned"):
        self.Info["Banned"] = True
        self.Info["BannedBy"] = User[host.Username].Info["DisplayedName"]
        self.Info["BanReason"] = reason
        self.Info["BanDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["BanExpires"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        WriteUserToDatabase(self.Username)
        #print 'write'
        User[host.Username].Info["BannedPlayers"] = int(User[host.Username].Info["BannedPlayers"]) + 1
        WriteUserToDatabase(host.Username)
        m = "You have been BANNED by " + self.Info["BannedBy"] + "."
        if (len(self.Info["BanReason"]) > 0):
            m += "\nReason: " + self.Info["BanReason"]
        for username in ServerInfo.UsersOnline:
            if (username == self.Username):
                SendCommandBackward(User[username].Info["ClientID"], m)
        m = str(User[self.Username].Info["DisplayedName"]) + " was BANNED by " + self.Info["BannedBy"] + "."
        if (len(self.Info["BanReason"]) > 0):
            m += "\nReason: " + self.Info["BanReason"]
        for username in ServerInfo.UsersOnline:
            if (username != self.Username):
                SendCommandBackward(User[username].Info["ClientID"], m)
        self.Info["ClientID"].close() ##actually kills the client and it's thread!
    else:
        m = self.Username + ' is already banned by: "' + self.Info["BannedBy"]+ '".'
        if (len(self.Info["BanReason"]) > 0):
            m += "\nReason: " + self.Info["BanReason"]
            SendCommandBackward(host, m)
        else:
            SendCommandBackward(host, m)
