def Demote(target, host, group, rank, reason):
    if not UserExists(host.Username):
        SendCommandBackward(host, 'User not found: "' + str(host.Username) + '".')
        return -1
    if not UserExists(target.Username):
        SendCommandBackward(host, 'User not found: "' + str(target.Username) + '".')
        return -1
    if GroupExists(group):
        if not UserInGroup(target, group):
            SendCommandBackward(host, '"' + target.Username + '" is not a member of group "' + group + '"')
            return -2
        rankold = rank
        rank = GroupGetRank(group, rank)
        if rank < 0:
            SendCommandBackward(host, 'Rank not found: ' + rankold + '')
            return -1             
        if (int(User[target.Username].Group[group].Rank["Number"]) <= int(rank)):
            SendCommandBackward(host, target.Username + "'s rank ([" + str(group) + "][" + str(Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName) + "]) is not higher then the rank specified ([" + group + "][" + Group[group].Rank[int(rank)].RankName + "]).")
            return -2
        if AdminOverride(host):
            User[target.Username].DemoteOverride(host, group, rank, reason)
            return 0
        if not UserInGroup(host, group):
            SendCommandBackward(host, 'You cannot demote "' + target.Username + '" in the group "' + group + '" because you are not a member of that group to begin with.')
            return -1  
        if GroupRelativePower(host, group, "MaxDemote") >= rank:
            User[target.Username].DemoteOverride(host, group, rank, reason)  
        else:
            SendCommandBackward(host, "Cannot demote " + target.Username + " from [" + str(group) + "][" + str(Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName) + "] to [" + group + "][" + Group[group].Rank[int(rank)].RankName + "]. Your rank is unable to demote theirs.")
    else:
        SendCommandBackward(host, 'Group not found: "' + str(group) + '".')        

        

def DemoteOverride(target, host, group, rank, reason):
    target.Group[group].Rank["Previous"] = int(target.Group[group].Rank["Number"])
    target.Group[group].Rank["Number"] = int(rank)
    target.Group[group].Rank["By"] = User[host.Username].Username
    target.Group[group].Rank["Reason"] = reason
    target.Group[group].Rank["Date"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
    WriteUserToDatabase(target.Username)
    m = str(target.Username) + " was promoted from [" + str(group) + "][" + str(Group[group].Rank[int(target.Group[group].Rank["Previous"])].RankName) + "] to [" + group + "][" + Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName + "] by " + target.Group[group].Rank["By"] + "."
    SendCommandForward(host, m)
    if (len(target.Group[group].Rank["Reason"]) > 0):
        m = "Reason: " + target.Group[group].Rank["Reason"]
        SendCommandForward(host, m)
