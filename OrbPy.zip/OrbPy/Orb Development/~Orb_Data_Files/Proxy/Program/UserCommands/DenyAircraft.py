def DenyAircraft(self, name):
        self.Permission.DenyAircraft[name] = 1
        self.Permission.AllowAircraft[name] = 0
