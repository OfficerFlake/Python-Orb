def DenyWeapon(self, name):
        self.Permission.DenyWeapon[name] = 1
        self.Permission.AllowWeapon[name] = 0
