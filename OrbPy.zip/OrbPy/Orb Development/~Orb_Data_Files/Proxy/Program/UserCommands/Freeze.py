def Freeze(target, host):
    if (target.Username == host.Username):
        SendCommandBackward(host, "You cannot freeze yourself!")
        return -1
    try:
        usersvalue = User[host.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
    except:
        ##The logging in user is not a member of the master group.
        usersvalue = 0
    try:
        targetsvalue = User[target.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
    except:
        ##The target user is not a member of the master group.
        targetsvalue = 0
    if AdminOverride(host):
        try:
            User[target.Username].FreezeOverride(host)
            return 0
        except:
            print sys.exc_info()
    if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanFreeze"]) >= 1):
        if ((int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanFreezeRank"])) >= targetsvalue):
            User[target.Username].FreezeOverride(host)
        else:
            SendCommandBackward(host, 'Cannot freeze "' + target.Username + '". Your rank is not high enough to freeze theirs.')
    else:
        SendCommandBackward(host, 'Cannot freeze "' + target.Username + '". Your rank is not able to freeze.')


def FreezeOverride(target, host):
    if (target.Info["Frozen"] < 1):
        target.Info["Frozen"] = True
        target.Info["FrozenBy"] = User[host.Username].Info["DisplayedName"]
        target.Info["FrozenDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        WriteUserToDatabase(target.Username)
        User[host.Username].Info["FrozenPlayers"] = int(User[host.Username].Info["FrozenPlayers"]) + 1
        WriteUserToDatabase(host.Username)
        m = "You have been FROZEN by " + target.Info["FrozenBy"] + "."
        for username in ServerInfo.UsersOnline:
            if (username == target.Username):
                SendCommandBackward(User[username].Info["ClientID"], m)
                if User[username].Info["ClientID"].Flying == True:
                    SendCommandBackward(User[username].Info["ClientID"], "You can STILL Fly for now, but your position on the server will remain static, and you can not send any damage signals.")
                User[username].Info["ClientID"].sock.send(Data2Packet(39, pack("I", 0)))
                User[username].Info["ClientID"].sock.send(Data2Packet(31, pack("I", 0)))
        m = str(User[target.Username].Info["DisplayedName"]) + " was FROZEN by " + target.Info["FrozenBy"] + "."
        for username in ServerInfo.UsersOnline:
            if (username != target.Username):
                SendCommandBackward(User[username].Info["ClientID"], m)
    else:
        m = target.Username + ' is already frozen by: "' + target.Info["FrozenBy"]+ '".'
        SendCommandBackward(host, m)
