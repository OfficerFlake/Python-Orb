def GetPermission(self, permname):
        return self.Permission[permname]
