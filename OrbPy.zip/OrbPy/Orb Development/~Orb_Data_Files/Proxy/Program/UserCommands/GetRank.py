def GetRank(self, groupname):
        return Group[groupname].Rank[int(self.Group[groupname].Rank["Number"])].RankName + " (" + Group[groupname].Rank[int(self.Group[groupname].Rank["Number"])].RankNameFull + ")"
