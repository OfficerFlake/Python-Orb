def Kick(target, reason, host):
    if (target.Username == host.Username):
        SendCommandBackward(host, "You cannot kick yourself!")
        return -1
    try:
        usersvalue = User[host.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
    except:
        ##The logging in user is not a member of the master group.
        usersvalue = 0
    try:
        targetsvalue = User[target.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
    except:
        ##The target user is not a member of the master group.
        targetsvalue = 0
    if AdminOverride(host):
        try:
            User[target.Username].KickOverride(reason, host)
            return 0
        except:
            print sys.exc_info()
    if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanKick"]) >= 1):
        if ((int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanKickRank"])) >= targetsvalue):
            User[target.Username].KickOverride(reason, host)
        else:
            SendCommandBackward(host, 'Cannot kick "' + target.Username + '". Your rank is not allowed to kick theirs.')
    else:
        SendCommandBackward(host, 'Cannot kick "' + target.Username + '". Your rank is not able to kick.')

def KickOverride(target, reason, host):
    online = False;
    for username in ServerInfo.UsersOnline:
        if (username == target.Username):
            online = True;
    if online:
        target.Info["KickedBy"] = User[host.Username].Info["DisplayedName"]
        target.Info["KickReason"] = reason
        target.Info["KickDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        target.Info["TimesKicked"] = int(target.Info["TimesKicked"]) + 1
        User[host.Username].Info["KickedPlayers"] = int(User[host.Username].Info["KickedPlayers"]) + 1
        WriteUserToDatabase(target.Username)
        WriteUserToDatabase(host.Username)
        m = "You have been KICKED by " + target.Info["KickedBy"] + "."
        if (len(target.Info["KickReason"]) > 0):
            m += "\nReason: " + target.Info["KickReason"]
        SendCommandBackward(target.Info["ClientID"], m)
        m = str(User[target.Username].Info["DisplayedName"]) + " was KICKED by " + target.Info["KickedBy"] + "."
        if (len(target.Info["KickReason"]) > 0):
            m += "\nReason: " + target.Info["KickReason"]
        for username in ServerInfo.UsersOnline:
            if (username != target.Username):
                SendCommandBackward(User[username].Info["ClientID"], m)
        time.sleep(0.25)
        target.Info["ClientID"].close() ##actually kills the client and it's thread!
    else:
        m = target.Username + ' is not online.'
        SendCommandBackward(host, m)

