def Mute(target, reason, host, expiry):
    if (target.Username == host.Username):
        SendCommandBackward(host, "You cannot mute yourself!")
        return -1
    try:
        usersvalue = User[host.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
    except:
        ##The logging in user is not a member of the master group.
        usersvalue = 0
    try:
        targetsvalue = User[target.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
    except:
        ##The target user is not a member of the master group.
        targetsvalue = 0
    if AdminOverride(host):
        try:
            User[target.Username].MuteOverride(reason, host, expiry)
            return 0
        except:
            print sys.exc_info()
    if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanMute"]) >= 1):
        if ((int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanMuteRank"])) >= targetsvalue):
            User[target.Username].MuteOverride(reason, host, expiry)
        else:
            SendCommandBackward(host, 'Cannot mute "' + target.Username + '". Your rank is not high enough to mute theirs.')
    else:
        SendCommandBackward(host, 'Cannot mute "' + target.Username + '". Your rank is not able to mute.')


def MuteOverride(target, reason, host, expiry):
    if (target.Info["Muted"] < 1):
        target.Info["Muted"] = True
        target.Info["MutedBy"] = User[host.Username].Info["DisplayedName"]
        target.Info["MuteReason"] = reason
        target.Info["MuteDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        target.Info["MuteExpires"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        WriteUserToDatabase(target.Username)
        User[host.Username].Info["MutedPlayers"] = int(User[host.Username].Info["MutedPlayers"]) + 1
        WriteUserToDatabase(host.Username)
        m = "You have been MUTED by " + target.Info["MutedBy"] + "."
        if (len(target.Info["MuteReason"]) > 0):
            m += "\nReason: " + target.Info["MuteReason"]
        for username in ServerInfo.UsersOnline:
            if (username == target.Username):
                SendCommandBackward(User[username].Info["ClientID"], m)
        m = str(User[target.Username].Info["DisplayedName"]) + " was MUTED by " + target.Info["MutedBy"] + "."
        if (len(target.Info["MuteReason"]) > 0):
            m += "\nReason: " + target.Info["MuteReason"]
        for username in ServerInfo.UsersOnline:
            if (username != target.Username):
                SendCommandBackward(User[username].Info["ClientID"], m)
    else:
        m = target.Username + ' is already muted by: "' + target.Info["MutedBy"]+ '".'
        if (len(target.Info["MuteReason"]) > 0):
            m += "\nReason: " + target.Info["MuteReason"]
            SendCommandBackward(host, m)
        else:
            SendCommandBackward(host, m)
