def PrintAllPermissions(self):
        for i in self.Permission:
            #print i
            self.PrintPermission(i)
