def PrintAllRanks(self):
        for i in self.Group:
            self.PrintRank(i)
