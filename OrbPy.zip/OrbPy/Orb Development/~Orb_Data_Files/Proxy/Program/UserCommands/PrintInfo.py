def PrintInfo(self, info):
        print self.Username + "'s Information for: " + info + " is: " + str(self.Info[info])
