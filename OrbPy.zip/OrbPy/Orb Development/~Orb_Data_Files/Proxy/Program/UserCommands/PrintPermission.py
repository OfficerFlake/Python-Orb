def PrintPermission(self, permname):
        #print permname
        if (permname == "AllowAircraft"):
            for i in self.GetPermission(permname):
                #print int(self.GetPermission(permname)[i])
                if (int(self.GetPermission(permname)[i]) >= 1):
                    print self.Username + " is Allowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
        elif (permname == "DenyAircraft"):
            for i in self.GetPermission(permname):
                #print int(self.GetPermission(permname)[i])
                if (int(self.GetPermission(permname)[i]) >= 1):
                    print self.Username + " is Disallowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
                    
        elif (permname == "AllowWeapon"):
            for i in self.GetPermission(permname):
                #print int(self.GetPermission(permname)[i])
                if (int(self.GetPermission(permname)[i]) >= 1):
                    print self.Username + " is Allowed to use Weapon: " + self.GetPermission(permname).keys()[0]
                    
        elif (permname == "DenyWeapon"):
            for i in self.GetPermission(permname):
                #print int(self.GetPermission(permname)[i])
                if (int(self.GetPermission(permname)[i]) >= 1):
                    print self.Username + " is Disallowed to use Weapon: " + self.GetPermission(permname).keys()[0]
        else:
            print self.Username + "'s Permission Setting for " + permname + " is: " + str(self.GetPermission(permname))
