def PrintRank(self, groupname):
        print self.Username + "'s Rank in " + groupname + " is: " + self.GetRank(groupname)
