def RemoveFromGroup(target, group, host):
    if not UserExists(host.Username):
        SendCommandBackward(host, 'User not found: "' + str(host.Username) + '".')
        return -1
    if not UserExists(target.Username):
        SendCommandBackward(host, 'User not found: "' + str(target.Username) + '".')
        return -1
    if GroupExists(group):
        if not UserInGroup(target, group):
            SendCommandBackward(host, '"' + target.Username + '" is not a member of group "' + group + '"')
            return -2
        if AdminOverride(host):
            User[target.Username].RemoveFromGroupOverride(group, host)
            return 0
        if not UserInGroup(host, group):
            SendCommandBackward(host, 'You cannot remove "' + target.Username + '" from the group "' + group + '" because you are not a member of that group to begin with.')
            return -1
        if PermissionsTest(host, group, "CanRemoveFromGroup") == True:
            if GroupRelativePower(host, group, "MaxDemote") >= target.Group[group].Rank["Number"]:
                User[target.Username].RemoveFromGroupOverride(group, host)
            else:
                #print 'failed to remove due to rank'
                SendCommandBackward(host, 'Cannot remove "' + target.Username + '" from group "' + str(group) + '" at rank "' + Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName + "]. You Can't Promote members to that rank.")
        else:
            #print 'failed to remove due to no permission'
            SendCommandBackward(host, 'Cannot remove "' + target.Username + '" from group "' + str(group) + '". Your rank is unable to remove users from the group')
    else:
        SendCommandBackward(host, 'Group not found: "' + str(group) + '".')

def RemoveFromGroupOverride(target, group, host):
    del target.Group[group]
    WriteUserToDatabase(target.Username)
    m = str(User[target.Username].Info["DisplayedName"]) + ' was removed from group "' + str(group) + ' by ' + str(User[host.Username].Info["DisplayedName"]) + "."
    SendCommandForward(host, m)

