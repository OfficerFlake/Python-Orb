def Say(self, message):
    #print "say2"
    try:
        usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
    except:
        ##The logging in user is not a member of the master group.
        usersvalue = 0
    #print str(int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanSay"]) + int(User[self.Username].Permission["CanSay"]))
    if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanSay"]) + int(User[self.Username].Permission["CanSay"]) >= 1):
        #print "passed"
        #print message
        SendCommandForward(User[self.Username].Info["ClientID"], message)
        return 0
    else:
        #print "failed"
        SendCommandBackward(User[self.Username].Info["ClientID"], "You don't have permission to '/say'")
        return -1
            
        
