def UnBan(target, reason, host, expiry):
    if (target.Username == host.Username) and not AdminOverride(host.Username):
        SendCommandBackward(host, "You cannot unban yourself!\nAlso, You should be logged out! How the fuck are you even on the server!?\nIMPOSSIBRU!")
        return -1
    if AdminOverride(host):
        try:
            User[target.Username].UnBanOverride(reason, host, expiry)
        except:
            print sys.exc_info()
    if PermissionsTest(host, ServerInfo.MasterGroup, "CanBan"):
        if PermissionsComparison(host, target, ServerInfo.MasterGroup, "CanBanRank"):
            BanOverride(target, reason, host, expiry)
        else:
            SendCommandBackward(host, 'Cannot unban "' + target.Username + '". You rank is not high enough to unban theirs.')
    else:
        SendCommandBackward(host, 'Cannot unban "' + target.Username + '". You rank is not able to unban.')

def UnBanOverride(self, reason, host, expiry):
    if InfoTest(self, "Banned"):
        self.Info["Banned"] = False
        self.Info["BannedBy"] = User[host.Username].Info["DisplayedName"]
        self.Info["BanReason"] = reason
        self.Info["BanDate"] = (-1, -1, -1)
        self.Info["BanExpires"] = (-1, -1, -1)
        WriteUserToDatabase(self.Username)
        m = str(User[self.Username].Info["DisplayedName"]) + " was unbanned by " + self.Info["BannedBy"] + "."
        if (len(self.Info["BanReason"]) > 0):
            m += "\nReason: " + self.Info["BanReason"]
            SendCommandForward(host, m)
        else:
            SendCommandForward(host, m)
    else:
        m = self.Username + ' is not currently banned.'
        SendCommandBackward(host, m)
