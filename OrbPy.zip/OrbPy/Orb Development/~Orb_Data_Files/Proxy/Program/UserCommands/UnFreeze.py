def UnFreeze(target, host):
    if (target.Username == host.Username):
        SendCommandBackward(host, "You cannot unfreeze yourself!")
        return -1
    try:
        usersvalue = User[host.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
    except:
        ##The logging in user is not a member of the master group.
        usersvalue = 0
    try:
        targetsvalue = User[target.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
    except:
        ##The target user is not a member of the master group.
        targetsvalue = 0
    if AdminOverride(host):
        try:
            User[target.Username].UnFreezeOverride(host)
            return 0
        except:
            print sys.exc_info()
    if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanFreeze"]) >= 1):
        if ((int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanFreezeRank"])) >= targetsvalue):
            User[target.Username].UnFreezeOverride(host)
        else:
            SendCommandBackward(host, 'Cannot unfreeze "' + target.Username + '". Your rank is not high enough to unfreeze theirs.')
    else:
        SendCommandBackward(host, 'Cannot unfreeze "' + target.Username + '". Your rank is not able to unfreeze.')


def UnFreezeOverride(target, host):
    if (target.Info["Frozen"] >= 1):
        target.Info["Frozen"] = False
        target.Info["FrozenBy"] = User[host.Username].Info["DisplayedName"]
        target.Info["FrozenDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        WriteUserToDatabase(target.Username)
        m = "You have been UNFROZEN by " + target.Info["FrozenBy"] + "."
        for username in ServerInfo.UsersOnline:
            if (username == target.Username):
                SendCommandBackward(User[username].Info["ClientID"], m)
                User[username].Info["ClientID"].sock.send(Data2Packet(39, pack("I", ServerInfo.WeaponsEnabled)))
                User[username].Info["ClientID"].sock.send(Data2Packet(31, pack("I", ServerInfo.MissilesEnabled)))
        m = str(User[target.Username].Info["DisplayedName"]) + " was UNFROZEN by " + target.Info["FrozenBy"] + "."
        for username in ServerInfo.UsersOnline:
            if (username != target.Username):
                SendCommandBackward(User[username].Info["ClientID"], m)
    else:
        m = target.Username + ' is not frozen.'
        SendCommandBackward(host, m)

