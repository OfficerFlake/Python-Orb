#for ThisGroupName in GroupsOnline:
#print ThisGroupName
Group[ThisGroupName].Rank.reverse()
path = "Database/GROUPS/"
fopen = open(path + ThisGroupName + '.txt', "w")
fopen.write("GROUPNAME\t" + ThisGroupName + "\n")
fopen.write("FULLNAME\t" + Group[ThisGroupName].FullName + "\n")
#print Group[ThisGroupName].Rank
for rank in enumerate(Group[ThisGroupName].Rank):
    #print rank
    #print rank[0]
    #print rank[1]
    fopen.write("RANK\t\t" + rank[1].RankName + "|" + rank[1].RankNameFull + "\n")
    frank = open(path + ThisGroupName + "/PERMISSIONS/" + str(rank[0]) + '.txt', "w")
    for permission in rank[1].Permission:
        #print permission
        #print rank[1].Permission[permission]
        if (permission == "AllowAircraft") or (permission == "DenyAircraft") or (permission == "AllowWeapon") or (permission == "DenyWeapon"):
            #print rank[1].Permission[permission].keys()
            for item in rank[1].Permission[permission].keys():
                frank.write("PERMISSION\t\t" + permission + "|" + str(item) + "|" + str(rank[1].Permission[permission][item]) + "\n")    
        else:
            frank.write("PERMISSION\t\t" + permission + "|" + str(rank[1].Permission[permission]) + "\n")
    frank.close()
fopen.close()
Group[ThisGroupName].Rank.reverse()
            
                
                
