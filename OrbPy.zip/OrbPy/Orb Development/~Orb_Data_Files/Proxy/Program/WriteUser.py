#for ThisUserName in UsersOnline:
#print ThisUserName
def WriteUserToDatabase(ThisUserName):
    if ThisUserName.lower() == "php bot" or ThisUserName.lower() == ServerInfo.ConsoleName.lower():
        return -1
    path = "Database/USERS/"
    fopen = open(path + ThisUserName + '.txt', "w")
    fopen.write("USERNAME\t\t" + ThisUserName + "\n")
    fopen.write("USERNAMEDISPLAYED\t" + User[ThisUserName].Info["DisplayedName"] + "\n")
    #print User[ThisUserName].Group.keys()
    for group in User[ThisUserName].Group.keys():
        fopen.write("GROUP\t\t\t" + group + "|" + str(User[ThisUserName].Group[group].Rank["Number"]) + "\n")
    fopen.close()
    fopen = open(path + "INFO/" + ThisUserName + '.txt', "w")
    for info in User[ThisUserName].Info:
        if info == 'FeedName' or info == 'ClientID':
            pass
        elif not (info == 'PlayTime') and not (info == 'FlightHours'):
            fopen.write("INFO\t\t\t" + info + "|" + str(User[ThisUserName].Info[info]) + "\n")
        elif (info == 'PlayTime') or (info == 'FlightHours'):
            try:
                weeks = str(User[ThisUserName].Info[info].weeks)
            except:
                weeks = 0
            try:
                days = str(User[ThisUserName].Info[info].days)
            except:
                days = 0
            try:
                hours = str(User[ThisUserName].Info[info].hours)
            except:
                hours = 0
            try:
                minutes = str(User[ThisUserName].Info[info].minutes)
            except:
                minutes = 0
            try:
                seconds = str(User[ThisUserName].Info[info].seconds)
            except:
                seconds = 0
            try:
                microseconds = str(User[ThisUserName].Info[info].microseconds)
            except:
                microseconds = 0
            final = "(" + str(weeks)
            final += ", " + str(days)
            final += ", " + str(hours)
            final += ", " + str(minutes)
            final += ", " + str(seconds)
            final += ", " + str(microseconds) + ")"
            #print final
            fopen.write("INFO\t\t\t" + info + "|" + final + "\n")
            
    fopen.close()
    fopen = open(path + "PERMISSIONS/" + ThisUserName + '.txt', "w")    
    for permission in User[ThisUserName].Permission:
        #print permission
        #print User[ThisUserName].Permission[permission]
        if (permission == "AllowAircraft") or (permission == "DenyAircraft") or (permission == "AllowWeapon") or (permission == "DenyWeapon"):
            #print User[ThisUserName].Permission[permission].keys()
            for item in User[ThisUserName].Permission[permission].keys():
                fopen.write("PERMISSION\t\t" + permission + "|" + str(item) + "|" + str(User[ThisUserName].Permission[permission][item]) + "\n")    
        else:
            fopen.write("PERMISSION\t\t" + permission + "|" + str(User[ThisUserName].Permission[permission]) + "\n")
    fopen.close()
            
                
                
