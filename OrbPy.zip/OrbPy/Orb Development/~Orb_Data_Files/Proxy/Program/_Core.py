import socket
import sys
import thread
import select
import time
from struct import pack, unpack

#WE NEED TO LOAD THE MODULES FIRST
execfile("Proxy/Program/PyToYSFHost.py")                ##PACKET CONSTRUCTOR/DECONSTRUCTOR
execfile("Proxy/Commands/CommandHost.py")               ##ACTIONS All MESSAGE TYPE 32 IF THEY ARE A COMMAND.
execfile("Proxy/Program/MessSendRecv.py")               ##FOR SENDING STRINGS TO AND FROM THE YSFLIGHT SERVER.
execfile("Proxy/Program/PacketHost.py")                 ##PROCESSES EVERY YSFLIGHT PACKET AND PERFORMS THE CORRECT ACTION
execfile("Proxy/Program/ServerObject.py")               ##HANDLES THE SERVER -> CLIENT COMMS
execfile("Proxy/Program/ClientObject.py")               ##HANDLES THE CLIENT -> SERVER COMMS
execfile("Proxy/Login/ClientMasterLoginSequence.py")    ##GRABS THE CLIENTS INFORMATION.
execfile("Proxy/Login/YSFHQLogin.py")                   ##PERFORMS A LOGIN WITH YSFHQ
execfile("Proxy/Program/UpdateOnlinePlayers.py")        ##UPDATE PLAYERS PLAY TIME.

###START THE PROGRAM:
print "Started YSFlight Proxy Service..."
Proxy = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
if (Settings.LocalTestMode):
        print "WARNING: PROXY SERVICE IS IN 'LOCALTESTMODE'"
        ProxyAddress = ('localhost',Settings.ProxyPort)
else:
        ProxyAddress = ('',Settings.ProxyPort) #We need to leave this string empty, otherwise it listens to LOCALHOST ONLY. 
try:
        Proxy.bind(ProxyAddress)
except:
        MasterClose("\n\nERROR! Orb cannot start on the port you requested (" + str(Settings.ProxyPort) + ").\nCheck that nothing else is running on the port then restart the server!", 30)
#print Proxy
#client[Clients] = Client(Proxy)
#print Proxy
print "Listening for clients on: " + str(Settings.ProxyPort) + "\n..."
UpdatePlayerDB = thread.start_new_thread(UpdateOnlinePlayers, ('',))
while True:
    ##try:
        try:
           Proxy.listen(1)
        except:
           Proxy.close();
           Proxy.listen(1);
        time.sleep(1)
        newclient = Proxy.accept()[0]
        client = thread.start_new_thread(Client, (newclient,))
        #print "Thread Spawned"
    ##except:
        #print "Thread Crash."
        ##pass;
        
