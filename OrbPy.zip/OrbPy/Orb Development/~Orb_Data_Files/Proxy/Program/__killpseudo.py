"""

22 = damage
46 = kill

if 22:
    get the username
    get the target.
    append user to targets assist.
    last assist = this user

if 46:
    get username
    get target
    if flight active:
        if targets kill is empty:
            append user to targets kill.
        else:
            append user to assist list.
        set targets flightactive to false

if leave flight:
    if target speed > 2KIAS:
        #not perfectly stopped
        target.deaths += 1
        target.killstreak = 0

        if kills empty:
            if last assist empty:
                if assist empty:
                    #killed self: suicide
                    target.deaths += 1
                    target.killstreak = 0
                    send YSF msg: "User Suicide" 
                else:
                    #last assist is empty, but an assist is made? grant the assist to all assisters, do not grant a kill to any.
                    for user in target.assist:
                        send user an assist message
                        user.score += 20
            else: #last assist not empty:
                if last assist matches a username:
                    #grant that kill
                    last assist.kills += 1
                    last assist.score += 100
                    last assist.killstreak += 1
                    for user in assist:
                        if user != last assist:
                            send user an assist message
                            user.score += 20
        else
            #kills not empty
            for user in kills:
                user.kills += 1
                user.score += 100
                user.killstreak += 1
            for assisstant in assists:
                found = false
                for user in kills:
                    if user == assisstant
                        found = true
                if not found:
                    user.send assist message
                    user.score += 20
    else: #target speed is <= 2 KIAS.
    
    
