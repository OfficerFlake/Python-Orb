def EstablishGroupVariables(self):
    self.Rank = []

class SpawnGroup:
    def __init__(self, name):
        EstablishGroupVariables(self);
        self.Groupname = name
        self.Fullname = name
        self.Permission = {}
        SetPermissions(self)
        #self.Rank.append(Rank())

    def AddRank(self, name, namefull):
        if Settings.VerboseDebug:
            self.Rank.append(Rank(name, namefull));
        else:
            try:
                self.Rank.append(Rank(name, namefull));
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def DelRank(self, name):
        if Settings.VerboseDebug:
            for i in self.Rank:
                if (i.RankName == name):
                    self.Rank.remove(i);
                    #print "Deleted rank: " + name
                    return True
        else:
            try:
                for i in self.Rank:
                    if (i.RankName == name):
                        self.Rank.remove(i);
                        #print "Deleted rank: " + name
                        return True
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def PrintRanks(self):
        if Settings.VerboseDebug:
            print "Printing Ranks For Group: " + self.Groupname
            i = 0
            while i < len(self.Rank):
                print "Rank #" + str(i) + ": " + self.Rank[i].RankName + " (" + self.Rank[i].RankNameFull + ")"
                i += 1
        else:
            try:
                print "Printing Ranks For Group: " + self.Groupname
                i = 0
                while i < len(self.Rank):
                    print "Rank #" + str(i) + ": " + self.Rank[i].RankName + " (" + self.Rank[i].RankNameFull + ")"
                    i += 1
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def RankIDFromName(self, name):
        if Settings.VerboseDebug:
            for i in enumerate(self.Rank):
                #print i[0]
                if (i[1].RankName == name):
                    return i[0]
            return -1
        else:
            try:
                for i in enumerate(self.Rank):
                    #print i[0]
                    if (i[1].RankName == name):
                        return i[0]
                return -1
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)
            

    def PrintAllPermissionsForAllRanks(self):
        if Settings.VerboseDebug:
            for i in self.Rank:
                #print i
                i.PrintAllPermissions()
        else:
            try:
                for i in self.Rank:
                    #print i
                    i.PrintAllPermissions()
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

def GroupGetRank(group, rank):
    if not GroupExists(group):
        return -1
    try:
        rank = int(rank)
    except:
        ranknew = int(Group[group].RankIDFromName(str(rank)))
        if (ranknew < 0):
            print "Rank not found: ", rank
            return -1
        else:
            rank = ranknew
    if (int(rank) > len(Group[group].Rank)-1):
        rank = int(len(Group[group].Rank)-1)
    elif (int(rank) < 0):
        rank = 0
    return rank

def GroupRelativePower(host, group, permission):
    if not GroupExists(group):
        return -1
    try:
        return int(User[host.Username].Group[group].Rank["Number"]) + int(Group[group].Rank[int(User[host.Username].Group[group].Rank["Number"])].Permission[permission])
    except:
        print "Error: Group Relative Power"
        return -9001

def GroupExists(group):
    try:
        test = Group[group]
        return True
    except:
        return False
Group = {}
