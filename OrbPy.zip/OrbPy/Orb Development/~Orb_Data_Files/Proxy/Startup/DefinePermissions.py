def EstablishPermissions(self):
    self.AllowAircraft = {}
    self.DenyAircraft = {}
    self.AllowWeapon = {}
    self.DenyWeapon = {}

def SetPermissions(self):
        EstablishPermissions(self);
        ##Use a math system, where a negative number removes the permission,
        ##A positive number adds it, and 0 has no effect.
        ##
        ##For example, rank login = 1 can log the user in, but
        ##If user permissions are set to -1, then the user can NOT log in.
        ##set the permission to 2, and 2-1 is still 1, and user can log in.

        ##BASIC
        self.Permission["CanLogin"] = 0
        self.Permission["CanJoinFlight"] = 0
        self.Permission["CanTalk"] = 0

        ##LOW POWER
        self.Permission["CanPrivateMessage"] = 0
        self.Permission["CanMessageIFF"] = 0
        self.Permission["CanIgnore"] = 0

        ##IN FLIGHT
        self.Permission["AllowAircraft"] = {} ##The wildcard is used to check the aircraft name. The wildcard is also considered a match.
        self.Permission["DenyAircraft"] = {} ##Stops a user from using any aircraft
        self.Permission["AllowWeapon"] = {} ## Allows all weapons
        self.Permission["DenyWeapon"] = {} ##Deny a weapon

        ##ADMIN TOGGLES:
        self.Permission["CanBan"] = 0
        self.Permission["CanBanRank"] = -1
            
        self.Permission["CanKick"] = 0
        self.Permission["CanKickRank"] = -1
        
        self.Permission["CanFreeze"] = 0
        self.Permission["CanFreezeRank"] = -1
        
        self.Permission["CanKill"] = 0
        self.Permission["CanKillRank"] = -1
        
        self.Permission["CanMute"] = 0
        self.Permission["CanMuteRank"] = -1

        self.Permission["CanPromote"] = 0
        self.Permission["MaxPromoteRank"] = -1
        
        self.Permission["CanDemote"] = 0
        self.Permission["MaxDemoteRank"] = -1

        self.Permission["CanHide"] = 0
        self.Permission["CanHideFromRank"] = -1
        
        self.Permission["CanViewOthersInfo"] = 0

        ##ADMIN HIGH
        self.Permission["CanAddToGroup"] = 1 ##Add a user to the group.
        self.Permission["CanRemoveFromGroup"] = 1
        self.Permission["CanChangeMap"] = 0
        self.Permission["CanHearAll"] = 0 ##Includes Private Messages.
        self.Permission["CanChangeTime"] = 0 ##Day/Night
        self.Permission["CanChangeWind"] = 0
        self.Permission["CanAdjustVisibility"] = 0
        self.Permission["CanRestart"] = 0
        self.Permission["CanShutdown"] = 0
        self.Permission["CanFlush"] = 0 ##Kicks all clients gracefully.
        self.Permission["CanSay"] = 0 ##Send A Message W/O Username Attached.
        self.Permission["CanAdjustRadar"] = 0 ##YSRadar
        self.Permission["CanAdjustBlackout"] = 0
        self.Permission["CanAdjustLandEverywhere"] = 0
        self.Permission["CanAdjustWeapons"] = 0
        self.Permission["CanAdjustCollision"] = 0

        ##ADMIN CREATIVE
        self.Permission["CanSpawnGround"] = 0
        self.Permission["CanSpawnAircraft"] = 0
