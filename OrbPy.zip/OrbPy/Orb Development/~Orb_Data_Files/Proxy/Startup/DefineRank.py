class Rank:
    def __init__(self, name, namefull):
        if Settings.VerboseDebug:
            self.RankName = name
            self.RankNameFull = namefull
            self.Permission = {}
            SetPermissions(self)
        else:
            try:
                self.RankName = name
                self.RankNameFull = namefull
                self.Permission = {}
                SetPermissions(self)
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def GetPermission(self, permname):
        if Settings.VerboseDebug:
            temp = self.Permission[permname]
            return temp
        else:
            try:
                temp = self.Permission[permname]
                return temp
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def PrintPermission(self, permname):
        if Settings.VerboseDebug:
            if (permname == "AllowAircraft"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.RankName + " is Allowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
            elif (permname == "DenyAircraft"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.RankName + " is Disallowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
                        
            elif (permname == "AllowWeapon"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.RankName + " is Allowed to use Weapon: " + self.GetPermission(permname).keys()[0]
                        
            elif (permname == "DenyWeapon"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.RankName + " is Disallowed to use Weapon: " + self.GetPermission(permname).keys()[0]
            else:
                print self.RankName + "'s Permission Setting for " + permname + " is: " + str(self.GetPermission(permname))
        else:
            try:
                if (permname == "AllowAircraft"):
                    for i in self.GetPermission(permname):
                        #print int(self.GetPermission(permname)[i])
                        if (int(self.GetPermission(permname)[i]) >= 1):
                            print self.RankName + " is Allowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
                elif (permname == "DenyAircraft"):
                    for i in self.GetPermission(permname):
                        #print int(self.GetPermission(permname)[i])
                        if (int(self.GetPermission(permname)[i]) >= 1):
                            print self.RankName + " is Disallowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
                            
                elif (permname == "AllowWeapon"):
                    for i in self.GetPermission(permname):
                        #print int(self.GetPermission(permname)[i])
                        if (int(self.GetPermission(permname)[i]) >= 1):
                            print self.RankName + " is Allowed to use Weapon: " + self.GetPermission(permname).keys()[0]
                            
                elif (permname == "DenyWeapon"):
                    for i in self.GetPermission(permname):
                        #print int(self.GetPermission(permname)[i])
                        if (int(self.GetPermission(permname)[i]) >= 1):
                            print self.RankName + " is Disallowed to use Weapon: " + self.GetPermission(permname).keys()[0]
                else:
                    print self.RankName + "'s Permission Setting for " + permname + " is: " + str(self.GetPermission(permname))
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)
    def PrintAllPermissions(self):
        if Settings.VerboseDebug:
            for i in self.Permission:
                #print i
                self.PrintPermission(i)
        else:
            try:
                for i in self.Permission:
                    #print i
                    self.PrintPermission(i)
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

