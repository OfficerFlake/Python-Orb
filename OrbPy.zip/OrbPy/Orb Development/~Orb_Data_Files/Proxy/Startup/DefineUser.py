class SpawnUser:
    execfile('Proxy/Program/UserCommands/_EstablishUserVariables.py')
    execfile('Proxy/Program/UserCommands/AddToGroup.py')
    execfile('Proxy/Program/UserCommands/RemoveFromGroup.py')
    execfile('Proxy/Program/UserCommands/GetRank.py')
    execfile('Proxy/Program/UserCommands/PrintRank.py')
    execfile('Proxy/Program/UserCommands/PrintAllRanks.py')
    execfile('Proxy/Program/UserCommands/GetPermission.py')
    execfile('Proxy/Program/UserCommands/PrintPermission.py')
    execfile('Proxy/Program/UserCommands/PrintAllPermissions.py')
    execfile('Proxy/Program/UserCommands/PrintInfo.py')
    execfile('Proxy/Program/UserCommands/PrintAllInfo.py')
    execfile('Proxy/Program/UserCommands/Promote.py')
    execfile('Proxy/Program/UserCommands/Demote.py')
    execfile('Proxy/Program/UserCommands/Say.py')
    execfile('Proxy/Program/UserCommands/Mute.py')
    execfile('Proxy/Program/UserCommands/UnMute.py')
    execfile('Proxy/Program/UserCommands/Freeze.py')
    execfile('Proxy/Program/UserCommands/UnFreeze.py')
    execfile('Proxy/Program/UserCommands/Ban.py')
    execfile('Proxy/Program/UserCommands/UnBan.py')
    execfile('Proxy/Program/UserCommands/Kick.py')
    execfile('Proxy/Program/UserCommands/AllowAircraft.py')
    execfile('Proxy/Program/UserCommands/DenyAircraft.py')
    execfile('Proxy/Program/UserCommands/AllowWeapon.py')
    execfile('Proxy/Program/UserCommands/DenyWeapon.py')
    
    def __init__(self, name):
        self.EstablishUserVariables();
        self.Username = name
        self.Info["DisplayedName"] = name
        self.Permission = {}
        SetPermissions(self)

def UserExists(user):
    try:
        test = User[user]
        return True
    except:
        return False
User = {}
