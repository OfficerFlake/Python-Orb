def EstablishUserGroupVariables(self):
    self.Rank = {}

class SpawnUserGroupObject:
    def __init__(self):
        EstablishUserGroupVariables(self);
        self.Rank["Number"] = 0
        self.Rank["Reason"] = ""
        self.Rank["By"] = ""
        self.Rank["Previous"] = 0
        self.Rank["Date"] = (-1, -1, -1)
