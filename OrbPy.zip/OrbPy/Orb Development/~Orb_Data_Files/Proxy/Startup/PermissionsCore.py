def PermissionsComparison(host, target, group, permission):
    if not UserExists(host.Username) and UserExists(target.Username) and GroupExists(group):
        return -1
    try:
        usersvalue = User[host.Username].Group[group].Rank["Number"]
    except:
        ##The host user is not a member of the group.
        usersvalue = 0
    try:
        targetsvalue = User[target.Username].Group[group].Rank["Number"]
    except:
        ##The target is not a member of the group.
        targetsvalue = 0
    if ((int(usersvalue) + int(Group[group].Rank[int(usersvalue)].Permission[permission])) >= targetsvalue):
        return True
    else:
        return False

def PermissionsComparisonOffline(host, target, group, permission):
    if not UserExists(host) and UserExists(target) and GroupExists(group):
        return -1
    try:
        usersvalue = User[host].Group[group].Rank["Number"]
    except:
        ##The host user is not a member of the group.
        usersvalue = 0
    try:
        targetsvalue = User[target].Group[group].Rank["Number"]
    except:
        ##The target is not a member of the group.
        targetsvalue = 0
    if ((int(usersvalue) + int(Group[group].Rank[int(usersvalue)].Permission[permission])) >= targetsvalue):
        return True
    else:
        return False
    
def RankComparison(host, target, group):
    if not UserExists(host.Username) and UserExists(target.Username) and GroupExists(group):
        return -1
    try:
        usersvalue = User[host.Username].Group[group].Rank["Number"]
    except:
        ##The host user is not a member of the group.
        usersvalue = 0
    try:
        targetsvalue = User[target.Username].Group[group].Rank["Number"]
    except:
        ##The target is not a member of the group.
        targetsvalue = 0
    if (int(usersvalue) >= targetsvalue):
        return True
    else:
        return False
        
def PermissionsTest(host, group, permission):
    if not UserExists(host.Username) and GroupExists(group):
        return -1
    try:
        usersvalue = User[host.Username].Group[group].Rank["Number"]
    except:
        ##The host user is not a member of the group.
        usersvalue = 0
    if (int(Group[group].Rank[int(usersvalue)].Permission[permission]) >= 1):
        return True
    else:
        return False

def AdminOverride(host):
    #print 'override'
    if not UserExists(host.Username):
        #print 'override -'
        return -1
    if host.Username.lower() == ServerInfo.AdminName.lower() or host.Username.lower() == ServerInfo.ConsoleName.lower():
        #print 'override +'
        return True
    else:
        #print 'override false'
        return False

def InfoTest(user, info):
    if not UserExists(user.Username):
        return -1
    try:
        int(User[user].Info[info])
    except:
        return -1
    if User[user].Info[info] >= 1:
        return True
    else:
        return False

def UserInGroup(user, group):
    if not UserExists(user.Username) and GroupExists(group):
        return -1
    try:
        test = User[user.Username].Group[group]
        return True
    except:
        return False

def UserInGroupOffline(user, group):
    if not UserExists(user) and GroupExists(group):
        return -1
    try:
        test = User[user].Group[group]
        return True
    except:
        return False
    
    
