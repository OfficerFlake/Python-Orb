import os
path = "Database/GROUPS/"
dirlist = os.listdir(path)
for dirname in dirlist:
    if (os.path.isdir(path + dirname)): ##we want to SKIP the text files this time!
        for groupname in Group.keys():
            ##We now have the dirname, now we need to sort through each group and find a match.
            if (groupname == dirname):
                #print groupname
                #print dirname
                ##With that dirname, see if it is a pre defined group.
                ThisGroupspath = path + groupname + "/PERMISSIONS/"
                ThisGroupdirlist = os.listdir(ThisGroupspath) 
                for ranknumber in enumerate(Group[groupname].Rank):
                    #print ranknumber
                    ranknumber = ranknumber[0]
                    ##NOW we have each rank in order;
                    for i in enumerate(ThisGroupdirlist):
                        #print "$" + i[1][:-4]
                        #print "$" + str(ranknumber)
                        if i[1][:-4] == str(ranknumber):
                            rank = i[1][:-4]
                            #print i
                            rankname = i[1]
                            ThisRankFile = open(ThisGroupspath + str(rank) + ".txt", "r")
                            print "        Got Permissions For Group: " + groupname + " Rank: " + Group[groupname].Rank[ranknumber].RankName
                            for line in ThisRankFile:
                                if (len(line) > 0):
                                    line.replace("\r", "")
                                    #print "Data: " + line
                                    while chr(10) in line:
                                        #print "line > 0"
                                        try:
                                            #print "thingy"
                                            line = line.replace(chr(10), "")
                                            #print "got one"
                                        except:
                                            break
                                    line = line.split("\t")
                                    #print line
                                    while len(line) > 0:
                                        try:
                                            line.remove("")
                                        except:
                                            break
                                    #print line[0]
                                    #print line[1]
                                    if len(line) == 2:
                                        key = line[0]
                                        value = line[1]
                                        #print line[0]
                                        #print line[1]
                                        #print ord(value[-1])
                                        #print "Key: $" + key + "$ Value: $" + value + "$"
                                        #print key
                                        #print ThisUserName
                                        if key == "PERMISSION":
                                            #print "Got A Permission"
                                            compare = value.split("|")
                                            #print compare
                                            try:
                                                permname = compare[0]
                                                permvalue = compare[1]
                                            except:
                                                print "        Got a bugged permission...: " + compare[0]
                                                break;
                                            if (permname == "AllowAircraft") or (permname == "DenyAircraft") or (permname == "AllowWeapon") or (permname == "DenyWeapon"):
                                                try:
                                                    permsetting = compare[2]
                                                    try:
                                                        Group[groupname].Rank[ranknumber].Permission[permname][permvalue] = permsetting
                                                    except:
                                                        Group[groupname].Rank[ranknumber].Permission[permname] = {}
                                                        Group[groupname].Rank[ranknumber].Permission[permname][permvalue] = permsetting
                                                except:
                                                    print "        Got a bugged permission...: " + compare[0]
                                                    break;                                    
                                            else:
                                                Group[groupname].Rank[ranknumber].Permission[permname] = permvalue
                            ThisRankFile.close()
                            #Group[groupname].Rank[ranknumber].PrintAllPermissions();

