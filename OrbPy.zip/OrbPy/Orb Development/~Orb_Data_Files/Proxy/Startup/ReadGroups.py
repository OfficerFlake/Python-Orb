import os
path = "Database/GROUPS/"
dirlist = os.listdir(path)
for fname in dirlist:
    if (fname.lower() [-4:] == ".txt"):
        print "    Got A Group: " + fname[0:-4]
        fopen = open(path + fname, "r")
        ThisGroupName = "Null"
        for line in fopen:
            if (len(line) > 0):
                line = line.replace("\r", "")
                line = line.replace("\n", "")
                #print "Data: " + line
                while chr(10) in line:
                    #print "line > 0"
                    try:
                        #print "thingy"
                        line = line.replace(chr(10), "")
                        #print "got one"
                    except:
                        break
                line = line.split("\t")
                #print line
                while len(line) > 0:
                    try:
                        line.remove("")
                    except:
                        break
                #print line[0]
                #print line[1]
                if len(line) == 2:
                    key = line[0]
                    value = line[1]
                    #print line[0]
                    #print line[1]
                    #print ord(value[-1])
                    #print "Key: $" + key + "$ Value: $" + value + "$"
                    #print key
                    if (key == "GROUPNAME"):
                        ThisGroupName = value
                        #print ThisGroupName
                        #print "got the groupname"
                        Group[ThisGroupName] = SpawnGroup(value)
                    elif (ThisGroupName != "Null"):
                        #print ThisGroupName
                        if key == "FULLNAME":
                            #print "got the fullname"
                            Group[ThisGroupName].FullName = value
                        elif key == "RANK":
                            Group[ThisGroupName].AddRank(value.split("|")[0], value.split("|")[1])
                            ranknumber = len(Group[ThisGroupName].Rank)-1
                            rankname = value.split("|")[0]
                            rankpath = "Database/GROUPS/" + ThisGroupName + "/PERMISSIONS/"
                            #print rankname
                            execfile("Proxy/Startup/ReadRankPermissions.py")
                    else:
                        if (ThisGroupName == "Null"):
                            print "    File Doesn't Start With Groupname..."
        fopen.close()
        Group[ThisGroupName].Rank.reverse()
        #Group[ThisGroupName].PrintRanks()
        #Group[ThisGroupName].PrintAllPermissionsForAllRanks()
        execfile("Proxy/Program/WriteGroup.py")
