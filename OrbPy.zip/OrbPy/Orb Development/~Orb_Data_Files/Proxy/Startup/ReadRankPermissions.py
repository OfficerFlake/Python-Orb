import os
##inherit rankname
##inherit ranknumber
##inherit rankpath

dirlist = os.listdir(rankpath)
for fname in dirlist:
    #print fname
    #print fname[:-4].lower()
    #print str(ranknumber).lower()
    if (fname[:-4].lower() == str(ranknumber).lower()):
        #print "Got Permissions For Rank: " + rankname
        fopen = open(rankpath + fname, "r")
        for line in fopen:
            if (len(line) > 0):
                line.replace("\r", "")
                #print "Data: " + line
                while chr(10) in line:
                    #print "line > 0"
                    try:
                        #print "thingy"
                        line = line.replace(chr(10), "")
                        #print "got one"
                    except:
                        break
                line = line.split("\t")
                #print line
                while len(line) > 0:
                    try:
                        line.remove("")
                    except:
                        break
                #print line[0]
                #print line[1]
                if len(line) == 2:
                    key = line[0]
                    value = line[1]
                    #print line[0]
                    #print line[1]
                    #print ord(value[-1])
                    #print "Key: $" + key + "$ Value: $" + value + "$"
                    #print key
                    #print ThisGroupName
                    if key == "PERMISSION":
                        #print "Got A Permission"
                        compare = value.split("|")
                        #print compare
                        try:
                            permname = compare[0]
                            permvalue = compare[1]
                        except:
                            print "        Got a bugged permission...: " + compare[0]
                            break;
                        if (permname == "AllowAircraft") or (permname == "DenyAircraft") or (permname == "AllowWeapon") or (permname == "DenyWeapon"):
                            try:
                                permsetting = compare[2]
                                try:
                                    Group[ThisGroupName].Rank[ranknumber].Permission[permname][permvalue] = permsetting
                                except:
                                    Group[ThisGroupName].Rank[ranknumber].Permission[permname] = {}
                                    Group[ThisGroupName].Rank[ranknumber].Permission[permname][permvalue] = permsetting
                            except:
                                print "        Got a bugged permission...: " + compare[0]
                                break;                                    
                        else:
                            Group[ThisGroupName].Rank[ranknumber].Permission[permname] = permvalue
        #Group[ThisGroupName].PrintAllPermissions();

