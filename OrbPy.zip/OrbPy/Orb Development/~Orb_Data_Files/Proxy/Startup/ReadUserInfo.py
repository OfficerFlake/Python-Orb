import os

def stringtotuple(variable):
    try:
        #print 'inside str->tuple'
        #print variable
        backup = variable
        variable = variable[1:-1] #'-1, -1, -1'
        #print variable
        variable = variable.replace(" ","") #'-1,-1,-1'
        #print variable
        variable = variable.split(",",2) #-1, -1, -1
        #print variable
        #print variable[0]
        #print variable[1]
        #print variable[2]
        x = ()
        x += ((int(variable[0])),)
        x += ((int(variable[1])),)
        x += ((int(variable[2])),)
        #print x
        #print 'no issues.'
        return x
    except:
        print 'string to tuple error'
        return backup

def stringtodelta(variable):
    try:
        #print 'inside str->delta'
        #print variable
        backup = variable
        variable = variable[1:-1] #'-1, -1, -1'
        #print variable
        variable = variable.replace(" ","") #'-1,-1,-1'
        #print variable
        variable = variable.split(",",6) #-1, -1, -1
        #print variable
        #print variable[0]
        #print variable[1]
        #print variable[2]
        #print variable[3]
        #print variable[4]
        #print variable[5]
        x = ()
        x += ((int(variable[0])),)
        x += ((int(variable[1])),)
        x += ((int(variable[2])),)
        x += ((int(variable[3])),)
        x += ((int(variable[4])),)
        x += ((int(variable[5])),)
        #print x
        #print 'no issues.'
        return x
    except:
        print '        String to delta error'
        return backup

infopath = "Database/USERS/INFO/"
filename = infopath + ThisUserName + '.txt'
if os.path.exists(filename) and os.path.isfile(filename):
    #print "    Got Info For User: " + ThisUserName
    finfo = open(filename, "r")
    for line in finfo:
        if (len(line) > 0):
            line.replace("\r", "")
            #print "Data: " + line
            while chr(10) in line:
                #print "line > 0"
                try:
                    #print "thingy"
                    line = line.replace(chr(10), "")
                    #print "got one"
                except:
                    break
            line = line.split("\t")
            #print line
            while len(line) > 0:
                try:
                    line.remove("")
                except:
                    break
            #print line[0]
            #print line[1]
            if len(line) == 2:
                key = line[0]
                value = line[1]
                #print line[0]
                #print line[1]
                #print ord(value[-1])
                #print "Key: $" + key + "$ Value: $" + value + "$"
                #print key
                #print ThisUserName
                if key == "INFO":
                    #print "Got A Permission"
                    compare = value.split("|")
                    #print compare
                    try:
                        infoname = compare[0]
                        try:
                            #print 'nested try success.'
                            infovalue = compare[1]
                            if (str(infovalue).lower() == "true"):
                                infovalue = True
                            elif (str(infovalue).lower() == "false"):
                                infovalue = False
                            else:
                                try:
                                    infovalue = int(infovalue)
                                except:
                                    pass
                        except:
                            print '        Some Error Reading User Info:', compare[0], '|', compare[1]
                            infovalue = ""
                        try:
                            if (infovalue[0] == "(") and (infovalue[-1] == ")") and ((infoname != 'PlayTime') and (infoname != 'FlightHours')):
                                #print infoname
                                #surely this is a date.
                                #print 'got a date'
                                infovalue = stringtotuple(infovalue)
                        except:
                            pass
                        try:
                            if (infoname == 'PlayTime') or (infoname == 'FlightHours'):
                                #print infoname
                                #print 'playtime'
                                #print infovalue
                                infovalue = stringtodelta(infovalue)
                                #print infovalue
                                #print int(infovalue[0])
                                #print int(infovalue[1])
                                #print int(infovalue[2])
                                #print int(infovalue[3])
                                #print int(infovalue[4])
                                #print int(infovalue[5])
                                #print 'all values read correctly.'
                                infovalue = datetime.timedelta(weeks=int(infovalue[0]), days=int(infovalue[1]), hours=int(infovalue[2]), minutes=int(infovalue[3]), seconds=int(infovalue[4]), microseconds=int(infovalue[5]))
                                #print 'infovalue sucessfully applied.'
                                #print infoname, ':',  infovalue
                        except:
                            if (infoname == 'PlayTime') or (info == 'FlightHours'):
                                print ThisUserName,  infoname, 'Read Error.'
                                infovalue = datetime.timedelta(seconds=0)
                    except:
                        print "        Got a bugged info...: " + compare[0]
                    else:
                        try:
                            if (infoname != 'PlayTime') and (infoname != 'FlightHours'):
                                User[ThisUserName].Info[infoname] = int(infovalue)
                            else:
                                User[ThisUserName].Info[infoname] = infovalue
                        except:
                            User[ThisUserName].Info[infoname] = infovalue
    finfo.close()
    #User[ThisUserName].PrintAllInfo();

