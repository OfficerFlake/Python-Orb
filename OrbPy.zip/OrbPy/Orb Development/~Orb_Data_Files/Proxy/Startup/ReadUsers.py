import os
path = "Database/USERS/"
dirlist = os.listdir(path)
for fname in dirlist:
    if (fname.lower() [-4:] == ".txt"):
        print "    Got A User: " + fname[0:-4]
        fopen = open(path + fname, "r")
        #print fopen
        ThisUserName = "Null"
        for line in fopen:
            if (len(line) > 0):
                line = line.replace("\r", "")
                line = line.replace("\n", "")
                #print "Data: " + line
                while chr(10) in line:
                    #print "line > 0"
                    try:
                        #print "thingy"
                        line = line.replace(chr(10), "")
                        #print "got one"
                    except:
                        break
                line = line.split("\t")
                #print line
                while len(line) > 0:
                    try:
                        line.remove("")
                    except:
                        break
                #print line[0]
                #print line[1]
                if len(line) == 2:
                    key = line[0]
                    value = line[1]
                    #print line[0]
                    #print line[1]
                    #print ord(value[-1])
                    #print "Key: $" + key + "$ Value: $" + value + "$"
                    #print key
                if (key == "USERNAME"):
                    ThisUserName = value
                    #print ThisUserName
                    #print "got the username"
                    User[ThisUserName] = SpawnUser(value)
                elif (ThisUserName != "Null"):
                    #print ThisUserName
                    if key == "USERNAMEDISPLAYED":
                        #print "got the fullname"
                        User[ThisUserName].Info["DisplayedName"] = value
                    elif key == "GROUP":
                        #print "Got A Usergroup"
                        compare = value.split("|")
                        #print compare
                        try:
                            groupname = Group[compare[0]]
                            #print groupname
                            grouprank = Group[compare[0]].Rank[int(compare[1])-1]
                            #print grouprank
                        except:
                            print "        Got a bugged group...: " + compare[0]
                            break;
                        User[ThisUserName].Group[compare[0]] = SpawnUserGroupObject();
                        User[ThisUserName].Group[compare[0]].Rank["Number"] = int(compare[1])
                        User[ThisUserName].Group[compare[0]].Rank["Previous"] = int(compare[1])
                        #print User[ThisUserName].Group[compare[0]].Rank["Number"]
                        #print Group[compare[0]].Rank
                        if (int(User[ThisUserName].Group[compare[0]].Rank["Number"]) > len(Group[compare[0]].Rank)-1):
                            User[ThisUserName].Group[compare[0]].Rank["Number"] = len(Group[compare[0]].Rank)-1
                        elif (int(User[ThisUserName].Group[compare[0]].Rank["Number"]) < 0):
                            User[ThisUserName].Group[compare[0]].Rank["Number"] = 0
                else:
                    if (ThisUserName == "Null"):
                        print "        File Doesn't Start With Username..."
        fopen.close()
        #print ThisUserName
        #User[ThisUserName].PrintAllRanks();
        #User[ThisUserName].PrintAllPermissions();
        #User[ThisUserName].PrintAllInfo();
        execfile("Proxy/Startup/ReadUserInfo.py")
        execfile("Proxy/Startup/ReadUserPermissions.py")
execfile("Proxy/Program/WriteUser.py")
