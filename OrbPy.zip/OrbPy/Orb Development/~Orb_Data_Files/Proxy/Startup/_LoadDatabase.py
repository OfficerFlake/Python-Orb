import sys
import time

print "Welcome to Orb Proxy Server!"
print "============================"
print "\n"

def MasterClose(Message, seconds):
    print Message
    print "\n"
    try:
        int(seconds)
    except:
        seconds = 30

    for i in range(seconds):
        print '\rORB WILL CLOSE IN: ' + str(seconds-i) + " Seconds. ",
        time.sleep(1)
    for i in range(3):
        print "\r!!! Server Closing !!!                             ",
        time.sleep(0.5)
        print "\r                                                   ",
        time.sleep(0.5)
    sys.exit()

try:
    test = ServerInfo.StartLock
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER START LOCK SETTING WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER START LOCK IS LISTED! (ServerInfo.StartLock)\n'
    MasterClose(Message, 30)
    
try:
    test = ServerInfo.StartLock
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER START PASS SETTING WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER START PASS IS LISTED! (ServerInfo.StartPass)\n'
    MasterClose(Message, 30)
    
if ServerInfo.StartLock == True:
    password = ""
    error = 0
    if password == ServerInfo.StartPass:
        MasterClose("The Server is currently Start Locked. You Cannot start the server unless the lock is removed or a password is set.", 30)
    print "The Server is currently Start Locked.\n\nPlease enter the password to launch the server.\n"
    while password != ServerInfo.StartPass:
        password = raw_input("Password: ")
        if password != ServerInfo.StartPass:
            error += 1
            if error < 3:
                print "Password Incorrect. Please Try Again."
            else:
                seconds = int(pow(30, float(error)/3))
                for i in range(seconds):
                    print '\rPassword Incorrect. Please Wait: ' + str(seconds-i) + " Seconds Before Trying Again. ",
                    time.sleep(1)
                print "\rPassword Incorrect. Please Try Again.                                   "
    print "\nPassword Correct. Thank you!\n"
    for i in range(3):
        print '\rServer Launching in: ' + str(3-i) + " Seconds. ",
        time.sleep(1)
    print "                               ",
    print "\rServer Launching.                              \n\n"
    print "Starting Orb Server."
    print "====================\n"
print "Preparing The Server For Launch..."
execfile("Proxy/Startup/DefinePermissions.py") #
execfile("Proxy/Startup/PermissionsCore.py")
execfile("Proxy/Startup/DefineGroups.py") #
execfile("Proxy/Startup/DefineRank.py") #
execfile("Proxy/Startup/DefineUserGroupObject.py") #
execfile("Proxy/Startup/DefineUser.py")
print 'Done\n\n'

print "Loading The Database...\n\n"

print "Reading Groups:"
print "==============="
execfile("Proxy/Startup/ReadGroups.py")

print "\nReading Users:"
print "=============="
execfile("Proxy/Startup/ReadUsers.py")

print "\nDatabase Loading Complete!\n\n"

try:
    test = ServerInfo.ConsoleName
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER CONSOLE NAME WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER CONSOLE (ServerInfo.ConsoleName) IS LISTED!(A matching user in the database is NOT needed.)\n'
    MasterClose(Message, 30)

try:
    test = ServerInfo.AdminName
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER OWNER NAME WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER OWNER (ServerInfo.AdminName) IS LISTED! (A matching user in the database is NOT needed.)\n'
    MasterClose(Message, 30)
    
try:
    test = ServerInfo.AdminPass
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER OWNER PASSWORD WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER OWNER PASSWORD (ServerInfo.AdminPass) IS LISTED!\n'
    MasterClose(Message, 30)

try:
    test = Settings.ServerIP
except:
    Settings.ServerIP = '127.0.0.1'
    print "Warning: No ServerIP set in the settings files, using 127.0.0.1 (THIS PC).\n"


if True:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER IP ADDRESS TO CONNECT TO IS NOT AN INTERNAL IP ADDRESS.\n\nFOR SECURITY, ORB CANNOT CONNECT TO EXTERNAL IPADDRESSES.\n\nSPEAK TO OFFICERFLAKE, OR APPLY FOR A DEVELOPERS LICENCE TO BYPASS THIS\nLIMITATION.\n'
    if ((Settings.ServerIP != '127.0.0.1') and
        (Settings.ServerIP[0:7] != '192.168') and
        (Settings.ServerIP[0:7] != '172.16.') and
        (Settings.ServerIP[0:7] != '172.17.') and
        (Settings.ServerIP[0:7] != '172.18.') and
        (Settings.ServerIP[0:7] != '172.19.') and
        (Settings.ServerIP[0:7] != '172.30.') and
        (Settings.ServerIP[0:7] != '172.31.') and
        (Settings.ServerIP[0:3] != '10.')):
            if (Settings.ServerIP[0:5] == '172.2'):
                if (Settings.ServerIP[6] == '.'):
                    pass
                else:
                    MasterClose(Message, 30)
            else:
                MasterClose(Message, 30)

try:
    test = Group[ServerInfo.MasterGroup]
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE MASTER GROUP, ' + str(ServerInfo.MasterGroup) + ', WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE DATABASE FOLDER TO ENSURE THE MASTER GROUP IS LISTED CORRECTLY, AND CHECK THE _SETTINGS.PY TO ENSURE THE MASTER GROUP IS REFERENCED CORRECTLY.\n'
    MasterClose(Message, 30)


