readfile = open('2_FinalBuild.py', 'r')
writefile = open('_PrintResults.txt', 'w')
i = 0
total = 0
for line in readfile:
    i += 1
    if "print" in line:
        if "#" in line[:line.find("print")]:
            pass
        else:
            writefile.write("#" + str(i) + ", " + line)
            total += 1
writefile.write("Total: " + str(total) + ".")
readfile.close()
writefile.close()
