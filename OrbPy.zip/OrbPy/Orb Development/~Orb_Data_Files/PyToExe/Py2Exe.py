from distutils.core import setup
import py2exe, sys, os

test = {}
test2 = {'lol': 'hi'}
test3 = [{'lol': 'hi'}]

sys.argv.append('py2exe')

setup(
    options = {'py2exe': {'bundle_files': 2}},
    name = 'Orb for YSFlight',
    version = '0.3.2',
    description = 'Orb for YSFlight',
    long_description = 'Orb is a Python based YSFlight Server Extension. It works by having ysflight run on a seperate port, and orb running on 7915 (usually). Clients connect to Orb, and Orb then connects them to the server. packets are intercepted, read and edited if need be to manipulate the server to have more power. Fuse this double relay method with a database, and basic functions with the possibility to extend, and Orb becomes immensly powerful.',
    author = 'Flake',
    author_email = 'OfficerFlake@gmail.com',
    url = 'https://sourceforge.net/projects/orbforysflight/',
    url_download = 'https://sourceforge.net/projects/orbforysflight/files/latest/download',
    console = [{'script': "Orb.py", "icon_resources": [(0, "neworb.ico")]}],
    zipfile = None
)
