import datetime

class CreateSettings:
    def __init__(self):
        try:
            self.ServerPort =                   7914    #This is the port that YSFlight Server is running on.
            self.ProxyPort =                    7915    #This is the port that all the YSFlight Clients will connect to.
            self.LocalTestMode =                False   #Local test mode opens the server to 'localhost' only, that is, This PC.
            self.VerboseDebug =                 True    #This Cancels the Try:Except structure that the program uses to keep itself safe from errors. It will throw a verbose error if turned off, which will 1) cause probelms and 2) provide a much more detailed bug report.
            self.AlwaysAllowLocalHost =         True    #This allows 'localhost' to always connect, even if the YSFHQ login system fails.
            self.UseYSFHQAuthentication =       False   #This is a module that makes the user login to the server via a lookup of their username via YSFHQ.
            self.BugReportMessage = '!!! [WARNING] !!!\n\nThere has been a bug in the program! (OH NOES!)\nPlease submit the following bug report via the bug report page:\nhttp://sourceforge.net/p/orbforysflight/tickets/new/\nIf you can accuratly reproduce the error, please re-perform the error with "Verbose Debug" turned ON,\nthen submit the error produced via the same link above.\n\nThanks for your report!\n\nBug Data:'
        except:
            print 'Some sort of error regarding the CreateSettings function.'

class ServerGlobalInfo:
    def __init__(self):
        try:
            self.UsersOnline =  []                      #This is a list of the users online. Do NOT Touch this! The original value is: []
            self.StartLock =    False                   #Locks the server so that it can only be started when a computer user physically enters a password
            self.StartPass =    "lol"
            self.AdminName =    "Flake"                 #This is a special, reserved username for you to log into your server. it requires a log in, but gives you full access
            self.ConsoleName =  "Console"               #As above, but is intended to be used by the GUI side of the program only.
            self.AdminPass =    ""                      #The password to log in to the server as a console operator.
            self.MasterGroup =  'YSRAAF'                #This is used to set the group which has the power of the server. For example, the YSRAAF server uses the YSRAAF group. Set this to any group you would like. USE CAUTION: If your group does NOT exist, ORB WILL NOT RUN!
            self.MissilesEnabled = 1
            self.WeaponsEnabled = 1
            self.Launched =     datetime.datetime.now() #The current time, so we can see the servers 'uptime' later. !!- Don't edit this variable! -!!
        except:
            print 'Some sort of error regrarding the ServerInfo module'
            
try:
    Settings  = CreateSettings();                   #Assigns all the settings as we listed above.
    ServerInfo = ServerGlobalInfo();                #Sets the info as listed above, ready to be referenced later.
except:
    print 'Some error while creating the serversettings classes.'
    

#ServerInfo.MasterGroup
#Settings.VerboseDebug
