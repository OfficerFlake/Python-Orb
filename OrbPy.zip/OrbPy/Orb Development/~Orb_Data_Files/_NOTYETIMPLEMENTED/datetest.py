import datetime

#print datetime.datetime.now()

foo = (2012,3,4,0,0,10)
foo2 = (2012,3,4,0,0,10)

x = datetime.datetime(foo[0],foo[1],foo[2],foo[3],foo[4],foo[5])
y = datetime.datetime(foo2[0],foo2[1],foo2[2],foo2[3],foo2[4],foo2[5])

#print x
#print y
#print y - x

output = ""
if x > y:
    ##YEAR
    if foo[0] > foo2[0]:
        ##1 YEAR
        if foo2[0] + 1 == foo[0]:
            output += "1 Year"
        ##MORE YEARS
        else:
            output += str(foo[0]-foo2[0]) + " Years"
    ##MONTH
    if foo[1] > foo2[1]:
        if len(output) > 0:
            output += ", "
        ##1 MONTH
        if foo2[1] + 1 == foo[1]:
            output += "1 Month"
        ##MORE MONTHS
        else:
            output += str(foo[1]-foo2[1]) + " Months"
    ##DAY
    if foo[2] > foo2[2]:
        if len(output) > 0:
            output += ", "
        ##1 DAY
        if foo2[2] + 1 == foo[2]:
            output += "1 Day"
        ##MORE DAYS
        else:
            output += str(foo[2]-foo2[2]) + " Days"
    ##HOUR
    if foo[3] > foo2[3]:
        if len(output) > 0:
            output += ", "
        ##1 HOUR
        if foo2[3] + 1 == foo[3]:
            output += "1 Hour"
        ##MORE HOURS
        else:
            output += str(foo[3]-foo2[3]) + " Hours"
    ##MINUTE
    if foo[4] > foo2[4]:
        if len(output) > 0:
            output += ", "
        ##1 MINUTE
        if foo2[4] + 1 == foo[4]:
            output += "1 Minute"
        ##MORE MINUTES
        else:
            output += str(foo[4]-foo2[4]) + " Minutes"
    ##SECOND
    if foo[5] > foo2[5]:
        if len(output) > 0:
            output += ", "
        ##1 SECOND
        if foo2[5] + 1 == foo[5]:
            output += "1 Second"
        ##MORE SECONDS
        else:
            output += str(foo[5]-foo2[5]) + " Seconds"
    output += " Ago."
    print output
elif x < y:
    ##YEAR
    if foo2[0] > foo[0]:
        ##1 YEAR
        if foo[0] + 1 == foo2[0]:
            output += "1 Year"
        ##MORE YEARS
        else:
            output += str(foo2[0]-foo[0]) + " Years"
    ##MONTH
    if foo2[1] > foo[1]:
        if len(output) > 0:
            output += ", "
        ##1 MONTH
        if foo[1] + 1 == foo2[1]:
            output += "1 Month"
        ##MORE MONTHS
        else:
            output += str(foo2[1]-foo[1]) + " Months"
    ##DAY
    if foo2[2] > foo[2]:
        if len(output) > 0:
            output += ", "
        ##1 DAY
        if foo[2] + 1 == foo2[2]:
            output += "1 Day"
        ##MORE DAYS
        else:
            output += str(foo2[2]-foo[2]) + " Days"
    ##HOUR
    if foo2[3] > foo[3]:
        if len(output) > 0:
            output += ", "
        ##1 HOUR
        if foo[3] + 1 == foo2[3]:
            output += "1 Hour"
        ##MORE HOURS
        else:
            output += str(foo2[3]-foo[3]) + " Hours"
    ##MINUTE
    if foo2[4] > foo[4]:
        if len(output) > 0:
            output += ", "
        ##1 MINUTE
        if foo[4] + 1 == foo2[4]:
            output += "1 Minute"
        ##MORE MINUTES
        else:
            output += str(foo2[4]-foo[4]) + " Minutes"
    ##SECOND
    if foo2[5] > foo[5]:
        if len(output) > 0:
            output += ", "
        ##1 SECOND
        if foo[5] + 1 == foo2[5]:
            output += "1 Second"
        ##MORE SECONDS
        else:
            output += str(foo2[5]-foo[5]) + " Seconds"
    output += " From Now."
    print output
elif x == y:
    print "Now."
else:
    print "Error?"
