import datetime;
import atexit

def cronjob(repeat, interval, task):
    if not type(repeat) is int:
        if repeat.lower() != "inf":
            try:
                repeat = int(repeat)
            except:
                print "Repeat value is not a number!"
                repeat = 0
    print "Started a CronTask: " + str(task) + ", repeating " + str(repeat) + " time(s), at a rate of once every " + str(interval) + " second(s)."
    if str(repeat).lower == 'inf':
        repeat = 99999999999999999999;
    position = 0;
    interval = datetime.timedelta(seconds=interval);
    x = datetime.datetime.now()
    while not (position > repeat):
        while (datetime.datetime.now() - x < interval):
            pass;
        x = datetime.datetime.now();
        position += 1;
        eval(task);

def showtime(x):
    msg = "The time is: ";
    h = str(x.hour)
    m = str(x.minute)
    s = str(x.second)
    if len(h) < 2:
        h = "0" + h
    if len(m) < 2:
        m = "0" + m
    if len(s) < 2:
        s = "0" + s
    msg += h + ":" + m + ":" + s
    print msg

def terminateprogram():
    x = 3
    y = 0
    z = datetime.datetime.now()
    i = datetime.timedelta(seconds=1)
    while x < y:
        while (datetime.datetime.now() - z < i):
            pass;
        z = datetime.datetime.now();
        y += 1
        print "exiting"
        
atexit.register(terminateprogram);
cronjob('9', 1.00, 'showtime(x)');
