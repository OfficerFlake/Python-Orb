variable = '(-1, -1, -1)'
y = (-1, -1, -1)
variable = variable[1:-1] #'-1, -1, -1'
variable = variable.replace(" ","") #'-1,-1,-1'
variable = variable.split(",",2) #-1, -1, -1
x = ()
x += ((int(variable[0])),)
x += ((int(variable[1])),)
x += ((int(variable[2])),)
print variable
print x
print y
