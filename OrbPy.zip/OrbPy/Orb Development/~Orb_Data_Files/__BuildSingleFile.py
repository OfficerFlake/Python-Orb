class FileReader:
    def __init__(self, filename, indentlevel):
        self.filename = open(filename, 'r')
        self.masterindentlevel = indentlevel
        print indentlevel
        for self.line in self.filename:
            #print self.line.replace("\n", "")
            self.indentlevel = 0
            while self.line[0:4] == "    ":
                self.line = self.line[4:]
                self.indentlevel += 1
            if "execfile(" in self.line:
                print self.line[:self.line.find("execfile(")]
                if not "#" in self.line[:self.line.find("execfile(")]:
                    self.newfile = self.line[self.line.find("execfile(")+len("execfile(")+1:]
                    self.newfile = self.newfile[:self.newfile.find(")")-1]
                    print self.newfile
                    print self.masterindentlevel + self.indentlevel
                    FileReader(self.newfile, self.masterindentlevel + self.indentlevel)
            else:
                Output.write("    " * self.masterindentlevel + "    " * self.indentlevel + self.line)
        self.filename.close()                


Output = open('__FinalBuild.py', 'w')
Master = '__Run_Console.py'
FileReader(Master, 0)
Output.close()
