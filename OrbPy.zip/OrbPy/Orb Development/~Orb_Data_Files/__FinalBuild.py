##RUN YSPS SERVER!

##RUN YSPS SERVER!

import datetime

class CreateSettings:
    def __init__(self):
        try:
            self.ServerPort =                   7914    #This is the port that YSFlight Server is running on.
            self.ServerIP =                     '127.0.0.1'            
            self.ProxyPort =                    7915    #This is the port that all the YSFlight Clients will connect to.
            self.LocalTestMode =                False   #Local test mode opens the server to 'localhost' only, that is, This PC.
            self.VerboseDebug =                 True    #This Cancels the Try:Except structure that the program uses to keep itself safe from errors. It will throw a verbose error if turned off, which will 1) cause probelms and 2) provide a much more detailed bug report.
            self.AlwaysAllowLocalHost =         True    #This allows 'localhost' to always connect, even if the YSFHQ login system fails.
            self.UseYSFHQAuthentication =       False   #This is a module that makes the user login to the server via a lookup of their username via YSFHQ.
            self.BugReportMessage = '!!! [WARNING] !!!\n\nThere has been a bug in the program! (OH NOES!)\nPlease submit the following bug report via the bug report page:\nhttp://sourceforge.net/p/orbforysflight/tickets/new/\nIf you can accuratly reproduce the error, please re-perform the error with "Verbose Debug" turned ON,\nthen submit the error produced via the same link above.\n\nThanks for your report!\n\nBug Data:'
        except:
            print 'Some sort of error regarding the CreateSettings function.'

class ServerGlobalInfo:
    def __init__(self):
        try:
            self.UsersOnline =  []                      #This is a list of the users online. Do NOT Touch this! The original value is: []
            self.StartLock =    False                   #Locks the server so that it can only be started when a computer user physically enters a password
            self.StartPass =    ""
            self.AdminName =    "OfficerFlake"          #This is a special, reserved username for you to log into your server. it requires a log in, but gives you full access
            self.ConsoleName =  "Console"               #As above, but is intended to be used by the GUI side of the program only.
            self.AdminPass =    ""                      #The password to log in to the server as a console operator.
            self.MasterGroup =  'ORB'                #This is used to set the group which has the power of the server. For example, the YSRAAF server uses the YSRAAF group. Set this to any group you would like. USE CAUTION: If your group does NOT exist, ORB WILL NOT RUN!
            self.MissilesEnabled = 1
            self.WeaponsEnabled = 1
            self.Launched =     datetime.datetime.now() #The current time, so we can see the servers 'uptime' later. !!- Don't edit this variable! -!!
        except:
            print 'Some sort of error regrarding the ServerInfo module'
            
try:
    Settings  = CreateSettings();                   #Assigns all the settings as we listed above.
    ServerInfo = ServerGlobalInfo();                #Sets the info as listed above, ready to be referenced later.
except:
    print 'Some error while creating the serversettings classes.'
    

#ServerInfo.MasterGroup
#Settings.VerboseDebug
import sys
import time

print "Welcome to Orb Proxy Server!"
print "============================"
print "\n"

def MasterClose(Message, seconds):
    print Message
    print "\n"
    try:
        int(seconds)
    except:
        seconds = 30

    for i in range(seconds):
        print '\rORB WILL CLOSE IN: ' + str(seconds-i) + " Seconds. ",
        time.sleep(1)
    for i in range(3):
        print "\r!!! Server Closing !!!                             ",
        time.sleep(0.5)
        print "\r                                                   ",
        time.sleep(0.5)
    sys.exit()

try:
    test = ServerInfo.StartLock
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER START LOCK SETTING WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER START LOCK IS LISTED! (ServerInfo.StartLock)\n'
    MasterClose(Message, 30)
    
try:
    test = ServerInfo.StartLock
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER START PASS SETTING WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER START PASS IS LISTED! (ServerInfo.StartPass)\n'
    MasterClose(Message, 30)
    
if ServerInfo.StartLock == True:
    password = ""
    error = 0
    if password == ServerInfo.StartPass:
        MasterClose("The Server is currently Start Locked. You Cannot start the server unless the lock is removed or a password is set.", 30)
    print "The Server is currently Start Locked.\n\nPlease enter the password to launch the server.\n"
    while password != ServerInfo.StartPass:
        password = raw_input("Password: ")
        if password != ServerInfo.StartPass:
            error += 1
            if error < 3:
                print "Password Incorrect. Please Try Again."
            else:
                seconds = int(pow(30, float(error)/3))
                for i in range(seconds):
                    print '\rPassword Incorrect. Please Wait: ' + str(seconds-i) + " Seconds Before Trying Again. ",
                    time.sleep(1)
                print "\rPassword Incorrect. Please Try Again.                                   "
    print "\nPassword Correct. Thank you!\n"
    for i in range(3):
        print '\rServer Launching in: ' + str(3-i) + " Seconds. ",
        time.sleep(1)
    print "                               ",
    print "\rServer Launching.                              \n\n"
    print "Starting Orb Server."
    print "====================\n"
print "Preparing The Server For Launch..."
def EstablishPermissions(self):
    self.AllowAircraft = {}
    self.DenyAircraft = {}
    self.AllowWeapon = {}
    self.DenyWeapon = {}

def SetPermissions(self):
        EstablishPermissions(self);
        ##Use a math system, where a negative number removes the permission,
        ##A positive number adds it, and 0 has no effect.
        ##
        ##For example, rank login = 1 can log the user in, but
        ##If user permissions are set to -1, then the user can NOT log in.
        ##set the permission to 2, and 2-1 is still 1, and user can log in.

        ##BASIC
        self.Permission["CanLogin"] = 0
        self.Permission["CanJoinFlight"] = 0
        self.Permission["CanTalk"] = 0

        ##LOW POWER
        self.Permission["CanPrivateMessage"] = 0
        self.Permission["CanMessageIFF"] = 0
        self.Permission["CanIgnore"] = 0

        ##IN FLIGHT
        self.Permission["AllowAircraft"] = {} ##The wildcard is used to check the aircraft name. The wildcard is also considered a match.
        self.Permission["DenyAircraft"] = {} ##Stops a user from using any aircraft
        self.Permission["AllowWeapon"] = {} ## Allows all weapons
        self.Permission["DenyWeapon"] = {} ##Deny a weapon

        ##ADMIN TOGGLES:
        self.Permission["CanBan"] = 0
        self.Permission["CanBanRank"] = -1
            
        self.Permission["CanKick"] = 0
        self.Permission["CanKickRank"] = -1
        
        self.Permission["CanFreeze"] = 0
        self.Permission["CanFreezeRank"] = -1
        
        self.Permission["CanKill"] = 0
        self.Permission["CanKillRank"] = -1
        
        self.Permission["CanMute"] = 0
        self.Permission["CanMuteRank"] = -1

        self.Permission["CanPromote"] = 0
        self.Permission["MaxPromoteRank"] = -1
        
        self.Permission["CanDemote"] = 0
        self.Permission["MaxDemoteRank"] = -1

        self.Permission["CanHide"] = 0
        self.Permission["CanHideFromRank"] = -1
        
        self.Permission["CanViewOthersInfo"] = 0

        ##ADMIN HIGH
        self.Permission["CanAddToGroup"] = 1 ##Add a user to the group.
        self.Permission["CanRemoveFromGroup"] = 1
        self.Permission["CanChangeMap"] = 0
        self.Permission["CanHearAll"] = 0 ##Includes Private Messages.
        self.Permission["CanChangeTime"] = 0 ##Day/Night
        self.Permission["CanChangeWind"] = 0
        self.Permission["CanAdjustVisibility"] = 0
        self.Permission["CanRestart"] = 0
        self.Permission["CanShutdown"] = 0
        self.Permission["CanFlush"] = 0 ##Kicks all clients gracefully.
        self.Permission["CanSay"] = 0 ##Send A Message W/O Username Attached.
        self.Permission["CanAdjustRadar"] = 0 ##YSRadar
        self.Permission["CanAdjustBlackout"] = 0
        self.Permission["CanAdjustLandEverywhere"] = 0
        self.Permission["CanAdjustWeapons"] = 0
        self.Permission["CanAdjustCollision"] = 0

        ##ADMIN CREATIVE
        self.Permission["CanSpawnGround"] = 0
        self.Permission["CanSpawnAircraft"] = 0
def PermissionsComparison(host, target, group, permission):
    if not UserExists(host.Username) and UserExists(target.Username) and GroupExists(group):
        return -1
    try:
        usersvalue = User[host.Username].Group[group].Rank["Number"]
    except:
        ##The host user is not a member of the group.
        usersvalue = 0
    try:
        targetsvalue = User[target.Username].Group[group].Rank["Number"]
    except:
        ##The target is not a member of the group.
        targetsvalue = 0
    if ((int(usersvalue) + int(Group[group].Rank[int(usersvalue)].Permission[permission])) >= targetsvalue):
        return True
    else:
        return False

def PermissionsComparisonOffline(host, target, group, permission):
    if not UserExists(host) and UserExists(target) and GroupExists(group):
        return -1
    try:
        usersvalue = User[host].Group[group].Rank["Number"]
    except:
        ##The host user is not a member of the group.
        usersvalue = 0
    try:
        targetsvalue = User[target].Group[group].Rank["Number"]
    except:
        ##The target is not a member of the group.
        targetsvalue = 0
    if ((int(usersvalue) + int(Group[group].Rank[int(usersvalue)].Permission[permission])) >= targetsvalue):
        return True
    else:
        return False
    
def RankComparison(host, target, group):
    if not UserExists(host.Username) and UserExists(target.Username) and GroupExists(group):
        return -1
    try:
        usersvalue = User[host.Username].Group[group].Rank["Number"]
    except:
        ##The host user is not a member of the group.
        usersvalue = 0
    try:
        targetsvalue = User[target.Username].Group[group].Rank["Number"]
    except:
        ##The target is not a member of the group.
        targetsvalue = 0
    if (int(usersvalue) >= targetsvalue):
        return True
    else:
        return False
        
def PermissionsTest(host, group, permission):
    if not UserExists(host.Username) and GroupExists(group):
        return -1
    try:
        usersvalue = User[host.Username].Group[group].Rank["Number"]
    except:
        ##The host user is not a member of the group.
        usersvalue = 0
    if (int(Group[group].Rank[int(usersvalue)].Permission[permission]) >= 1):
        return True
    else:
        return False

def AdminOverride(host):
    #print 'override'
    if not UserExists(host.Username):
        #print 'override -'
        return -1
    if host.Username.lower() == ServerInfo.AdminName.lower() or host.Username.lower() == ServerInfo.ConsoleName.lower():
        #print 'override +'
        return True
    else:
        #print 'override false'
        return False

def InfoTest(user, info):
    if not UserExists(user.Username):
        return -1
    try:
        int(User[user].Info[info])
    except:
        return -1
    if User[user].Info[info] >= 1:
        return True
    else:
        return False

def UserInGroup(user, group):
    if not UserExists(user.Username) and GroupExists(group):
        return -1
    try:
        test = User[user.Username].Group[group]
        return True
    except:
        return False

def UserInGroupOffline(user, group):
    if not UserExists(user) and GroupExists(group):
        return -1
    try:
        test = User[user].Group[group]
        return True
    except:
        return False
    
    
def EstablishGroupVariables(self):
    self.Rank = []

class SpawnGroup:
    def __init__(self, name):
        EstablishGroupVariables(self);
        self.Groupname = name
        self.Fullname = name
        self.Permission = {}
        SetPermissions(self)
        #self.Rank.append(Rank())

    def AddRank(self, name, namefull):
        if Settings.VerboseDebug:
            self.Rank.append(Rank(name, namefull));
        else:
            try:
                self.Rank.append(Rank(name, namefull));
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def DelRank(self, name):
        if Settings.VerboseDebug:
            for i in self.Rank:
                if (i.RankName == name):
                    self.Rank.remove(i);
                    #print "Deleted rank: " + name
                    return True
        else:
            try:
                for i in self.Rank:
                    if (i.RankName == name):
                        self.Rank.remove(i);
                        #print "Deleted rank: " + name
                        return True
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def PrintRanks(self):
        if Settings.VerboseDebug:
            print "Printing Ranks For Group: " + self.Groupname
            i = 0
            while i < len(self.Rank):
                print "Rank #" + str(i) + ": " + self.Rank[i].RankName + " (" + self.Rank[i].RankNameFull + ")"
                i += 1
        else:
            try:
                print "Printing Ranks For Group: " + self.Groupname
                i = 0
                while i < len(self.Rank):
                    print "Rank #" + str(i) + ": " + self.Rank[i].RankName + " (" + self.Rank[i].RankNameFull + ")"
                    i += 1
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def RankIDFromName(self, name):
        if Settings.VerboseDebug:
            for i in enumerate(self.Rank):
                #print i[0]
                if (i[1].RankName == name):
                    return i[0]
            return -1
        else:
            try:
                for i in enumerate(self.Rank):
                    #print i[0]
                    if (i[1].RankName == name):
                        return i[0]
                return -1
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)
            

    def PrintAllPermissionsForAllRanks(self):
        if Settings.VerboseDebug:
            for i in self.Rank:
                #print i
                i.PrintAllPermissions()
        else:
            try:
                for i in self.Rank:
                    #print i
                    i.PrintAllPermissions()
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

def GroupGetRank(group, rank):
    if not GroupExists(group):
        return -1
    try:
        rank = int(rank)
    except:
        ranknew = int(Group[group].RankIDFromName(str(rank)))
        if (ranknew < 0):
            print "Rank not found: ", rank
            return -1
        else:
            rank = ranknew
    if (int(rank) > len(Group[group].Rank)-1):
        rank = int(len(Group[group].Rank)-1)
    elif (int(rank) < 0):
        rank = 0
    return rank

def GroupRelativePower(host, group, permission):
    if not GroupExists(group):
        return -1
    try:
        return int(User[host.Username].Group[group].Rank["Number"]) + int(Group[group].Rank[int(User[host.Username].Group[group].Rank["Number"])].Permission[permission])
    except:
        print "Error: Group Relative Power"
        return -9001

def GroupExists(group):
    try:
        test = Group[group]
        return True
    except:
        return False
Group = {}
class Rank:
    def __init__(self, name, namefull):
        if Settings.VerboseDebug:
            self.RankName = name
            self.RankNameFull = namefull
            self.Permission = {}
            SetPermissions(self)
        else:
            try:
                self.RankName = name
                self.RankNameFull = namefull
                self.Permission = {}
                SetPermissions(self)
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def GetPermission(self, permname):
        if Settings.VerboseDebug:
            temp = self.Permission[permname]
            return temp
        else:
            try:
                temp = self.Permission[permname]
                return temp
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

    def PrintPermission(self, permname):
        if Settings.VerboseDebug:
            if (permname == "AllowAircraft"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.RankName + " is Allowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
            elif (permname == "DenyAircraft"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.RankName + " is Disallowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
                        
            elif (permname == "AllowWeapon"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.RankName + " is Allowed to use Weapon: " + self.GetPermission(permname).keys()[0]
                        
            elif (permname == "DenyWeapon"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.RankName + " is Disallowed to use Weapon: " + self.GetPermission(permname).keys()[0]
            else:
                print self.RankName + "'s Permission Setting for " + permname + " is: " + str(self.GetPermission(permname))
        else:
            try:
                if (permname == "AllowAircraft"):
                    for i in self.GetPermission(permname):
                        #print int(self.GetPermission(permname)[i])
                        if (int(self.GetPermission(permname)[i]) >= 1):
                            print self.RankName + " is Allowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
                elif (permname == "DenyAircraft"):
                    for i in self.GetPermission(permname):
                        #print int(self.GetPermission(permname)[i])
                        if (int(self.GetPermission(permname)[i]) >= 1):
                            print self.RankName + " is Disallowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
                            
                elif (permname == "AllowWeapon"):
                    for i in self.GetPermission(permname):
                        #print int(self.GetPermission(permname)[i])
                        if (int(self.GetPermission(permname)[i]) >= 1):
                            print self.RankName + " is Allowed to use Weapon: " + self.GetPermission(permname).keys()[0]
                            
                elif (permname == "DenyWeapon"):
                    for i in self.GetPermission(permname):
                        #print int(self.GetPermission(permname)[i])
                        if (int(self.GetPermission(permname)[i]) >= 1):
                            print self.RankName + " is Disallowed to use Weapon: " + self.GetPermission(permname).keys()[0]
                else:
                    print self.RankName + "'s Permission Setting for " + permname + " is: " + str(self.GetPermission(permname))
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)
    def PrintAllPermissions(self):
        if Settings.VerboseDebug:
            for i in self.Permission:
                #print i
                self.PrintPermission(i)
        else:
            try:
                for i in self.Permission:
                    #print i
                    self.PrintPermission(i)
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print Settings.BugReportMessage
                print "    ", (exc_type, fname, exc_tb.tb_lineno)

def EstablishUserGroupVariables(self):
    self.Rank = {}

class SpawnUserGroupObject:
    def __init__(self):
        EstablishUserGroupVariables(self);
        self.Rank["Number"] = 0
        self.Rank["Reason"] = ""
        self.Rank["By"] = ""
        self.Rank["Previous"] = 0
        self.Rank["Date"] = (-1, -1, -1)
class SpawnUser:
    def EstablishUserVariables(self):
        self.Group = {}
        self.Info = {}
        self.Kills = {}
        self.FlightStart = {}
        self.Flight = {}
        self.Info["ClientID"] = -1
        self.Info["DisplayedName"] = ""
        self.Info["FeedName"] = ""
        self.Info["IPAddress"] = "0.0.0.0"
        self.Info["LoginCount"] = 0
        self.Info["MessagesTyped"] = 0
        self.Info["JoinDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["LastVisit"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["PlayTime"] = datetime.timedelta(seconds=0)
        self.Info["Kills"] = 0
        self.Info["Deaths"] = 0
        self.Info["FlightsFlown"] = 0
        self.Info["FlightHours"] = datetime.timedelta(seconds=0)
        self.Info["Banned"] = 0
        self.Info["BannedBy"] = ""
        self.Info["BanDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["BanExpires"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["BanReason"] = ""
        self.Info["Frozen"] = 0
        self.Info["FrozenBy"] = ""
        self.Info["FreezeDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["FreezeExpires"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["FreezeReason"] = ""
        self.Info["Muted"] = 0
        self.Info["MutedBy"] = ""
        self.Info["MuteDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["MuteExpires"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["MuteReason"] = ""
        self.Info["KickedBy"] = ""
        self.Info["KickReason"] = ""
        self.Info["KickDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        self.Info["TimesKicked"] = 0
        self.Info["KickedPlayers"] = 0
        self.Info["BannedPlayers"] = 0
        self.Info["MutedPlayers"] = 0
        self.Info["FrozenPlayers"] = 0
        self.Info["Hidden"] = 0
        self.Info["Represent"] = ServerInfo.MasterGroup
        self.Kills["Assist"] = []
        self.Kills["LastAssist"] = ""
        self.Kills["Killed"] = False
        self.Kills["Killers"] = ""
        self.FlightStart["ID"] = 0
        self.FlightStart["IFF"] = 0
        self.FlightStart["xpos"] = 0.0
        self.FlightStart["ypos"] = 0.0
        self.FlightStart["zpos"] = 0.0
        self.FlightStart["xrot"] = 0.0
        self.FlightStart["yrot"] = 0.0
        self.FlightStart["zrot"] = 0.0
        self.FlightStart["xspd"] = 0.0
        self.FlightStart["yspd"] = 0.0
        self.FlightStart["zspd"] = 0.0
        self.FlightStart["Aircraft"] = ""
        self.FlightStart["GroundID"] = 0
        self.FlightStart["Flag"] = 0
        self.Flight["ID"] = 0
        self.Flight["IFF"] = 0
        self.Flight["xpos"] = 0.0
        self.Flight["ypos"] = 0.0
        self.Flight["zpos"] = 0.0
        self.Flight["xrot"] = 0.0
        self.Flight["yrot"] = 0.0
        self.Flight["zrot"] = 0.0
        self.Flight["xspd"] = 0.0
        self.Flight["yspd"] = 0.0
        self.Flight["zspd"] = 0.0
        self.Flight["Aircraft"] = ""
        self.Flight["GroundID"] = 0
        self.Flight["Flag"] = 0
        self.Flight["BeginFlag"] = True
        
        
    def AddToGroup(target, group, rank, host):
        if not UserExists(host.Username):
            SendCommandBackward(host, 'User not found: "' + str(host.Username) + '".')
            return -1
        if not UserExists(target.Username):
            SendCommandBackward(host, 'User not found: "' + str(target.Username) + '".')
            return -1
        if GroupExists(group):
            if UserInGroup(target, group):
                SendCommandBackward(host, '"' + target.Username + '" is already a member of group "' + group + '"')
                return -2
            rankold = rank
            rank = GroupGetRank(group, rank)
            if rank < 0:
                SendCommandBackward(host, 'Rank not found: ' + rankold + '')
                return -1
            if AdminOverride(host):
                User[target.Username].AddToGroupOverride(group, rank, host)
                return 0
            if not UserInGroup(host, group):
                SendCommandBackward(host, 'You cannot add "' + target.Username + '" to the group "' + group + '" because you are not a member of that group to begin with.')
                return -1
            if PermissionsTest(host, group, "CanAddToGroup") >= 1:
                if GroupRelativePower(host, group, "MaxPromote") >= rank:
                    User[target.Username].AddToGroupOverride(group, rank, host)
                else:
                    #print 'failed to induct due to rank'
                    SendCommandBackward(host, 'Cannot add "' + target.Username + '" to group "' + str(group) + '" at rank "' + Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName + "]. You Can't Promote members to that rank.")
            else:
                #print 'failed to induct due to no permission'
                SendCommandBackward(host, 'Cannot add "' + target.Username + '". Your rank is unable to induct users to the group')
        else:
            SendCommandBackward(host, 'Group not found: "' + str(group) + '".')
    
    def AddToGroupOverride(target, group, rank, host):
        target.Group[group] = SpawnUserGroupObject();
        target.Group[group].Rank["Number"] = rank
        target.Group[group].Rank["Previous"] = rank
        WriteUserToDatabase(target.Username)
        m = str(User[target.Username].Info["DisplayedName"]) + ' was added to Group "' + str(group) + '" at rank "' + str(Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName) + '" by ' + str(User[host.Username].Info["DisplayedName"]) + "."
        SendCommandForward(host, m)
    def RemoveFromGroup(target, group, host):
        if not UserExists(host.Username):
            SendCommandBackward(host, 'User not found: "' + str(host.Username) + '".')
            return -1
        if not UserExists(target.Username):
            SendCommandBackward(host, 'User not found: "' + str(target.Username) + '".')
            return -1
        if GroupExists(group):
            if not UserInGroup(target, group):
                SendCommandBackward(host, '"' + target.Username + '" is not a member of group "' + group + '"')
                return -2
            if AdminOverride(host):
                User[target.Username].RemoveFromGroupOverride(group, host)
                return 0
            if not UserInGroup(host, group):
                SendCommandBackward(host, 'You cannot remove "' + target.Username + '" from the group "' + group + '" because you are not a member of that group to begin with.')
                return -1
            if PermissionsTest(host, group, "CanRemoveFromGroup") == True:
                if GroupRelativePower(host, group, "MaxDemote") >= target.Group[group].Rank["Number"]:
                    User[target.Username].RemoveFromGroupOverride(group, host)
                else:
                    #print 'failed to remove due to rank'
                    SendCommandBackward(host, 'Cannot remove "' + target.Username + '" from group "' + str(group) + '" at rank "' + Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName + "]. You Can't Promote members to that rank.")
            else:
                #print 'failed to remove due to no permission'
                SendCommandBackward(host, 'Cannot remove "' + target.Username + '" from group "' + str(group) + '". Your rank is unable to remove users from the group')
        else:
            SendCommandBackward(host, 'Group not found: "' + str(group) + '".')
    
    def RemoveFromGroupOverride(target, group, host):
        del target.Group[group]
        WriteUserToDatabase(target.Username)
        m = str(User[target.Username].Info["DisplayedName"]) + ' was removed from group "' + str(group) + ' by ' + str(User[host.Username].Info["DisplayedName"]) + "."
        SendCommandForward(host, m)
    
    def GetRank(self, groupname):
            return Group[groupname].Rank[int(self.Group[groupname].Rank["Number"])].RankName + " (" + Group[groupname].Rank[int(self.Group[groupname].Rank["Number"])].RankNameFull + ")"
    def PrintRank(self, groupname):
            print self.Username + "'s Rank in " + groupname + " is: " + self.GetRank(groupname)
    def PrintAllRanks(self):
            for i in self.Group:
                self.PrintRank(i)
    def GetPermission(self, permname):
            return self.Permission[permname]
    def PrintPermission(self, permname):
            #print permname
            if (permname == "AllowAircraft"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.Username + " is Allowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
            elif (permname == "DenyAircraft"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.Username + " is Disallowed to use Aircraft: " + self.GetPermission(permname).keys()[0]
                        
            elif (permname == "AllowWeapon"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.Username + " is Allowed to use Weapon: " + self.GetPermission(permname).keys()[0]
                        
            elif (permname == "DenyWeapon"):
                for i in self.GetPermission(permname):
                    #print int(self.GetPermission(permname)[i])
                    if (int(self.GetPermission(permname)[i]) >= 1):
                        print self.Username + " is Disallowed to use Weapon: " + self.GetPermission(permname).keys()[0]
            else:
                print self.Username + "'s Permission Setting for " + permname + " is: " + str(self.GetPermission(permname))
    def PrintAllPermissions(self):
            for i in self.Permission:
                #print i
                self.PrintPermission(i)
    def PrintInfo(self, info):
            print self.Username + "'s Information for: " + info + " is: " + str(self.Info[info])
    def PrintAllInfo(self):
            for i in self.Info.keys():
                #print i
                self.PrintInfo(i)
    def Promote(target, host, group, rank, reason):
        if not UserExists(host.Username):
            SendCommandBackward(host, 'User not found: "' + str(host.Username) + '".')
            return -1
        if not UserExists(target.Username):
            SendCommandBackward(host, 'User not found: "' + str(target.Username) + '".')
            return -1
        if GroupExists(group):
            if not UserInGroup(target, group):
                SendCommandBackward(host, '"' + target.Username + '" is not a member of group "' + group + '"')
                return -2
            rankold = rank
            rank = GroupGetRank(group, rank)
            if rank < 0:
                SendCommandBackward(host, 'Rank not found: ' + rankold + '')
                return -1             
            if (int(User[target.Username].Group[group].Rank["Number"]) >= int(rank)):
                SendCommandBackward(host, target.Username + "'s rank ([" + str(group) + "][" + str(Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName) + "]) is not lower then the rank specified ([" + group + "][" + Group[group].Rank[int(rank)].RankName + "]).")
                return -2
            if AdminOverride(host):
                User[target.Username].PromoteOverride(host, group, rank, reason)
                return 0
            if not UserInGroup(host, group):
                SendCommandBackward(host, 'You cannot promote "' + target.Username + '" in the group "' + group + '" because you are not a member of that group to begin with.')
                return -1  
            if GroupRelativePower(host, group, "MaxPromote") >= rank:
                User[target.Username].DemoteOverride(host, group, rank, reason)  
            else:
                SendCommandBackward(host, "Cannot promote " + target.Username + " from [" + str(group) + "][" + str(Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName) + "] to [" + group + "][" + Group[group].Rank[int(rank)].RankName + "]. Your rank is unable to promote that high.")
        else:
            SendCommandBackward(host, 'Group not found: "' + str(group) + '".')        
    
            
    
    def PromoteOverride(target, host, group, rank, reason):
        target.Group[group].Rank["Previous"] = int(target.Group[group].Rank["Number"])
        target.Group[group].Rank["Number"] = int(rank)
        target.Group[group].Rank["By"] = User[host.Username].Username
        target.Group[group].Rank["Reason"] = reason
        target.Group[group].Rank["Date"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        WriteUserToDatabase(target.Username)
        m = str(target.Username) + " was promoted from [" + str(group) + "][" + str(Group[group].Rank[int(target.Group[group].Rank["Previous"])].RankName) + "] to [" + group + "][" + Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName + "] by " + target.Group[group].Rank["By"] + "."
        SendCommandForward(host, m)
        if (len(target.Group[group].Rank["Reason"]) > 0):
            m = "Reason: " + target.Group[group].Rank["Reason"]
            SendCommandForward(host, m)
    def Demote(target, host, group, rank, reason):
        if not UserExists(host.Username):
            SendCommandBackward(host, 'User not found: "' + str(host.Username) + '".')
            return -1
        if not UserExists(target.Username):
            SendCommandBackward(host, 'User not found: "' + str(target.Username) + '".')
            return -1
        if GroupExists(group):
            if not UserInGroup(target, group):
                SendCommandBackward(host, '"' + target.Username + '" is not a member of group "' + group + '"')
                return -2
            rankold = rank
            rank = GroupGetRank(group, rank)
            if rank < 0:
                SendCommandBackward(host, 'Rank not found: ' + rankold + '')
                return -1             
            if (int(User[target.Username].Group[group].Rank["Number"]) <= int(rank)):
                SendCommandBackward(host, target.Username + "'s rank ([" + str(group) + "][" + str(Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName) + "]) is not higher then the rank specified ([" + group + "][" + Group[group].Rank[int(rank)].RankName + "]).")
                return -2
            if AdminOverride(host):
                User[target.Username].DemoteOverride(host, group, rank, reason)
                return 0
            if not UserInGroup(host, group):
                SendCommandBackward(host, 'You cannot demote "' + target.Username + '" in the group "' + group + '" because you are not a member of that group to begin with.')
                return -1  
            if GroupRelativePower(host, group, "MaxDemote") >= rank:
                User[target.Username].DemoteOverride(host, group, rank, reason)  
            else:
                SendCommandBackward(host, "Cannot demote " + target.Username + " from [" + str(group) + "][" + str(Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName) + "] to [" + group + "][" + Group[group].Rank[int(rank)].RankName + "]. Your rank is unable to demote theirs.")
        else:
            SendCommandBackward(host, 'Group not found: "' + str(group) + '".')        
    
            
    
    def DemoteOverride(target, host, group, rank, reason):
        target.Group[group].Rank["Previous"] = int(target.Group[group].Rank["Number"])
        target.Group[group].Rank["Number"] = int(rank)
        target.Group[group].Rank["By"] = User[host.Username].Username
        target.Group[group].Rank["Reason"] = reason
        target.Group[group].Rank["Date"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
        WriteUserToDatabase(target.Username)
        m = str(target.Username) + " was promoted from [" + str(group) + "][" + str(Group[group].Rank[int(target.Group[group].Rank["Previous"])].RankName) + "] to [" + group + "][" + Group[group].Rank[int(target.Group[group].Rank["Number"])].RankName + "] by " + target.Group[group].Rank["By"] + "."
        SendCommandForward(host, m)
        if (len(target.Group[group].Rank["Reason"]) > 0):
            m = "Reason: " + target.Group[group].Rank["Reason"]
            SendCommandForward(host, m)
    def Say(self, message):
        #print "say2"
        try:
            usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The logging in user is not a member of the master group.
            usersvalue = 0
        #print str(int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanSay"]) + int(User[self.Username].Permission["CanSay"]))
        if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanSay"]) + int(User[self.Username].Permission["CanSay"]) >= 1):
            #print "passed"
            #print message
            SendCommandForward(User[self.Username].Info["ClientID"], message)
            return 0
        else:
            #print "failed"
            SendCommandBackward(User[self.Username].Info["ClientID"], "You don't have permission to '/say'")
            return -1
                
            
    def Mute(target, reason, host, expiry):
        if (target.Username == host.Username):
            SendCommandBackward(host, "You cannot mute yourself!")
            return -1
        try:
            usersvalue = User[host.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The logging in user is not a member of the master group.
            usersvalue = 0
        try:
            targetsvalue = User[target.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The target user is not a member of the master group.
            targetsvalue = 0
        if AdminOverride(host):
            try:
                User[target.Username].MuteOverride(reason, host, expiry)
                return 0
            except:
                print sys.exc_info()
        if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanMute"]) >= 1):
            if ((int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanMuteRank"])) >= targetsvalue):
                User[target.Username].MuteOverride(reason, host, expiry)
            else:
                SendCommandBackward(host, 'Cannot mute "' + target.Username + '". Your rank is not high enough to mute theirs.')
        else:
            SendCommandBackward(host, 'Cannot mute "' + target.Username + '". Your rank is not able to mute.')
    
    
    def MuteOverride(target, reason, host, expiry):
        if (target.Info["Muted"] < 1):
            target.Info["Muted"] = True
            target.Info["MutedBy"] = User[host.Username].Info["DisplayedName"]
            target.Info["MuteReason"] = reason
            target.Info["MuteDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
            target.Info["MuteExpires"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
            WriteUserToDatabase(target.Username)
            User[host.Username].Info["MutedPlayers"] = int(User[host.Username].Info["MutedPlayers"]) + 1
            WriteUserToDatabase(host.Username)
            m = "You have been MUTED by " + target.Info["MutedBy"] + "."
            if (len(target.Info["MuteReason"]) > 0):
                m += "\nReason: " + target.Info["MuteReason"]
            for username in ServerInfo.UsersOnline:
                if (username == target.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
            m = str(User[target.Username].Info["DisplayedName"]) + " was MUTED by " + target.Info["MutedBy"] + "."
            if (len(target.Info["MuteReason"]) > 0):
                m += "\nReason: " + target.Info["MuteReason"]
            for username in ServerInfo.UsersOnline:
                if (username != target.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
        else:
            m = target.Username + ' is already muted by: "' + target.Info["MutedBy"]+ '".'
            if (len(target.Info["MuteReason"]) > 0):
                m += "\nReason: " + target.Info["MuteReason"]
                SendCommandBackward(host, m)
            else:
                SendCommandBackward(host, m)
    def Unmute(target, reason, host, expiry):
        if (target.Username == host.Username):
            SendCommandBackward(host, "You cannot mute yourself!")
            return -1
        try:
            usersvalue = User[host.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The logging in user is not a member of the master group.
            usersvalue = 0
        try:
            targetsvalue = User[target.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The target user is not a member of the master group.
            targetsvalue = 0
        if AdminOverride(host):
            try:
                User[target.Username].UnmuteOverride(reason, host, expiry)
                return 0
            except:
                print sys.exc_info()
        if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanMute"]) >= 1):
            if ((int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanMuteRank"])) >= targetsvalue):
                User[target.Username].UnmuteOverride(reason, host, expiry)
            else:
                SendCommandBackward(host, 'Cannot unmute "' + target.Username + '". Your rank is not high enough to unmute theirs.')
        else:
            SendCommandBackward(host, 'Cannot unmute "' + target.Username + '". Your rank is not able to unmute.')
    
    
    def UnmuteOverride(target, reason, host, expiry):
        if (target.Info["Muted"] >= 1):
            target.Info["Muted"] = False
            target.Info["MutedBy"] = User[host.Username].Info["DisplayedName"]
            target.Info["MuteReason"] = reason
            target.Info["MuteDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
            target.Info["MuteExpires"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
            WriteUserToDatabase(target.Username)
            User[host.Username].Info["MutedPlayers"] = int(User[host.Username].Info["MutedPlayers"]) + 1
            WriteUserToDatabase(host.Username)
            m = "You have been UNMUTED by " + target.Info["MutedBy"] + "."
            if (len(target.Info["MuteReason"]) > 0):
                m += "\nReason: " + target.Info["MuteReason"]
            for username in ServerInfo.UsersOnline:
                if (username == target.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
            m = str(User[target.Username].Info["DisplayedName"]) + " was UNMUTED by " + target.Info["MutedBy"] + "."
            if (len(target.Info["MuteReason"]) > 0):
                m += "\nReason: " + target.Info["MuteReason"]
            for username in ServerInfo.UsersOnline:
                if (username != target.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
        else:
            m = target.Username + ' is not muted.'
            if (len(target.Info["MuteReason"]) > 0):
                m += "\nReason: " + target.Info["MuteReason"]
                SendCommandBackward(host, m)
            else:
                SendCommandBackward(host, m)
    def Freeze(target, host):
        if (target.Username == host.Username):
            SendCommandBackward(host, "You cannot freeze yourself!")
            return -1
        try:
            usersvalue = User[host.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The logging in user is not a member of the master group.
            usersvalue = 0
        try:
            targetsvalue = User[target.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The target user is not a member of the master group.
            targetsvalue = 0
        if AdminOverride(host):
            try:
                User[target.Username].FreezeOverride(host)
                return 0
            except:
                print sys.exc_info()
        if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanFreeze"]) >= 1):
            if ((int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanFreezeRank"])) >= targetsvalue):
                User[target.Username].FreezeOverride(host)
            else:
                SendCommandBackward(host, 'Cannot freeze "' + target.Username + '". Your rank is not high enough to freeze theirs.')
        else:
            SendCommandBackward(host, 'Cannot freeze "' + target.Username + '". Your rank is not able to freeze.')
    
    
    def FreezeOverride(target, host):
        if (target.Info["Frozen"] < 1):
            target.Info["Frozen"] = True
            target.Info["FrozenBy"] = User[host.Username].Info["DisplayedName"]
            target.Info["FrozenDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
            WriteUserToDatabase(target.Username)
            User[host.Username].Info["FrozenPlayers"] = int(User[host.Username].Info["FrozenPlayers"]) + 1
            WriteUserToDatabase(host.Username)
            m = "You have been FROZEN by " + target.Info["FrozenBy"] + "."
            for username in ServerInfo.UsersOnline:
                if (username == target.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
                    if User[username].Info["ClientID"].Flying == True:
                        SendCommandBackward(User[username].Info["ClientID"], "You can STILL Fly for now, but your position on the server will remain static, and you can not send any damage signals.")
                    User[username].Info["ClientID"].sock.send(Data2Packet(39, pack("I", 0)))
                    User[username].Info["ClientID"].sock.send(Data2Packet(31, pack("I", 0)))
            m = str(User[target.Username].Info["DisplayedName"]) + " was FROZEN by " + target.Info["FrozenBy"] + "."
            for username in ServerInfo.UsersOnline:
                if (username != target.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
        else:
            m = target.Username + ' is already frozen by: "' + target.Info["FrozenBy"]+ '".'
            SendCommandBackward(host, m)
    def UnFreeze(target, host):
        if (target.Username == host.Username):
            SendCommandBackward(host, "You cannot unfreeze yourself!")
            return -1
        try:
            usersvalue = User[host.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The logging in user is not a member of the master group.
            usersvalue = 0
        try:
            targetsvalue = User[target.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The target user is not a member of the master group.
            targetsvalue = 0
        if AdminOverride(host):
            try:
                User[target.Username].UnFreezeOverride(host)
                return 0
            except:
                print sys.exc_info()
        if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanFreeze"]) >= 1):
            if ((int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanFreezeRank"])) >= targetsvalue):
                User[target.Username].UnFreezeOverride(host)
            else:
                SendCommandBackward(host, 'Cannot unfreeze "' + target.Username + '". Your rank is not high enough to unfreeze theirs.')
        else:
            SendCommandBackward(host, 'Cannot unfreeze "' + target.Username + '". Your rank is not able to unfreeze.')
    
    
    def UnFreezeOverride(target, host):
        if (target.Info["Frozen"] >= 1):
            target.Info["Frozen"] = False
            target.Info["FrozenBy"] = User[host.Username].Info["DisplayedName"]
            target.Info["FrozenDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
            WriteUserToDatabase(target.Username)
            m = "You have been UNFROZEN by " + target.Info["FrozenBy"] + "."
            for username in ServerInfo.UsersOnline:
                if (username == target.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
                    User[username].Info["ClientID"].sock.send(Data2Packet(39, pack("I", ServerInfo.WeaponsEnabled)))
                    User[username].Info["ClientID"].sock.send(Data2Packet(31, pack("I", ServerInfo.MissilesEnabled)))
            m = str(User[target.Username].Info["DisplayedName"]) + " was UNFROZEN by " + target.Info["FrozenBy"] + "."
            for username in ServerInfo.UsersOnline:
                if (username != target.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
        else:
            m = target.Username + ' is not frozen.'
            SendCommandBackward(host, m)
    
    def Ban(target, reason, host, expiry):
        if (target.Username == host.Username):
            SendCommandBackward(host, "You cannot ban yourself!")
            return -1
        if AdminOverride(host):
            try:
                User[target.Username].BanOverride(reason, host, expiry)
            except:
                print sys.exc_info()
        if PermissionsTest(host, ServerInfo.MasterGroup, "CanBan"):
            #print 'test1'
            if PermissionsComparison(host, target, ServerInfo.MasterGroup, "CanBanRank"):
                BanOverride(target, reason, host, expiry)
            else:
                SendCommandBackward(host, 'Cannot ban "' + target.Username + '". You rank is not high enough to ban theirs.')
        else:
            SendCommandBackward(host, 'Cannot ban "' + target.Username + '". You rank is not able to ban.')
    
    def BanOverride(self, reason, host, expiry):
        if not InfoTest(self, "Banned"):
            self.Info["Banned"] = True
            self.Info["BannedBy"] = User[host.Username].Info["DisplayedName"]
            self.Info["BanReason"] = reason
            self.Info["BanDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
            self.Info["BanExpires"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
            WriteUserToDatabase(self.Username)
            #print 'write'
            User[host.Username].Info["BannedPlayers"] = int(User[host.Username].Info["BannedPlayers"]) + 1
            WriteUserToDatabase(host.Username)
            m = "You have been BANNED by " + self.Info["BannedBy"] + "."
            if (len(self.Info["BanReason"]) > 0):
                m += "\nReason: " + self.Info["BanReason"]
            for username in ServerInfo.UsersOnline:
                if (username == self.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
            m = str(User[self.Username].Info["DisplayedName"]) + " was BANNED by " + self.Info["BannedBy"] + "."
            if (len(self.Info["BanReason"]) > 0):
                m += "\nReason: " + self.Info["BanReason"]
            for username in ServerInfo.UsersOnline:
                if (username != self.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
            self.Info["ClientID"].close() ##actually kills the client and it's thread!
        else:
            m = self.Username + ' is already banned by: "' + self.Info["BannedBy"]+ '".'
            if (len(self.Info["BanReason"]) > 0):
                m += "\nReason: " + self.Info["BanReason"]
                SendCommandBackward(host, m)
            else:
                SendCommandBackward(host, m)
    def UnBan(target, reason, host, expiry):
        if (target.Username == host.Username) and not AdminOverride(host.Username):
            SendCommandBackward(host, "You cannot unban yourself!\nAlso, You should be logged out! How the fuck are you even on the server!?\nIMPOSSIBRU!")
            return -1
        if AdminOverride(host):
            try:
                User[target.Username].UnBanOverride(reason, host, expiry)
            except:
                print sys.exc_info()
        if PermissionsTest(host, ServerInfo.MasterGroup, "CanBan"):
            if PermissionsComparison(host, target, ServerInfo.MasterGroup, "CanBanRank"):
                BanOverride(target, reason, host, expiry)
            else:
                SendCommandBackward(host, 'Cannot unban "' + target.Username + '". You rank is not high enough to unban theirs.')
        else:
            SendCommandBackward(host, 'Cannot unban "' + target.Username + '". You rank is not able to unban.')
    
    def UnBanOverride(self, reason, host, expiry):
        if InfoTest(self, "Banned"):
            self.Info["Banned"] = False
            self.Info["BannedBy"] = User[host.Username].Info["DisplayedName"]
            self.Info["BanReason"] = reason
            self.Info["BanDate"] = (-1, -1, -1)
            self.Info["BanExpires"] = (-1, -1, -1)
            WriteUserToDatabase(self.Username)
            m = str(User[self.Username].Info["DisplayedName"]) + " was unbanned by " + self.Info["BannedBy"] + "."
            if (len(self.Info["BanReason"]) > 0):
                m += "\nReason: " + self.Info["BanReason"]
                SendCommandForward(host, m)
            else:
                SendCommandForward(host, m)
        else:
            m = self.Username + ' is not currently banned.'
            SendCommandBackward(host, m)
    def Kick(target, reason, host):
        if (target.Username == host.Username):
            SendCommandBackward(host, "You cannot kick yourself!")
            return -1
        try:
            usersvalue = User[host.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The logging in user is not a member of the master group.
            usersvalue = 0
        try:
            targetsvalue = User[target.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The target user is not a member of the master group.
            targetsvalue = 0
        if AdminOverride(host):
            try:
                User[target.Username].KickOverride(reason, host)
                return 0
            except:
                print sys.exc_info()
        if (int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanKick"]) >= 1):
            if ((int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanKickRank"])) >= targetsvalue):
                User[target.Username].KickOverride(reason, host)
            else:
                SendCommandBackward(host, 'Cannot kick "' + target.Username + '". Your rank is not allowed to kick theirs.')
        else:
            SendCommandBackward(host, 'Cannot kick "' + target.Username + '". Your rank is not able to kick.')
    
    def KickOverride(target, reason, host):
        online = False;
        for username in ServerInfo.UsersOnline:
            if (username == target.Username):
                online = True;
        if online:
            target.Info["KickedBy"] = User[host.Username].Info["DisplayedName"]
            target.Info["KickReason"] = reason
            target.Info["KickDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
            target.Info["TimesKicked"] = int(target.Info["TimesKicked"]) + 1
            User[host.Username].Info["KickedPlayers"] = int(User[host.Username].Info["KickedPlayers"]) + 1
            WriteUserToDatabase(target.Username)
            WriteUserToDatabase(host.Username)
            m = "You have been KICKED by " + target.Info["KickedBy"] + "."
            if (len(target.Info["KickReason"]) > 0):
                m += "\nReason: " + target.Info["KickReason"]
            SendCommandBackward(target.Info["ClientID"], m)
            m = str(User[target.Username].Info["DisplayedName"]) + " was KICKED by " + target.Info["KickedBy"] + "."
            if (len(target.Info["KickReason"]) > 0):
                m += "\nReason: " + target.Info["KickReason"]
            for username in ServerInfo.UsersOnline:
                if (username != target.Username):
                    SendCommandBackward(User[username].Info["ClientID"], m)
            time.sleep(0.25)
            target.Info["ClientID"].close() ##actually kills the client and it's thread!
        else:
            m = target.Username + ' is not online.'
            SendCommandBackward(host, m)
    
    def AllowAircraft(self, name):
            self.Permission.AllowAircraft[name] = 1
            self.Permission.DenyAircraft[name] = 0
    def DenyAircraft(self, name):
            self.Permission.DenyAircraft[name] = 1
            self.Permission.AllowAircraft[name] = 0
    def AllowWeapon(self, name):
            self.Permission.AllowWeapon[name] = 1
            self.Permission.DenyWeapon[name] = 0
    def DenyWeapon(self, name):
            self.Permission.DenyWeapon[name] = 1
            self.Permission.AllowWeapon[name] = 0
    
    def __init__(self, name):
        self.EstablishUserVariables();
        self.Username = name
        self.Info["DisplayedName"] = name
        self.Permission = {}
        SetPermissions(self)

def UserExists(user):
    try:
        test = User[user]
        return True
    except:
        return False
User = {}
print 'Done\n\n'

print "Loading The Database...\n\n"

print "Reading Groups:"
print "==============="
import os
path = "Database/GROUPS/"
dirlist = os.listdir(path)
for fname in dirlist:
    if (fname.lower() [-4:] == ".txt"):
        print "    Got A Group: " + fname[0:-4]
        fopen = open(path + fname, "r")
        ThisGroupName = "Null"
        for line in fopen:
            if (len(line) > 0):
                line = line.replace("\r", "")
                line = line.replace("\n", "")
                #print "Data: " + line
                while chr(10) in line:
                    #print "line > 0"
                    try:
                        #print "thingy"
                        line = line.replace(chr(10), "")
                        #print "got one"
                    except:
                        break
                line = line.split("\t")
                #print line
                while len(line) > 0:
                    try:
                        line.remove("")
                    except:
                        break
                #print line[0]
                #print line[1]
                if len(line) == 2:
                    key = line[0]
                    value = line[1]
                    #print line[0]
                    #print line[1]
                    #print ord(value[-1])
                    #print "Key: $" + key + "$ Value: $" + value + "$"
                    #print key
                    if (key == "GROUPNAME"):
                        ThisGroupName = value
                        #print ThisGroupName
                        #print "got the groupname"
                        Group[ThisGroupName] = SpawnGroup(value)
                    elif (ThisGroupName != "Null"):
                        #print ThisGroupName
                        if key == "FULLNAME":
                            #print "got the fullname"
                            Group[ThisGroupName].FullName = value
                        elif key == "RANK":
                            Group[ThisGroupName].AddRank(value.split("|")[0], value.split("|")[1])
                            ranknumber = len(Group[ThisGroupName].Rank)-1
                            rankname = value.split("|")[0]
                            rankpath = "Database/GROUPS/" + ThisGroupName + "/PERMISSIONS/"
                            #print rankname
                            import os
                            ##inherit rankname
                            ##inherit ranknumber
                            ##inherit rankpath
                            
                            dirlist = os.listdir(rankpath)
                            for fname in dirlist:
                                #print fname
                                #print fname[:-4].lower()
                                #print str(ranknumber).lower()
                                if (fname[:-4].lower() == str(ranknumber).lower()):
                                    #print "Got Permissions For Rank: " + rankname
                                    fopen = open(rankpath + fname, "r")
                                    for line in fopen:
                                        if (len(line) > 0):
                                            line.replace("\r", "")
                                            #print "Data: " + line
                                            while chr(10) in line:
                                                #print "line > 0"
                                                try:
                                                    #print "thingy"
                                                    line = line.replace(chr(10), "")
                                                    #print "got one"
                                                except:
                                                    break
                                            line = line.split("\t")
                                            #print line
                                            while len(line) > 0:
                                                try:
                                                    line.remove("")
                                                except:
                                                    break
                                            #print line[0]
                                            #print line[1]
                                            if len(line) == 2:
                                                key = line[0]
                                                value = line[1]
                                                #print line[0]
                                                #print line[1]
                                                #print ord(value[-1])
                                                #print "Key: $" + key + "$ Value: $" + value + "$"
                                                #print key
                                                #print ThisGroupName
                                                if key == "PERMISSION":
                                                    #print "Got A Permission"
                                                    compare = value.split("|")
                                                    #print compare
                                                    try:
                                                        permname = compare[0]
                                                        permvalue = compare[1]
                                                    except:
                                                        print "        Got a bugged permission...: " + compare[0]
                                                        break;
                                                    if (permname == "AllowAircraft") or (permname == "DenyAircraft") or (permname == "AllowWeapon") or (permname == "DenyWeapon"):
                                                        try:
                                                            permsetting = compare[2]
                                                            try:
                                                                Group[ThisGroupName].Rank[ranknumber].Permission[permname][permvalue] = permsetting
                                                            except:
                                                                Group[ThisGroupName].Rank[ranknumber].Permission[permname] = {}
                                                                Group[ThisGroupName].Rank[ranknumber].Permission[permname][permvalue] = permsetting
                                                        except:
                                                            print "        Got a bugged permission...: " + compare[0]
                                                            break;                                    
                                                    else:
                                                        Group[ThisGroupName].Rank[ranknumber].Permission[permname] = permvalue
                                    #Group[ThisGroupName].PrintAllPermissions();
                            
                    else:
                        if (ThisGroupName == "Null"):
                            print "    File Doesn't Start With Groupname..."
        fopen.close()
        Group[ThisGroupName].Rank.reverse()
        #Group[ThisGroupName].PrintRanks()
        #Group[ThisGroupName].PrintAllPermissionsForAllRanks()
        #for ThisGroupName in GroupsOnline:
        #print ThisGroupName
        Group[ThisGroupName].Rank.reverse()
        path = "Database/GROUPS/"
        fopen = open(path + ThisGroupName + '.txt', "w")
        fopen.write("GROUPNAME\t" + ThisGroupName + "\n")
        fopen.write("FULLNAME\t" + Group[ThisGroupName].FullName + "\n")
        #print Group[ThisGroupName].Rank
        for rank in enumerate(Group[ThisGroupName].Rank):
            #print rank
            #print rank[0]
            #print rank[1]
            fopen.write("RANK\t\t" + rank[1].RankName + "|" + rank[1].RankNameFull + "\n")
            frank = open(path + ThisGroupName + "/PERMISSIONS/" + str(rank[0]) + '.txt', "w")
            for permission in rank[1].Permission:
                #print permission
                #print rank[1].Permission[permission]
                if (permission == "AllowAircraft") or (permission == "DenyAircraft") or (permission == "AllowWeapon") or (permission == "DenyWeapon"):
                    #print rank[1].Permission[permission].keys()
                    for item in rank[1].Permission[permission].keys():
                        frank.write("PERMISSION\t\t" + permission + "|" + str(item) + "|" + str(rank[1].Permission[permission][item]) + "\n")    
                else:
                    frank.write("PERMISSION\t\t" + permission + "|" + str(rank[1].Permission[permission]) + "\n")
            frank.close()
        fopen.close()
        Group[ThisGroupName].Rank.reverse()
                    
                        
                        

print "\nReading Users:"
print "=============="
import os
path = "Database/USERS/"
dirlist = os.listdir(path)
for fname in dirlist:
    if (fname.lower() [-4:] == ".txt"):
        print "    Got A User: " + fname[0:-4]
        fopen = open(path + fname, "r")
        #print fopen
        ThisUserName = "Null"
        for line in fopen:
            if (len(line) > 0):
                line = line.replace("\r", "")
                line = line.replace("\n", "")
                #print "Data: " + line
                while chr(10) in line:
                    #print "line > 0"
                    try:
                        #print "thingy"
                        line = line.replace(chr(10), "")
                        #print "got one"
                    except:
                        break
                line = line.split("\t")
                #print line
                while len(line) > 0:
                    try:
                        line.remove("")
                    except:
                        break
                #print line[0]
                #print line[1]
                if len(line) == 2:
                    key = line[0]
                    value = line[1]
                    #print line[0]
                    #print line[1]
                    #print ord(value[-1])
                    #print "Key: $" + key + "$ Value: $" + value + "$"
                    #print key
                if (key == "USERNAME"):
                    ThisUserName = value
                    #print ThisUserName
                    #print "got the username"
                    User[ThisUserName] = SpawnUser(value)
                elif (ThisUserName != "Null"):
                    #print ThisUserName
                    if key == "USERNAMEDISPLAYED":
                        #print "got the fullname"
                        User[ThisUserName].Info["DisplayedName"] = value
                    elif key == "GROUP":
                        #print "Got A Usergroup"
                        compare = value.split("|")
                        #print compare
                        try:
                            groupname = Group[compare[0]]
                            #print groupname
                            grouprank = Group[compare[0]].Rank[int(compare[1])-1]
                            #print grouprank
                        except:
                            print "        Got a bugged group...: " + compare[0]
                            break;
                        User[ThisUserName].Group[compare[0]] = SpawnUserGroupObject();
                        User[ThisUserName].Group[compare[0]].Rank["Number"] = int(compare[1])
                        User[ThisUserName].Group[compare[0]].Rank["Previous"] = int(compare[1])
                        #print User[ThisUserName].Group[compare[0]].Rank["Number"]
                        #print Group[compare[0]].Rank
                        if (int(User[ThisUserName].Group[compare[0]].Rank["Number"]) > len(Group[compare[0]].Rank)-1):
                            User[ThisUserName].Group[compare[0]].Rank["Number"] = len(Group[compare[0]].Rank)-1
                        elif (int(User[ThisUserName].Group[compare[0]].Rank["Number"]) < 0):
                            User[ThisUserName].Group[compare[0]].Rank["Number"] = 0
                else:
                    if (ThisUserName == "Null"):
                        print "        File Doesn't Start With Username..."
        fopen.close()
        #print ThisUserName
        #User[ThisUserName].PrintAllRanks();
        #User[ThisUserName].PrintAllPermissions();
        #User[ThisUserName].PrintAllInfo();
        import os
        
        def stringtotuple(variable):
            try:
                #print 'inside str->tuple'
                #print variable
                backup = variable
                variable = variable[1:-1] #'-1, -1, -1'
                #print variable
                variable = variable.replace(" ","") #'-1,-1,-1'
                #print variable
                variable = variable.split(",",2) #-1, -1, -1
                #print variable
                #print variable[0]
                #print variable[1]
                #print variable[2]
                x = ()
                x += ((int(variable[0])),)
                x += ((int(variable[1])),)
                x += ((int(variable[2])),)
                #print x
                #print 'no issues.'
                return x
            except:
                print 'string to tuple error'
                return backup
        
        def stringtodelta(variable):
            try:
                #print 'inside str->delta'
                #print variable
                backup = variable
                variable = variable[1:-1] #'-1, -1, -1'
                #print variable
                variable = variable.replace(" ","") #'-1,-1,-1'
                #print variable
                variable = variable.split(",",6) #-1, -1, -1
                #print variable
                #print variable[0]
                #print variable[1]
                #print variable[2]
                #print variable[3]
                #print variable[4]
                #print variable[5]
                x = ()
                x += ((int(variable[0])),)
                x += ((int(variable[1])),)
                x += ((int(variable[2])),)
                x += ((int(variable[3])),)
                x += ((int(variable[4])),)
                x += ((int(variable[5])),)
                #print x
                #print 'no issues.'
                return x
            except:
                print '        String to delta error'
                return backup
        
        infopath = "Database/USERS/INFO/"
        filename = infopath + ThisUserName + '.txt'
        if os.path.exists(filename) and os.path.isfile(filename):
            #print "    Got Info For User: " + ThisUserName
            finfo = open(filename, "r")
            for line in finfo:
                if (len(line) > 0):
                    line.replace("\r", "")
                    #print "Data: " + line
                    while chr(10) in line:
                        #print "line > 0"
                        try:
                            #print "thingy"
                            line = line.replace(chr(10), "")
                            #print "got one"
                        except:
                            break
                    line = line.split("\t")
                    #print line
                    while len(line) > 0:
                        try:
                            line.remove("")
                        except:
                            break
                    #print line[0]
                    #print line[1]
                    if len(line) == 2:
                        key = line[0]
                        value = line[1]
                        #print line[0]
                        #print line[1]
                        #print ord(value[-1])
                        #print "Key: $" + key + "$ Value: $" + value + "$"
                        #print key
                        #print ThisUserName
                        if key == "INFO":
                            #print "Got A Permission"
                            compare = value.split("|")
                            #print compare
                            try:
                                infoname = compare[0]
                                try:
                                    #print 'nested try success.'
                                    infovalue = compare[1]
                                    if (str(infovalue).lower() == "true"):
                                        infovalue = True
                                    elif (str(infovalue).lower() == "false"):
                                        infovalue = False
                                    else:
                                        try:
                                            infovalue = int(infovalue)
                                        except:
                                            pass
                                except:
                                    print '        Some Error Reading User Info:', compare[0], '|', compare[1]
                                    infovalue = ""
                                try:
                                    if (infovalue[0] == "(") and (infovalue[-1] == ")") and ((infoname != 'PlayTime') and (infoname != 'FlightHours')):
                                        #print infoname
                                        #surely this is a date.
                                        #print 'got a date'
                                        infovalue = stringtotuple(infovalue)
                                except:
                                    pass
                                try:
                                    if (infoname == 'PlayTime') or (infoname == 'FlightHours'):
                                        #print infoname
                                        #print 'playtime'
                                        #print infovalue
                                        infovalue = stringtodelta(infovalue)
                                        #print infovalue
                                        #print int(infovalue[0])
                                        #print int(infovalue[1])
                                        #print int(infovalue[2])
                                        #print int(infovalue[3])
                                        #print int(infovalue[4])
                                        #print int(infovalue[5])
                                        #print 'all values read correctly.'
                                        infovalue = datetime.timedelta(weeks=int(infovalue[0]), days=int(infovalue[1]), hours=int(infovalue[2]), minutes=int(infovalue[3]), seconds=int(infovalue[4]), microseconds=int(infovalue[5]))
                                        #print 'infovalue sucessfully applied.'
                                        #print infoname, ':',  infovalue
                                except:
                                    if (infoname == 'PlayTime') or (info == 'FlightHours'):
                                        print ThisUserName,  infoname, 'Read Error.'
                                        infovalue = datetime.timedelta(seconds=0)
                            except:
                                print "        Got a bugged info...: " + compare[0]
                            else:
                                try:
                                    if (infoname != 'PlayTime') and (infoname != 'FlightHours'):
                                        User[ThisUserName].Info[infoname] = int(infovalue)
                                    else:
                                        User[ThisUserName].Info[infoname] = infovalue
                                except:
                                    User[ThisUserName].Info[infoname] = infovalue
            finfo.close()
            #User[ThisUserName].PrintAllInfo();
        
        import os
        permpath = "Database/USERS/PERMISSIONS/"
        dirlist = os.listdir(permpath)
        filename = infopath + ThisUserName + '.txt'
        if os.path.exists(filename) and os.path.isfile(filename):
            #print "Got Permissions For User: " + ThisUserName
            fperm = open(permpath + fname, "r")
            for line in fperm:
                if (len(line) > 0):
                    line.replace("\r", "")
                    #print "Data: " + line
                    while chr(10) in line:
                        #print "line > 0"
                        try:
                            #print "thingy"
                            line = line.replace(chr(10), "")
                            #print "got one"
                        except:
                            break
                    line = line.split("\t")
                    #print line
                    while len(line) > 0:
                        try:
                            line.remove("")
                        except:
                            break
                    #print line[0]
                    #print line[1]
                    if len(line) == 2:
                        key = line[0]
                        value = line[1]
                        #print line[0]
                        #print line[1]
                        #print ord(value[-1])
                        #print "Key: $" + key + "$ Value: $" + value + "$"
                        #print key
                        #print ThisUserName
                        if key == "PERMISSION":
                            #print "Got A Permission"
                            compare = value.split("|")
                            #print compare
                            try:
                                permname = compare[0]
                                permvalue = compare[1]
                            except:
                                print "        Got a bugged permission...: " + compare[0]
                                break;
                            if (permname == "AllowAircraft") or (permname == "DenyAircraft") or (permname == "AllowWeapon") or (permname == "DenyWeapon"):
                                try:
                                    permsetting = compare[2]
                                    try:
                                        User[ThisUserName].Permission[permname][permvalue] = permsetting
                                    except:
                                        User[ThisUserName].Permission[permname] = {}
                                        User[ThisUserName].Permission[permname][permvalue] = permsetting
                                except:
                                    print "        Got a bugged permission...: " + compare[0]
                                    break;                                    
                            else:
                                User[ThisUserName].Permission[permname] = permvalue
            #print fperm
            fperm.close()
            #User[ThisUserName].PrintAllPermissions();
        
#for ThisUserName in UsersOnline:
#print ThisUserName
def WriteUserToDatabase(ThisUserName):
    if ThisUserName.lower() == "php bot" or ThisUserName.lower() == ServerInfo.ConsoleName.lower():
        return -1
    path = "Database/USERS/"
    fopen = open(path + ThisUserName + '.txt', "w")
    fopen.write("USERNAME\t\t" + ThisUserName + "\n")
    fopen.write("USERNAMEDISPLAYED\t" + User[ThisUserName].Info["DisplayedName"] + "\n")
    #print User[ThisUserName].Group.keys()
    for group in User[ThisUserName].Group.keys():
        fopen.write("GROUP\t\t\t" + group + "|" + str(User[ThisUserName].Group[group].Rank["Number"]) + "\n")
    fopen.close()
    fopen = open(path + "INFO/" + ThisUserName + '.txt', "w")
    for info in User[ThisUserName].Info:
        if info == 'FeedName' or info == 'ClientID':
            pass
        elif not (info == 'PlayTime') and not (info == 'FlightHours'):
            fopen.write("INFO\t\t\t" + info + "|" + str(User[ThisUserName].Info[info]) + "\n")
        elif (info == 'PlayTime') or (info == 'FlightHours'):
            try:
                weeks = str(User[ThisUserName].Info[info].weeks)
            except:
                weeks = 0
            try:
                days = str(User[ThisUserName].Info[info].days)
            except:
                days = 0
            try:
                hours = str(User[ThisUserName].Info[info].hours)
            except:
                hours = 0
            try:
                minutes = str(User[ThisUserName].Info[info].minutes)
            except:
                minutes = 0
            try:
                seconds = str(User[ThisUserName].Info[info].seconds)
            except:
                seconds = 0
            try:
                microseconds = str(User[ThisUserName].Info[info].microseconds)
            except:
                microseconds = 0
            final = "(" + str(weeks)
            final += ", " + str(days)
            final += ", " + str(hours)
            final += ", " + str(minutes)
            final += ", " + str(seconds)
            final += ", " + str(microseconds) + ")"
            #print final
            fopen.write("INFO\t\t\t" + info + "|" + final + "\n")
            
    fopen.close()
    fopen = open(path + "PERMISSIONS/" + ThisUserName + '.txt', "w")    
    for permission in User[ThisUserName].Permission:
        #print permission
        #print User[ThisUserName].Permission[permission]
        if (permission == "AllowAircraft") or (permission == "DenyAircraft") or (permission == "AllowWeapon") or (permission == "DenyWeapon"):
            #print User[ThisUserName].Permission[permission].keys()
            for item in User[ThisUserName].Permission[permission].keys():
                fopen.write("PERMISSION\t\t" + permission + "|" + str(item) + "|" + str(User[ThisUserName].Permission[permission][item]) + "\n")    
        else:
            fopen.write("PERMISSION\t\t" + permission + "|" + str(User[ThisUserName].Permission[permission]) + "\n")
    fopen.close()
            
                
                

print "\nDatabase Loading Complete!\n\n"

try:
    test = ServerInfo.ConsoleName
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER CONSOLE NAME WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER CONSOLE (ServerInfo.ConsoleName) IS LISTED!(A matching user in the database is NOT needed.)\n'
    MasterClose(Message, 30)

try:
    test = ServerInfo.AdminName
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER OWNER NAME WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER OWNER (ServerInfo.AdminName) IS LISTED! (A matching user in the database is NOT needed.)\n'
    MasterClose(Message, 30)
    
try:
    test = ServerInfo.AdminPass
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER OWNER PASSWORD WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE _SETTINGS.PY TO ENSURE THE SERVER OWNER PASSWORD (ServerInfo.AdminPass) IS LISTED!\n'
    MasterClose(Message, 30)

try:
    test = Settings.ServerIP
except:
    Settings.ServerIP = '127.0.0.1'
    print "Warning: No ServerIP set in the settings files, using 127.0.0.1 (THIS PC).\n"

Message = '\n!!! MASTER CAUTION !!!:\n\nTHE SERVER IP ADDRESS TO CONNECT TO IS NOT AN INTERNAL IP ADDRESS.\n\nFOR SECURITY, ORB CANNOT CONNECT TO EXTERNAL IPADDRESSES.\n\nSPEAK TO OFFICERFLAKE, OR APPLY FOR A DEVELOPERS LICENCE TO BYPASS THIS\nLIMITATION.\n'
if ((Settings.ServerIP != '127.0.0.1') and
    (Settings.ServerIP[0:7] != '192.168') and
    (Settings.ServerIP[0:7] != '172.16.') and
    (Settings.ServerIP[0:7] != '172.17.') and
    (Settings.ServerIP[0:7] != '172.18.') and
    (Settings.ServerIP[0:7] != '172.19.') and
    (Settings.ServerIP[0:7] != '172.30.') and
    (Settings.ServerIP[0:7] != '172.31.') and
    (Settings.ServerIP[0:3] != '10.')):
        if (Settings.ServerIP[0:5] == '172.2'):
            if (Settings.ServerIP[6] == '.'):
                pass
            else:
                MasterClose(Message, 30)
        else:
            MasterClose(Message, 30)

try:
    test = Group[ServerInfo.MasterGroup]
except:
    Message = '\n!!! MASTER CAUTION !!!:\n\nTHE MASTER GROUP, ' + str(ServerInfo.MasterGroup) + ', WAS NOT FOUND!\n\nTHE SERVER HAS FORCED EXIT!\n\nPLEASE CHECK THE DATABASE FOLDER TO ENSURE THE MASTER GROUP IS LISTED CORRECTLY, AND CHECK THE _SETTINGS.PY TO ENSURE THE MASTER GROUP IS REFERENCED CORRECTLY.\n'
    MasterClose(Message, 30)


import socket
import sys
import thread
import select
import time
from struct import pack, unpack

#WE NEED TO LOAD THE MODULES FIRST
import select
import errno

def RecvPacket2Data(self):
    try:
        test = overflow
    except:
        overflow = ''
    try:
        test = error
    except:
        error = 0
    try:
        datalength = 0
        if len(overflow) == 0:
            buffer_data = self.sock.recv(4)
        else:
            buffer_data = overflow[0:4]
            overflow = overflow[4:]
        #print buffer_data
        #print len(buffer_data)
        if (len(buffer_data) <= 0) and not self.closing:
            #print "Data error: socket returns no data. Client Dc'd?"
            error += 1
            if error > 1:
                error = 0
                print "Something went wrong twice in a row. This probably means the client has disconnected, or the internet is really crap today... Sorry if I'm wrong!"
                return -2, -2, -2
            else:
                return -1, -1, -1
        datalength = unpack("I",buffer_data[0:4])[0]
        #print "Expected length: " + str(datalength)
        #buffer_data = overflow
        if len(overflow) == 0:
            buffer_data = self.sock.recv(datalength)
        else:
            buffer_data = self.sock.recv(datalength - len(overflow))
            overflow = ''
        #print "Length received: " + str(len(buffer_data))
        #print Packet2Hex(buffer_data)
        while len(buffer_data) < datalength and not self.closing:
            if Settings.VerboseDebug:
                print "TCP/IP Protocal broke a Packet into pieces. Reconstructing..."
            #print len(buffer_data)
            #print datalength
            buffer_data += self.sock.recv(datalength - len(buffer_data))
        if len(buffer_data) > datalength and not self.closing:
            if Settings.VerboseDebug:
                print "TCP/IP Protocal broke a Packet into pieces. Reconstructing..."
            overflow = buffer_data[datalength:]
        #overflow = buffer_data[datalength:]
        #buffer_data = buffer_data[0:datalength]
        #if len(buffer_data) != datalength and not self.closing:
        #    print "data error: packet size received is not the correct size expected."
        #    error += 1
        #    if error > 1:
        #        print 'The overflow is causing an error... Flushing It.'
        #        #flush the buffer!
        #        try:
        #            overflow = self.sock.recv(8192)
        #        except:
        #            print 'Buffer Flush Overflow'
        #        overflow = ''
        #    return -1, -1, -1
        #print buffer_data
        #print len(buffer_data)
        #print buffer_data[0:4]
        #print len(buffer_data[0:4])
        if not self.closing and len(buffer_data) >= 4:
            datatype = unpack("I",buffer_data[0:4])[0]
            #print "type: " + str(datatype)
            datapayload = unpack(str(datalength-4) + "s",buffer_data[4:])[0]
            #print "load: " + datapayload
            #print "loadsize: " + str(len(datapayload))
            return datalength, datatype, datapayload
        else:
            return -1, -1, -1
    except socket.error, ex:
        (error_number, error_message) = ex
        if (error_number == errno.ECONNABORTED):
            print "Socket Has Been Closed."
            return -2, -2, -2
        else:
            print Settings.BugReportMessage
            print "Traceback Location: PytoYSFHost: RecvPacket2Data: Sockets"
            print error_number
            print error_message
            return -2, -2, -2
    except Exception, ex:
        print Settings.BugReportMessage
        print "Traceback Location: PytoYSFHost: RecvPacket2Data: Other"
        try:
            (error_number, error_message) = ex
            print error_number
            print error_message
        except:
            print ex
        return -2, -2, -2

def Packet2Data(databuffer):
    try:
        datalength = unpack("I",databuffer[0:3])[0]
        datatype = unpack("I",databuffer[4:7])[0]
        datapayload = unpack(str(datalength-4) + "s",len(databuffer[8:]))[0]
        return datalength, datatype, datapayload
    except:
        print self.Username, "Sent A Bugged Packet."
        return 4, 17, "\0\0\0\0"

def Data2Packet(datatype, data):
    try:
        return pack("II" + str(len(data)) + "s", 4+len(data), datatype, data)
    except:
        return pack("II4s", 4, 17, "\0\0\0\0")

def Packet2Hex(databuffer):
    try:
        i = 0
        m = ''
        while i < len(databuffer):
            temp = ord(databuffer[i])
            first = temp/16
            if (first == 0):
                first = '0'
            elif (first == 1):
                first = '1'
            elif (first == 2):
                first = '2'
            elif (first == 3):
                first = '3'
            elif (first == 4):
                first = '4'
            elif (first == 5):
                first = '5'
            elif (first == 6):
                first = '6'
            elif (first == 7):
                first = '7'
            elif (first == 8):
                first = '8'
            elif (first == 9):
                first = '9'
            elif (first == 10):
                first = 'A'
            elif (first == 11):
                first = 'B'
            elif (first == 12):
                first = 'C'
            elif (first == 13):
                first = 'D'
            elif (first == 14):
                first = 'E'
            elif (first == 15):
                first = 'F'
            second = temp - (temp/16)*16
            if (second == 0):
                second = '0'
            elif (second == 1):
                second = '1'
            elif (second == 2):
                second = '2'
            elif (second == 3):
                second = '3'
            elif (second == 4):
                second = '4'
            elif (second == 5):
                second = '5'
            elif (second == 6):
                second = '6'
            elif (second == 7):
                second = '7'
            elif (second == 8):
                second = '8'
            elif (second == 9):
                second = '9'
            elif (second == 10):
                second = 'A'
            elif (second == 11):
                second = 'B'
            elif (second == 12):
                second = 'C'
            elif (second == 13):
                second = 'D'
            elif (second == 14):
                second = 'E'
            elif (second == 15):
                second = 'F'
            if len(m) > 0:
                m += ":"
            m += str(first) + str(second)
            i += 1
        return m
    except:
        return -1
##ImportCommands:
def Promote(self, message_in):
        message_in = message_in.split(" ",4)
        if (len(message_in) < 4):
            SendCommandBackward(self, 'Not enough arguments! /Promote requires at least a username, a group and a rank.')
            return 0
        ##0 = command
        ##1 = username
        try:
            target = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = group
        try:
            group = Group[message_in[2]]
            group = message_in[2]
        except:
            SendCommandBackward(self, 'Group not found: ' + message_in[2])
            return -2
        ##3 = rank
        try:
            rank = message_in[3]
        except:
            try:
                rank = User[message_in[1]].Group[message_in[2]].Rank["Number"] - 1
            except:
                rank = 0
                #will result in the script denying the demote, as the user isn't part of the group anyway.
        ##4 = reason                                    
        try:
            reason = message_in[4]
        except:
            reason = ""
        User[message_in[1]].Promote(self, group, rank, reason)

def Demote(self, message_in):
        message_in = message_in.split(" ",4)
        if (len(message_in) < 4):
            SendCommandBackward(self, 'Not enough arguments! /Demote requires at least a username, a group and a rank.')
            return 0
        ##0 = command
        ##1 = username
        try:
            target = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = group
        try:
            group = Group[message_in[2]]
            group = message_in[2]
        except:
            SendCommandBackward(self, 'Group not found: ' + message_in[2])
            return -2
        ##3 = rank
        try:
            rank = message_in[3]
        except:
            try:
                rank = User[message_in[1]].Group[message_in[2]].Rank["Number"] - 1
            except:
                rank = 0
                #will result in the script denying the demote, as the user isn't part of the group anyway.
        ##4 = reason                                    
        try:
            reason = message_in[4]
        except:
            reason = ""
        User[message_in[1]].Demote(self, group, rank, reason)
def Information(self, message_in):
    try:
        #
        #
        #Permissions Test.
        #
        #
        message_in = message_in.split(" ", 1)
        if (len(message_in) < 2):
            target = self.Username
            #print 'uname ' + target
        else:
            target = message_in[1]
            if UserExists(target):
                pass
            else:
                m =  'User Not Found: "' + target + '"'
                SendCommandBackward(self, m)
                return -1
        if AdminOverride(self):
            print 'override'
            InformationOverride(self, target)
        elif PermissionsComparisonOffline(self.Username, target, ServerInfo.MasterGroup, "CanViewOthersInfo") or (self.Username != target):
            m =  'You can not look up information on user "' + User[target].Info["DisplayedName"] + '". Your rank is not able to view others info.'
            SendCommandBackward(self, m)
            return -2
        else:
            print 'Not override'
            InformationOverride(self, target)
    except:
        print sys.exc_info()


def InformationOverride(self, target):
    try:
        InformationOverride_UserOnline(self, target)
        InformationOverride_LoginInfo(self, target)
        InformationOverride_BanInfo(self, target)
        InformationOverride_KickInfo(self, target)
        InformationOverride_FreezeInfo(self, target)
        InformationOverride_KDRInfo(self, target)
        InformationOverride_MessagesTypedInfo(self, target)
        InformationOverride_FlightInfo(self, target)
        InformationOverride_MasterGroupInfo(self, target)
        InformationOverride_PlaytimeInfo(self, target)
    except:
        print sys.exc_info()

def InformationOverride_UserOnline(self, target):
    if (User[target].Info["Hidden"]): #User Is Hidden, We must see if they are able to be seen.
        if not PermissionsComparison(self, target, ServerInfo.MasterGroup, "CanHideFromRank") or not AdminOverride(self):
            m =  "About " + User[target].Info["DisplayedName"] + ": OFFLINE, last seen from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m) #Hidden, can't be seen.
        else: #See if they are online.
            found = False
            for i in ServerInfo.UsersOnline:
                if (i == target):
                    found = True
        if found: #online and can be seen.
            m =  "About " + User[target].Info["DisplayedName"] + ": HIDDEN, connected from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m)
        else: #offline but could be seen.
            m =  "About " + User[target].Info["DisplayedName"] + ": OFFLINE, last seen from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m)
    else: 
        found = False
        for i in ServerInfo.UsersOnline:
            if (i == target):
                found = True
        if found:
            m = "About " + User[target].Info["DisplayedName"] + ": ONLINE, connected from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m)
        else:
            m =  "About " + User[target].Info["DisplayedName"] + ": OFFLINE, last seen from " + User[target].Info["IPAddress"]
            SendCommandBackward(self, m)

def InformationOverride_LoginInfo(self, target):            
    if (User[target].Info["LoginCount"] > 0):
        try:
            if (User[target].Info["JoinDate"] == (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)):
                m = "Logged in " + str(User[target].Info["LoginCount"]) + " time(s), joining today."
            else:
                m = "Logged in " + str(User[target].Info["LoginCount"]) + " time(s) since " + tupletodate(User[target].Info["JoinDate"]) + "."
            SendCommandBackward(self, m)
        except:
            print sys.exc_info()
    else:
        try:
            #m = "Joined Today."
            #SendCommandBackward(self, m)
            print "Login Data Unnavailable"
            pass
        except:
            print sys.exc_info()

def InformationOverride_BanInfo(self, target): 
    if (User[target].Info["Banned"]):
        try:
            m = "BANNED by " + User[target].Info["BannedBy"] + " On " + tupletodate(User[target].Info["BanDate"]) + "."
            SendCommandBackward(self, m)
            m = "Ban Reason: " + User[target].Info["BanReason"]
            SendCommandBackward(self, m)
            m = "Ban Expires: " + tupletodate(User[target].Info["BanExpires"])
            SendCommandBackward(self, m)
        except:
            print sys.exc_info()

def InformationOverride_KickInfo(self, target): 
    if (User[target].Info["TimesKicked"] > 0):
        try:
            m = "Kicked " + str(User[target].Info["TimesKicked"]) + " Time(s). Last kick by " + User[target].Info["KickedBy"] + " On " + tupletodate(User[target].Info["KickDate"]) + "."
            SendCommandBackward(self, m)
            m = "Kick Reason: " + User[target].Info["KickReason"]
            SendCommandBackward(self, m)
        except:
            print sys.exc_info()

def InformationOverride_FreezeInfo(self, target): 
    if (User[target].Info["Frozen"] > 0):
        difference = datetime.datetime.now() - User[target].Info["FrozenDate"]
        try:
            weeks = difference.weeks
        except:
            weeks = 0
        try:
            days = difference.days
        except:
            days = 0
        try:
            hours = difference.hours
        except:
            hours = 0
        try:
            minutes = difference.minutes
        except:
            minutes = 0
        try:
            seconds = difference.seconds
        except:
            seconds = 0
        difference = ""
        if weeks > 0:
            difference = " " + str(weeks) + "w ago."
        elif days > 0:
            difference = " " + str(days) + "d ago."
        elif hours > 0:
            difference = " " + str(hours) + "h ago."
        elif minutes > 0:
            difference = " " + str(minutes) + "m ago."
        elif seconds > 0:
            difference = " " + str(seconds) + "s ago."
        elif weeks == 0 and days == 0 and hours == 0 and minutes == 0 and seconds == 0:
            difference = " now."
        else:
            difference = "."
        m = "Frozen by " + User[User[target].Info["FrozenBy"]].Info["DisplayedName"] + difference
        SendCommandBackward(self, m)

def InformationOverride_KDRInfo(self, target):            
    if (User[target].Info["Deaths"] > 0) or (User[target].Info["Kills"] > 0):
        if (User[target].Info["Deaths"] <= 0):
            m = "Killed " + str(User[target].Info["Kills"]) + " Player(s), Been Killed 0 Times. K:D Ratio: Perfect!"
            SendCommandBackward(self, m)
        else:
            m = "Killed " + str(User[target].Info["Kills"]) + " Player(s), Been Killed " + str(User[target].Info["Deaths"]) + " Times. K:D Ratio: " + str(float(User[target].Info["Kills"])/float(User[target].Info["Deaths"])) + "."
            SendCommandBackward(self, m)

def InformationOverride_MessagesTypedInfo(self, target): 
    if (User[target].Info["MessagesTyped"] > 0):
        m = "Typed " + str(User[target].Info["MessagesTyped"]) + " message(s) in total."
        SendCommandBackward(self, m)

def InformationOverride_FlightInfo(self, target): 
    if (User[target].Info["FlightsFlown"] > 0):
        try:
            hours = float(User[target].Info["FlightHours"].weeks) * 24 * 7
        except:
            hours = float(0)
        try:
            hours += float(User[target].Info["FlightHours"].days) * 24
        except:
            hours += float(0)
        #print hours
        try:
            hours += float(User[target].Info["FlightHours"].hours)
        except:
            pass
        #print hours
        try:
            hours += float(User[target].Info["FlightHours"].minutes)/60
        except:
            pass
        #print hours
        try:
            hours += float(User[target].Info["FlightHours"].seconds)/3600
        except:
            pass
        #print hours
        minutes = str(hours*60)[0:str(hours*60).find('.')+2]
        hours = str(hours)[0:str(hours).find('.')+2]
        m = "Joined Flight " + str(User[target].Info["FlightsFlown"]) + " Time(s), Flying " + str(hours) + " Hour(s) Total(" + str(minutes) + " minutes)."
        SendCommandBackward(self, m)

def InformationOverride_GroupInfo(self, target): 
    for i in User[target].Group.keys():
        #print i
        m = "Info for group: " + i
        SendCommandBackward(self, m)
        #print User[username].Group[i].Rank["Previous"]
        #print User[username].Group[i].Rank["Number"]
        #print len(Group[i].Rank)
        if (int(User[target].Group[i].Rank["Previous"]) > len(Group[i].Rank)-1):
            print "Database Error: Users Previous Rank Exceed The Group Limit!"
            User[target].Group[i].Rank["Previous"] = len(Group[i].Rank)-1
        elif (int(User[target].Group[i].Rank["Previous"]) < 0):
            print "Database Error: Users Previous Rank Less Then Zero!"
            User[target].Group[i].Rank["Previous"] = 0
        if (int(User[target].Group[i].Rank["Previous"]) == int(User[target].Group[i].Rank["Number"])):
            #print Group[i].Rank[int(User[target].Group[i].Rank["Number"])]
            m = "Rank: " + Group[i].Rank[int(User[target].Group[i].Rank["Number"])].RankName
            SendCommandBackward(self, m)
        elif(int(User[target].Group[i].Rank["Previous"]) < int(User[target].Group[i].Rank["Number"])):
            m = "Promoted from " + Group[i].Rank[int(User[target].Group[i].Rank["Previous"])].RankName + " to " + Group[i].Rank[int(User[target].Group[i].Rank["Number"])].RankName + " by " + User[target].Group[i].Rank["By"]+ " on " + tupletodate(User[target].Group[i].Rank["Date"]) + "."
            SendCommandBackward(self, m)
            if (len(User[target].Group[i].Rank["Reason"]) > 0):
                m = "Reason: " + User[target].Group[i].Rank["Reason"]
                SendCommandForward(host, m)
        elif (int(User[target].Group[i].Rank["Previous"]) > int(User[target].Group[i].Rank["Number"])):
            m = "Demoted from " + Group[i].Rank[int(User[target].Group[i].Rank["Previous"])].RankName + " to " + Group[i].Rank[int(User[target].Group[i].Rank["Number"])].RankName + " by " + User[target].Group[i].Rank["By"]+ " on " + tupletodate(User[target].Group[i].Rank["Date"]) + "."
            SendCommandBackward(self, m)
            m = "Reason: " + User[target].Group[i].Rank["Reason"]
            if (len(User[target].Group[i].Rank["Reason"]) > 0):
                m = "Reason: " + User[target].Group[i].Rank["Reason"]
                SendCommandForward(host, m)
        else:
            m = "Rank: " + Group[i].Rank[int(User[target].Group[i].Rank["Number"])].RankName
            SendCommandBackward(self, m)

def InformationOverride_MasterGroupInfo(self, target):
    if UserInGroupOffline(target, ServerInfo.MasterGroup):
        if (int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"]) > len(Group[ServerInfo.MasterGroup].Rank)-1):
            print "Database Error: Users Previous Rank Exceed The Master Groups Limit!"
            User[target].Group[ServerInfo.MasterGroup].Rank["Previous"] = len(Group[ServerInfo.MasterGroup].Rank)-1
        elif (int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"]) < 0):
            print "Database Error: Users Previous Rank Less Then Zero!"
            User[target].Group[ServerInfo.MasterGroup].Rank["Previous"] = 0
        if (int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"]) == int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])):
            #print Group[i].Rank[int(User[target].Group[i].Rank["Number"])]
            m = "Current Rank: " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])].RankName
            SendCommandBackward(self, m)
        elif(int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"]) < int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])):
            m = "Promoted from " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"])].RankName + " to " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])].RankName + " by " + User[User[target].Group[ServerInfo.MasterGroup].Rank["By"]].Info["DisplayedName"] + " on " + tupletodate(User[target].Group[ServerInfo.MasterGroup].Rank["Date"]) + "."
            SendCommandBackward(self, m)
            if (len(User[target].Group[ServerInfo.MasterGroup].Rank["Reason"]) > 0):
                m = "Reason: " + User[target].Group[ServerInfo.MasterGroup].Rank["Reason"]
                SendCommandBackward(self, m)
        elif (int(User[target].Group[SendCommandBackward(self, m)].Rank["Previous"]) > int(User[target].Group[SendCommandBackward(self, m)].Rank["Number"])):
            m = "Demoted from " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Previous"])].RankName + " to " + Group[ServerInfo.MasterGroup].Rank[int(User[target].Group[ServerInfo.MasterGroup].Rank["Number"])].RankName + " by " + User[User[target].Group[ServerInfo.MasterGroup].Rank["By"]].Info["DisplayedName"] + " on " + tupletodate(User[target].Group[ServerInfo.MasterGroup].Rank["Date"]) + "."
            SendCommandBackward(self, m)
            if (len(User[target].Group[ServerInfo.MasterGroup].Rank["Reason"]) > 0):
                m = "Reason: " + User[target].Group[ServerInfo.MasterGroup].Rank["Reason"]
                SendCommandBackward(self, m)
    else:
        m = User[target].Info["DisplayedName"] + " is not an inducted member of the server."
        SendCommandBackward(self, m)
    
        
def InformationOverride_PlaytimeInfo(self, target): 
    try:
        hours = float(User[target].Info["PlayTime"].weeks) * 24 * 7
    except:
        hours = float(0)
    try:
        hours += float(User[target].Info["PlayTime"].days) * 24
    except:
        hours += float(0)
    #print hours
    try:
        hours += float(User[target].Info["PlayTime"].hours)
    except:
        pass
    #print hours
    try:
        hours += float(User[target].Info["PlayTime"].minutes)/60
    except:
        pass
    #print hours
    try:
        hours += float(User[target].Info["PlayTime"].seconds)/3600
    except:
        pass
    #print hours
    minutes = str(hours*60)[0:str(hours*60).find('.')+2]
    hours = str(hours)[0:str(hours).find('.')+2]
    m = "Played for " + str(hours) + " hours in total(" + str(minutes) + " minutes)."
    SendCommandBackward(self, m)
def Players(self):
    m = ""
    for username in ServerInfo.UsersOnline:
        try:
            usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The logging in user is not a member of the master group.
            usersvalue = 0
        #print usersvalue
        try:
            targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The target user is not a member of the master group.
            targetsvalue = 0
        #print targetsvalue
        if (User[username].Info["Hidden"]):
            if not (int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"])  >= int(usersvalue)):
                if (len(m) == 0):
                    m += User[username].Info["DisplayedName"]
                else:
                    m += ", " + User[username].Info["DisplayedName"]
            else:
                #print "hidden user: " + User[username].Info["DisplayedName"]
                pass
        else:
            ##USER IS NOT HIDDEN:
                if (len(m) == 0):
                    m += User[username].Info["DisplayedName"]
                else:
                    m += ", " + User[username].Info["DisplayedName"]
    ##finally,
    SendCommandBackward(self, "Users Online:\n" + m)
def Hide(self):
    if (int(User[self.Username].Info["Hidden"]) == 1):
        SendCommandBackward(self, "You are already hidden.")
    else:
        try:
            usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
        except:
            ##The user is not a member of the master group.
            usersvalue = 0
        #print int(User[self.Username].Permission["CanHide"])
        #print int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanHide"])
        if (int(User[self.Username].Permission["CanHide"]) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanHide"]) >= 1):
            User[self.Username].Info["Hidden"] = 1
            WriteUserToDatabase(self.Username)
            SendCommandBackward(self, "You are now hidden")
            for username in ServerInfo.UsersOnline:
                try:
                    usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
                except:
                    ##The logging in user is not a member of the master group.
                    usersvalue = -1
                try:
                    targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
                except:
                    ##The target user is not a member of the master group.
                    targetsvalue = -1
                if not (username == self.Username):
                    if (int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"])  >= int(usersvalue)):
                        m = User[self.Username].Info["DisplayedName"] + ' is now HIDDEN.'
                        SendCommandBackward(User[username].Info["ClientID"], m)
                    else:
                        SendCommandBackward(User[username].Info["ClientID"], User[self.Username].Info["DisplayedName"] + ' left the server.')
        else:
            SendCommandBackward(self, "Your rank is not high enough to 'Hide'.")

def UnHide(self):
    ##All users should be able to unhide!
    if (int(User[self.Username].Info["Hidden"]) == 0):
        SendCommandBackward(self, "You are not currently hidden.")
    else:
        User[self.Username].Info["Hidden"] = 0
        WriteUserToDatabase(self.Username)
        SendCommandBackward(self, "You are no longer hidden.")
        for username in ServerInfo.UsersOnline:
            try:
                usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
            except:
                ##The logging in user is not a member of the master group.
                usersvalue = -1
            try:
                targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
            except:
                ##The target user is not a member of the master group.
                targetsvalue = -1
            if not (username == self.Username):
                if (int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"])  >= int(usersvalue)):
                    m = User[self.Username].Info["DisplayedName"] + ' is no longer Hidden.'
                    SendCommandBackward(User[username].Info["ClientID"], m)
                else:
                    SendCommandBackward(User[username].Info["ClientID"], User[self.Username].Info["DisplayedName"] + ' joined the server.')
def Add(self, message_in):
        message_in = message_in.split(" ",3)
        if (len(message_in) < 3):
            SendCommandBackward(self, 'Not enough arguments! /Add requires at least a username and a group.')
            return 0
        ##0 = command
        ##1 = username
        try:
            test = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = group
        try:
            test = Group[message_in[2]]
        except:
            SendCommandBackward(self, 'Group not found: ' + message_in[2])
            return -2
        ##3 = rank
        try:
            rank = message_in[3]
        except:
            rank = 0
        User[message_in[1]].AddToGroup(message_in[2], rank, self)

def Remove(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 3):
            SendCommandBackward(self, 'Not enough arguments! /Remove requires at least a username and a group')
            return 0
        ##0 = command
        ##1 = username
        try:
            test = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = group
        try:
            test = Group[message_in[2]]
        except:
            SendCommandBackward(self, 'Group not found: ' + message_in[2])
            return -2
        User[message_in[1]].RemoveFromGroup(message_in[2], self)
def Ban(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 3):
            SendCommandBackward(self, 'Not enough arguments! /ban requires at least a username and a reason.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = reason
        reason = message_in[2]
        ##3 = expires
        try:
            expires = message_in[3]
        except:
            expires = (-1, -1, -1)
        username.Ban(reason, self, expires)

def UnBan(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 3):
            SendCommandBackward(self, 'Not enough arguments! /unban requires at least a username and a reason.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = reason
        reason = message_in[2]
        ##3 = expires
        try:
            expires = message_in[3]
        except:
            expires = (-1, -1, -1)
        username.UnBan(reason, self, expires)
def Mute(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /mute requires at least a username.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = reason
        try:
            reason = message_in[2]
        except:
            reason = ""
        ##3 = expires
        try:
            expires = message_in[3]
        except:
            expires = (-1, -1, -1)
        username.Mute(reason, self, expires)

def UnMute(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /unmute requires at least a username.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = reason
        try:
            reason = message_in[2]
        except:
            reason = ""
        ##3 = expires
        try:
            expires = message_in[3]
        except:
            expires = (-1, -1, -1)
        username.Unmute(reason, self, expires)
def Freeze(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /freeze requires a username.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        username.Freeze(self)

def UnFreeze(self, message_in):
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /unfreeze requires a username.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        username.UnFreeze(self)
def Kick(self, message_in):
        #print message_in
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /kick requires at least a username.')
            return 0
        ##0 = command
        ##1 = username
        try:
            username = User[message_in[1]]
        except:
            SendCommandBackward(self, 'User not found: ' + message_in[1])
            return -1
        ##2 = reason
        try:
                reason = message_in[2]
        except:
                reason = ""
        username.Kick(reason, self)
from time import sleep

def Kill(self, message_in):
        #print message_in
        message_in = message_in.split(" ",2)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /kill requires an object ID.')
            return 0
        ##0 = command
        ##1 = targetID
        try:
            targetID = int(message_in[1])
        except:
            SendCommandBackward(self, 'Target ID not a number! ' + message_in[1])
            return -1
        ##2 = reason
        try:
                reason = message_in[2]
        except:
                reason = ""
        try:
            data = pack("IIIHHHI", 1, targetID, 1, 20, 1, 1, 11)
            ProcessPacket(self, len(data)+8, 22, data)
        except Exception, ex:
            print ex
            sleep(50000)
def Say(self, message_in):
        #print message_in
        message_in = message_in.split(" ",1)
        if (len(message_in) < 2):
            SendCommandBackward(self, 'Not enough arguments! /say requires at least a message.')
            return 0
        ##0 = command
        ##2 = message
        try:
                message = message_in[1]
        except:
                message = ""
        User[self.Username].Say(message)
from random import choice

def PrivateMessage(self, message_in):
    target = message_in.split(" ", 1)[0][1:]
    found = False
    for username in ServerInfo.UsersOnline:
        if username == target:
            found = True
    if not found:
        m = 'User not found: "' + target + '".'
        SendCommandBackward(self, m)
        return -1
    if (target == self.Username):
        m = ['Trying to talk to ourselves are we? Tut tut tut...',
             "I love me... I love me... I'm the best friend I can be...",
             "HAHA LONER!",
             "Stop talking to yourself. It's the first sign of madness.",
             "All work and no play makes jack a dullboy",
             "FOREVERALONE.JPG",
             "FOREVERALONE. LEVEL: YSFLIGHT",
             "You're talking to yourself again. Perhaps It's time for a break?\nPlease enjoy this refreshing beverage!",
             "Mr. T pities the fool whom talks to themselves...",
             "PM From " + User[self.Username].Info["DisplayedName"] + ": Hello? Hello? ... Why doesn't anyone talk to me...",
             "We're Gunna Be Late! WHY WON'T YOU TALK TO ME!?",
             "SUCESS! You talk to yourself! Your shallow lifeless words echo off the servers lifeless empty ears, lost in a pile of 1's and 0's...",
             "ACHIVEMENT GET: BE A COMPLETE NOOB AND TALK TO YOURSELF VIA PRIVATE MESSAGE."]
        print  '(' + self.Username + ' -> ' + target + ')', message_in.split(" ", 1)[1]
        SendCommandBackward(self, choice(m))
        return 0
    for username in ServerInfo.UsersOnline:
        if (username == self.Username):
                print  '(' + self.Username + ' -> ' + target + ')', message_in.split(" ", 1)[1]
                m = "PM To " + User[target].Info["DisplayedName"] + ": " + message_in.split(" ", 1)[1]
                SendCommandBackward(self, m)
        elif (username == target):
                m = "PM From " + User[self.Username].Info["DisplayedName"] + ": " + message_in.split(" ", 1)[1]
                SendCommandBackward(User[target].Info["ClientID"], m)
            
        

def Type32(self, message_in, message_out):
    if (message_in.split(" ")[0].lower() == "/info") or (message_in.split(" ")[0].lower() == "/about"):
        Information(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/players") or (message_in.split(" ")[0].lower() == "/who") or (message_in.split(" ")[0].lower() == "/listuser") or (message_in.split(" ")[0].lower() == "/listusers"):
        Players(self)
    elif (message_in.split(" ")[0].lower() == "/hide") and not User[self.Username].Info["Muted"]:
        Hide(self)
    elif (message_in.split(" ")[0].lower() == "/unhide"):
        UnHide(self)
    elif (message_in.split(" ")[0].lower() == "/promote") and not User[self.Username].Info["Muted"]:
        Promote(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/demote") and not User[self.Username].Info["Muted"]:
        Demote(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/add") and not User[self.Username].Info["Muted"]:
        Add(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/remove") and not User[self.Username].Info["Muted"]:
        Remove(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/ban") and not User[self.Username].Info["Muted"]:
        Ban(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/unban") and not User[self.Username].Info["Muted"]:
        UnBan(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/mute") and not User[self.Username].Info["Muted"]:
        Mute(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/unmute") and not User[self.Username].Info["Muted"]:
        UnMute(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/freeze") or (message_in.split(" ")[0].lower() == "/stop") and not User[self.Username].Info["Muted"]:
        Freeze(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/unfreeze") or (message_in.split(" ")[0].lower() == "/thaw") and not User[self.Username].Info["Muted"]:
        UnFreeze(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/kick") or (message_in.split(" ")[0].lower() == "/boot") and not User[self.Username].Info["Muted"]:
        Kick(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/say") and not User[self.Username].Info["Muted"]:
        Say(self, message_in)
    #elif (message_in.split(" ")[0].lower() == "/kill") and not User[self.Username].Info["Muted"]:
    #    Kill(self, message_in)
    elif (message_in.split(" ")[0].lower() == "/clear") or (message_in.split(" ")[0].lower() == "/cls"):
        i = 0
        x = datetime.datetime.now()
        y = datetime.timedelta(seconds=0.025)
        m = "Cleaning your screen!"
        SendCommandBackward(self, m)
        while i < 16:
            while (x+y > datetime.datetime.now()):
                pass
            x = datetime.datetime.now()
            i += 1
            m = "\n\n\n\n\n\n\n\n"
            SendCommandBackward(self, m)
    elif (message_in.split(" ")[0].lower()[0] == "/"):
        if not (message_in.split(" ")[0].lower()[1] == "/"):
            SendCommandBackward(self, "Command Not Recognised: \"" + message_in + "\"")
            
    if True:
        try:
            if User[self.Username].Info["Muted"]:
                print  '(' + self.Username + '[M] -> ' + self.other.Username + ')', message_in
                SendCommandBackward(self, "You are still muted!")
            else:
                ##Normal Chat Message!
                if (message_in[0] == "@"):
                    PrivateMessage(self, message_in)
                else:
                    #print "not a pm"
                    try:
                        usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
                    except:
                        ##The logging in user is not a member of the master group.
                        usersvalue = -1
                    #print usersvalue
                    if usersvalue >= 0:
                        tag = "[" + str(ServerInfo.MasterGroup) + "]"
                        tag += "["+ str(Group[ServerInfo.MasterGroup].Rank[int(User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"])].RankName) + "]"
                        #print tag
                    else:
                        if len(User[self.Username].Group.keys()) > 0:
                            group = User[self.Username].Group.keys()[0]
                            tag = "[" + group + "]"
                            tag += "["+ str(Group[group].Rank[int(User[self.Username].Group[group].Rank["Number"])].RankName) + "]"
                            #print tag
                        else:
                            tag = ""
                    if (message_in.split(" ")[0].lower()[0] == "/"):
                        if (message_in.split(" ")[0].lower()[1] == "/"):
                            print  '(' + self.Username + ' -> ' + self.other.Username + ') "' + message_in[1:] + "\""
                            m = "(" + tag + User[self.Username].Info["DisplayedName"] + ") \"" + message_in[1:] + "\""
                    else:
                        print  '(' + self.Username + ' -> ' + self.other.Username + ') "' + message_in + "\""
                        m = "(" + tag + User[self.Username].Info["DisplayedName"] + ") \"" + message_in + "\""
                    SendCommandForward(self, m)
        except:
            ##Normal Chat Message/ServerMessage.
            SendCommandForward(self, message_out)

def tupletodate(variable):
	try:
		return str(str(variable[0]) + "/" + str(variable[1]) + "/" + str(variable[2]))
	except:
		print 'tuple to date error'
		return variable
def SendCommandConfirmation(self, message_in):
    ##Function Not Used?
    try:
        self.sock.send(Data2Packet(datatype, String2Message("*(" + self.username + ")" + message_in)))
    except:
        pass #socket closed.

def SendCommandForward(self, message_out):
    try:
        self.other.sock.send(Data2Packet(32, String2Message(message_out)))
    except:
        pass #socket closed.
    
def SendCommandBackward(self, message_out):
    try:
        self.sock.send(Data2Packet(32, String2Message(message_out)))
    except:
        pass #socket closed.
    
def String2Message(data):
    try:
        return pack("8s" + str(len(data)) + "s" + "1s", "\0", data, "\0")
    except:
        return pack("8s" + str(len("\0")) + "s" + "1s", "\0", "\0", "\0")
        pass #socket closed.
    
def String2Data(data):
    try:
        return len(pack("8s" + str(len(data)) + "s" + "1s", "\0", data, "\0"))+4, 32, pack("8s" + str(len(data)) + "s" + "1s", "\0", data, "\0")
    except:
        return len(pack("8s" + str(len("\0")) + "s" + "1s", "\0", "\0", "\0"))+4, 32, pack("8s" + str(len("\0")) + "s" + "1s", "\0", "\0", "\0")
        pass #socket closed.
    
def Message2String(data):
    try:
        data = unpack(str(len(data)) + "s", data)[0]
        return data.strip("\0")
    except:
        return ""
        pass #socket closed.

def SendString(self, data):
    try:
        self.sock.send(Data2Packet(32,String2Message(data)))
    except:
        pass #socket closed.

def RecvString(self, data):
    try:
        return Message2String(RecvPacket2Data(self.sock)[2])
    except:
        return ""
        pass #socket closed.
import imp

def FlightDataHost(self, datalength, datatype, datapayload):
##    if True: #Comment This Entire Area Out To Avoid Flight Data Displays.
##        try:
##            test = self.LastFlightTimerID
##        except:
##            self.LastFlightTimerID = 0
##        if unpack("I",datapayload[0:4])[0] - 500000 < self.LastFlightTimerID:
##            return 0
##        else:
##            self.LastFlightTimerID = unpack("I",datapayload[0:4])[0]
    ##Flight Data?
    ##print datapayload
    #print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Flight Data.'
    timer = unpack("I",datapayload[0:4])[0]
    #print 'Timer:', timer
    pilotID = unpack("I",datapayload[4:8])[0]
    #print 'ID:', pilotID
    flightrecordtype = unpack("H",datapayload[8:10])[0]
    #print 'RecordType:', flightrecordtype
    if flightrecordtype != 3:
        if User[self.client.Username].Flight["BeginFlag"] == True:
            User[self.client.Username].FlightStart["xpos"] = unpack("f",datapayload[10:14])[0]
            User[self.client.Username].FlightStart["ypos"] = unpack("f",datapayload[14:18])[0]
            User[self.client.Username].FlightStart["zpos"] = unpack("f",datapayload[18:22])[0]
            User[self.client.Username].FlightStart["yrot"] = unpack("H",datapayload[22:24])[0]
            User[self.client.Username].FlightStart["xrot"] = unpack("H",datapayload[24:26])[0]
            User[self.client.Username].FlightStart["zrot"] = unpack("H",datapayload[26:28])[0]
            User[self.client.Username].FlightStart["xspd"] = unpack("H",datapayload[28:30])[0]
            User[self.client.Username].FlightStart["yspd"] = unpack("H",datapayload[30:32])[0]
            User[self.client.Username].FlightStart["zspd"] = unpack("H",datapayload[32:34])[0]
            User[self.client.Username].Flight["BeginFlag"] = False
            self.other.sock.send(Data2Packet(datatype, datapayload))
            return 0
        if User[self.client.Username].Info["Frozen"]:
            datapayload = datapayload[0:10] + pack("f",User[self.client.Username].Flight["xpos"]) +  pack("f",User[self.client.Username].Flight["ypos"]) +  pack("f",User[self.client.Username].Flight["zpos"]) + pack("H",User[self.client.Username].Flight["yrot"]) + pack("H",User[self.client.Username].Flight["xrot"]) + pack("H",User[self.client.Username].Flight["zrot"]) + "\0\0\0\0\0\0" + datapayload[34:]
            self.other.sock.send(Data2Packet(datatype, datapayload))
            self.sock.send(Data2Packet(datatype, datapayload))
            return 0
        User[self.client.Username].Flight["xpos"] = unpack("f",datapayload[10:14])[0]
        #print 'xPos:', xpos
        User[self.client.Username].Flight["ypos"] = unpack("f",datapayload[14:18])[0]
        #print 'yPos:', ypos
        User[self.client.Username].Flight["zpos"] = unpack("f",datapayload[18:22])[0]
        #print 'zPos:', zpos
        User[self.client.Username].Flight["yrot"] = unpack("H",datapayload[22:24])[0]
        #print 'Heading:', hdg
        User[self.client.Username].Flight["xrot"] = unpack("H",datapayload[24:26])[0]
        #print 'Pitch:', pitch
        User[self.client.Username].Flight["zrot"] = unpack("H",datapayload[26:28])[0]
        #print 'Bank:', bank
        User[self.client.Username].Flight["xspd"] = unpack("H",datapayload[28:30])[0]
        #print 'xSpeed:', xspeed
        User[self.client.Username].Flight["yspd"] = unpack("H",datapayload[30:32])[0]
        #print 'ySpeed:', yspeed
        User[self.client.Username].Flight["zspd"] = unpack("H",datapayload[32:34])[0]
        self.other.sock.send(Data2Packet(datatype, datapayload))
        return 0
        #print 'zSpeed:', zspeed
        accel_pitch = unpack("h",datapayload[34:36])[0]
        #print 'Accel_Pitch:', float(accel_pitch)/32767*360
        accel_yaw = unpack("h",datapayload[36:38])[0]
        return 0
        #print 'Accel_Yaw:', float(accel_yaw)/32767*360
        accel_roll = unpack("h",datapayload[38:40])[0]
        #print 'Accel_Roll:', float(accel_roll)/32767*360
        unknown1 = unpack("H",datapayload[40:42])[0]
        #print 'Unknown1:', unknown1
        fuel = unpack("H",datapayload[42:44])[0]
        #print 'Fuel:', fuel
        unknown2 = unpack("H",datapayload[44:46])[0]
        #print 'Unknown2:', unknown2
        unknown3 = unpack("H",datapayload[46:48])[0]
        #print 'Unknown3:', unknown3
        VGW = unpack("H",datapayload[48:50])[0]
        #print 'VGW:', VGW
        flightdata = unpack("B",datapayload[50:51])[0]
        boards = float(flightdata / 16)/15 * 100
        gear = (flightdata - (flightdata / 16)*16)
        #print 'Boards:', str(boards) + '%'
        if gear > 15 or gear < 0:
            pass
            #print 'Gear: ??? (' + str(gear) + ')'
        elif gear == 15:
            pass
            #print 'Gear: Down (' + str(gear) + ')'
        elif gear >= 10 and gear < 15:
            pass
            #print 'Gear: ### (' + str(gear) + ')'
        elif gear >= 5 and gear < 10:
            pass
            #print 'Gear: ## (' + str(gear) + ')'
        elif gear >= 1 and gear < 5:
            pass
            #print 'Gear: # (' + str(gear) + ')'
        elif gear == 0:
            pass
            #print 'Gear: Up (' + str(gear) + ')'
        flightdata = unpack("B",datapayload[51:52])[0]
        flaps = float(flightdata / 16)/15 * 100
        brake = (flightdata - (flightdata / 16)*16)/15
        #print 'Flaps:', str(flaps) + '%'
        if brake:
            pass
            #print 'Brake: On'
        else:
            pass
            #print 'Brake: Off'
        flightdata = unpack("B",datapayload[52:53])[0]
        #0 - Landing Lights
        #1 - Strobe
        #2 - Nav
        #3 - Beacon
        #4 - Guns
        #5 - Contrails
        #6 - Smoke
        #7 - Burners
        #print 'Raw FlighData:', flightdata
        flightdata = bin(flightdata)
        #print 'Raw FlighData:', flightdata
        if int(flightdata[0]) or int(flightdata[1]) or int(flightdata[2]) or int(flightdata[3]):
            #print 'lights are on.'
            m = 'Lights: On ('
            if int(flightdata[0]):
                m += 'Landing'
            if int(flightdata[1]):
                if len(m) > 12:
                    m += '|'
                m += 'Strobe'
            if int(flightdata[2]):
                if len(m) > 12:
                    m += '|'
                m += 'Nav'
            if int(flightdata[3]):
                if len(m) > 12:
                    m += '|'
                m += 'Beacon'
            #print m + ')'
        else:
            pass
            #print 'Lights: Off'
        if int(flightdata[4]):
            pass
            #print 'Guns: On'
        else:
            pass
            #print 'Guns: Off'
        if int(flightdata[5]):
            #print 'Contrails: On'
            pass
        else:
            #print 'Contrails: Off'
            pass
        if int(flightdata[6]):
            #print 'Smoke: On'
            pass
        else:
            #print 'Smoke: Off'
            pass
        if int(flightdata[7]):
            pass
            #print 'Burners: On'
        else:
            pass
            #print 'Burners: Off'
        unknown = unpack("B",datapayload[53:54])[0]
        #print 'Unknown:', unknown
        gunammo = unpack("H",datapayload[54:56])[0]
        #print 'Gun Ammo:', gunammo
        rockets = unpack("H",datapayload[56:58])[0]
        #print 'Rockets:', rockets
        aam = unpack("B",datapayload[58:59])[0]
        #print 'AAM:', aam
        agm = unpack("B",datapayload[59:60])[0]
        #print 'AGM:', agm
        bombs = unpack("B",datapayload[60:61])[0]
        #print 'Bombs:', bombs
        strength = unpack("B",datapayload[61:62])[0]
        #print 'Strength:', strength
        gforce = unpack("b",datapayload[62:63])[0]
        #print 'gForce:', float(gforce)/10
        throttle = unpack("b",datapayload[63:64])[0]
        #print 'Throttle:', str(float(throttle)/99*100) + '%'
        elevator = unpack("b",datapayload[64:65])[0]
        #print 'Elevator:', str(float(elevator)/99*100) + '%'
        aileron = unpack("b",datapayload[65:66])[0]
        #print 'Aileron:', str(float(aileron)/99*100) + '%'
        rudder = unpack("b",datapayload[66:67])[0]
        #print 'Rudder:', str(float(rudder)/99*100) + '%'
        trim = unpack("b",datapayload[67:68])[0]
        #print 'Trim:', str(float(trim)/99*100) + '%'
        last = unpack("B",datapayload[68:69])[0]
        #print 'Last:', last
        remaining = datapayload[69:]
        if len(remaining) > 0:
            pass
            #print 'Remaining Length:', len(remaining)
            #print 'Remaining:', remaining
    elif flightrecordtype == 3:
        if User[self.client.Username].Flight["BeginFlag"] == True:
            User[self.client.Username].FlightStart["xpos"] = unpack("f",datapayload[12:16])[0]
            User[self.client.Username].FlightStart["ypos"] = unpack("f",datapayload[16:20])[0]
            User[self.client.Username].FlightStart["zpos"] = unpack("f",datapayload[20:24])[0]
            User[self.client.Username].FlightStart["yrot"] = unpack("H",datapayload[24:26])[0]
            User[self.client.Username].FlightStart["xrot"] = unpack("H",datapayload[26:28])[0]
            User[self.client.Username].FlightStart["zrot"] = unpack("H",datapayload[28:30])[0]
            User[self.client.Username].FlightStart["xspd"] = unpack("H",datapayload[30:32])[0]
            User[self.client.Username].FlightStart["yspd"] = unpack("H",datapayload[32:34])[0]
            User[self.client.Username].FlightStart["zspd"] = unpack("H",datapayload[34:36])[0]
            User[self.client.Username].Flight["BeginFlag"] = False
            self.other.sock.send(Data2Packet(datatype, datapayload))
            return 0
        if User[self.client.Username].Info["Frozen"]:
            datapayload = datapayload[0:12] + pack("f",User[self.client.Username].Flight["xpos"]) +  pack("f",User[self.client.Username].Flight["ypos"]) +  pack("f",User[self.client.Username].Flight["zpos"]) + pack("H",User[self.client.Username].Flight["yrot"]) + pack("H",User[self.client.Username].Flight["xrot"]) + pack("H",User[self.client.Username].Flight["zrot"]) + "\0\0\0\0\0\0" + datapayload[36:]
            self.other.sock.send(Data2Packet(datatype, datapayload))
            #self.sock.send(Data2Packet(datatype, datapayload)) #THIS IS NOT WORKING?
            return 0
        PivotZX = unpack("h",datapayload[10:12])[0]
        #print 'PivotZX:', PivotZX
        User[self.client.Username].Flight["xpos"] = unpack("f",datapayload[12:16])[0]
        #print 'xPos:', xpos
        User[self.client.Username].Flight["ypos"] = unpack("f",datapayload[16:20])[0]
        #print 'yPos:', ypos
        User[self.client.Username].Flight["zpos"] = unpack("f",datapayload[20:24])[0]
        #print 'zPos:', zpos
        User[self.client.Username].Flight["yrot"] = unpack("H",datapayload[24:26])[0]
        #print 'Heading:', hdg
        User[self.client.Username].Flight["xrot"] = unpack("H",datapayload[26:28])[0]
        #print 'Pitch:', pitch
        User[self.client.Username].Flight["zrot"] = unpack("H",datapayload[28:30])[0]
        #print 'Bank:', bank
        User[self.client.Username].Flight["xspd"] = unpack("H",datapayload[30:32])[0]
        #print 'xSpeed:', xspeed
        User[self.client.Username].Flight["yspd"] = unpack("H",datapayload[32:34])[0]
        #print 'ySpeed:', yspeed
        User[self.client.Username].Flight["zspd"] = unpack("H",datapayload[34:36])[0]
        #print 'zSpeed:', zspeed
        self.other.sock.send(Data2Packet(datatype, datapayload))
        return 0
        accel_pitch = unpack("h",datapayload[36:38])[0]
        #print 'Accel_Pitch:', float(accel_pitch)/32767*360
        accel_yaw = unpack("H",datapayload[38:40])[0]
        #print 'Accel_Yaw:', float(accel_yaw)/32767*360
        accel_roll = unpack("H",datapayload[40:42])[0]
        #print 'Accel_Roll:', float(accel_roll)/32767*360
        gForce = unpack("h",datapayload[42:44])[0]
        #print 'gForce:', float(gForce)/32767*360
        GunAmmo = unpack("H",datapayload[44:46])[0]
        #print 'GunAmmo:', GunAmmo
        AAM = unpack("H",datapayload[46:48])[0]
        #print 'AAM:', AAM
        AGM = unpack("H",datapayload[48:50])[0]
        #print 'AGM:', AGM
        B500 = unpack("H",datapayload[50:52])[0]
        #print 'B500:', B500
        Smoke = unpack("H",datapayload[52:54])[0]
        #print 'Smoke:', Smoke
##        boards = float(flightdata / 16)/15 * 100
##        gear = (flightdata - (flightdata / 16)*16)
##        #print 'Boards:', str(boards) + '%'
##        return 0
##        if gear > 15 or gear < 0:
##            #print 'Gear: ??? (' + str(gear) + ')'
##        elif gear == 15:
##            #print 'Gear: Down (' + str(gear) + ')'
##        elif gear >= 10 and gear < 15:
##            #print 'Gear: ### (' + str(gear) + ')'
##        elif gear >= 5 and gear < 10:
##            #print 'Gear: ## (' + str(gear) + ')'
##        elif gear >= 1 and gear < 5:
##            #print 'Gear: # (' + str(gear) + ')'
##        elif gear == 0:
##            #print 'Gear: Up (' + str(gear) + ')'
##        throttle = unpack("b",datapayload[72:73])[0]
##        #print 'Throttle:', str(float(throttle)/99*100) + '%'
##        elevator = unpack("b",datapayload[73:74])[0]
##        #print 'Elevator:', str(float(elevator)/99*100) + '%'
##        aileron = unpack("b",datapayload[74:75])[0]
##        #print 'Aileron:', str(float(aileron)/99*100) + '%'
##        rudder = unpack("b",datapayload[75:76])[0]
##        #print 'Rudder:', str(float(rudder)/99*100) + '%'
##        trim = unpack("b",datapayload[76:77])[0]
##        #print 'Trim:', str(float(trim)/99*100) + '%'
##        flightdata = unpack("H",datapayload[77:79])[0]
##        #print 'SHIT NIGGA:', flightdata
##        #print 'lol:', datapayload[77:81]
##        #x = chr(255)
##        #y = chr(255)
##        #datapayload = datapayload[0:54] + x + y + datapayload[56:]
##        remaining = datapayload[81:]
##        if len(remaining) > 0:
##            #print 'Remaining Length:', len(remaining)
##            #print 'Remaining:', remaining
##        self.other.sock.send(Data2Packet(datatype, datapayload))
##        return 0
##        flaps = float(flightdata / 16)/15 * 100
##        brake = (flightdata - (flightdata / 16)*16)/15
##        #print 'Flaps:', str(flaps) + '%'
##        if brake:
##            #print 'Brake: On'
##        else:
##            #print 'Brake: Off'
        flightdata = unpack("B",datapayload[54:55])[0]
        #0 - Landing Lights
        #1 - Strobe
        #2 - Nav
        #3 - Beacon
        #4 - Guns
        #5 - Contrails
        #6 - Smoke
        #7 - Burners
        ##print 'Raw Flight Data:', flightdata
        flightdata = bin(flightdata)
        ##print 'Raw Flight Data:', flightdata
        if int(flightdata[0]) or int(flightdata[1]) or int(flightdata[2]) or int(flightdata[3]):
            ##print 'lights are on.'
            m = 'Lights: On ('
            if int(flightdata[0]):
                m += 'Landing'
            if int(flightdata[1]):
                if len(m) > 12:
                    m += '|'
                m += 'Strobe'
            if int(flightdata[2]):
                if len(m) > 12:
                    m += '|'
                m += 'Nav'
            if int(flightdata[3]):
                if len(m) > 12:
                    m += '|'
                m += 'Beacon'
            #print m + ')'
        else:
            #print 'Lights: Off'
            pass
        if int(flightdata[4]):
            #print 'Guns: On'
            pass
        else:
            #print 'Guns: Off'
            pass
        if int(flightdata[5]):
            #print 'Contrails: On'
            pass
        else:
            #print 'Contrails: Off'
            pass
        if int(flightdata[6]):
            #print 'Smoke: On'
            pass
        else:
            #print 'Smoke: Off'
            pass
        if int(flightdata[7]):
            #print 'Burners: On'
            pass
        else:
            #print 'Burners: Off'
            pass
        PivotXY = unpack("B",datapayload[55:56])[0]
        #print 'PivotXY:', PivotXY
        gunammo = unpack("H",datapayload[56:58])[0]
        #print 'Gun Ammo:', gunammo
        rockets = unpack("H",datapayload[58:60])[0]
        #print 'Rockets:', rockets
        aam = unpack("B",datapayload[60:61])[0]
        #print 'AAM:', aam
        agm = unpack("B",datapayload[61:62])[0]
        #print 'AGM:', agm
        bombs = unpack("B",datapayload[62:63])[0]
        #print 'Bombs:', bombs
        strength = unpack("H",datapayload[63:65])[0]
        #print 'Strength:', strength
        gforce = unpack("b",datapayload[65:66])[0]
        #print 'gForce:', float(gforce)/10
        throttle = unpack("b",datapayload[66:67])[0]
        #print 'Throttle:', str(float(throttle)/99*100) + '%'
        elevator = unpack("b",datapayload[67:68])[0]
        #print 'Elevator:', str(float(elevator)/99*100) + '%'
        aileron = unpack("b",datapayload[68:69])[0]
        #print 'Aileron:', str(float(aileron)/99*100) + '%'
        rudder = unpack("b",datapayload[69:70])[0]
        #print 'Rudder:', str(float(rudder)/99*100) + '%'
        trim = unpack("b",datapayload[70:71])[0]
        #print 'Trim:', str(float(trim)/99*100) + '%'
        last = unpack("B",datapayload[71:72])[0]
        #print 'Last:', last
        remaining = datapayload[72:]
        if len(remaining) > 0:
            #print 'Remaining Length:', len(remaining)
            #print 'Remaining:', remaining
            pass
    self.other.sock.send(Data2Packet(datatype, datapayload))
import random
import math

def FlightDataHostTest(self, datalength, datatype, datapayload):
    if unpack("H",datapayload[8:10])[0] != 3:
        self.other.sock.send(Data2Packet(datatype, datapayload))
        return 0
    else:
        datapayload = datapayload[0:55] + chr(math.floor(random.random()*255)) + datapayload[56:]
        self.other.sock.send(Data2Packet(datatype, datapayload))
        return 0
                                                

def ProcessPacket(self, datalength, datatype, datapayload):
    try:
        if datalength < 0:
            return -1
        #print "in the process system"
        if (datatype == 0):
            return 0, "" 
        elif (datatype == 4):
            try:
                ##Map.
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Map Name."
                #print "    Load:", unpack(str(len(datapayload)) + "s",datapayload)[0]
                #print "    Hex:", Packet2Hex(datapayload)
                #print 'End Map Name'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 5):
            try:
                ##Entity Joins.
    ##            print 'got some sort of reply packet?'
    ##            print "Length: " + str(datalength)
    ##            print "Type: " + str(datatype)
    ##            print "Load: " + str(datapayload)
    ##            print "length of load:", str(len(datapayload))
    ##            try:
    ##                print "int 1:", str(unpack("I",datapayload[0:4])[0])
    ##                print "int 2:", str(unpack("I",datapayload[4:8])[0])
    ##            except:
    ##                pass
                try:
                    #print 'Spawn Entity'
                    #print 'Loadout for Aircraft/Ground Spawn'
                    #print 'Full Packet: $' + str(datapayload) + '$'
                    entitytype = unpack("I",datapayload[0:4])[0]
                    #print 'type: $' + str(entitytype) + '$'
                    entityid = unpack("I",datapayload[4:8])[0]
                    #print 'id: $' + str(entityid) + '$'
                    entityiff = unpack("I",datapayload[8:12])[0]
                    #print 'iff: $' + str(entityiff) + '$'
                    entityspawnxpos = unpack("f",datapayload[12:16])[0]
                    #print 'xpos: $' + str(entityspawnxpos) + '$'
                    entityspawnypos = unpack("f",datapayload[16:20])[0]
                    #print 'ypos: $' + str(entityspawnypos) + '$'
                    entityspawnzpos = unpack("f",datapayload[20:24])[0]
                    #print 'zpos: $' + str(entityspawnzpos) + '$'
                    entityspawnxrot = unpack("f",datapayload[24:28])[0]
                    #print 'xrot: $' + str(entityspawnxrot) + '$'
                    entityspawnyrot = unpack("f",datapayload[28:32])[0]
                    #print 'yrot: $' + str(entityspawnyrot) + '$'
                    entityspawnzrot = unpack("f",datapayload[32:36])[0]
                    #print 'zrot: $' + str(entityspawnzrot) + '$'
                    entityname = unpack("64s",datapayload[36:100])[0]
                    entityname = entityname.strip('\0')
                    #print 'name: $' + str(entityname) + '$'
                    entitygroid = unpack("I",datapayload[100:104])[0]
                    #print 'groid: $' + str(entitygroid) + '$'
                    entitygroflag = unpack("I",datapayload[104:108])[0]
                    #print 'flag: $' + str(entitygroflag) + '$'
                    entityunknown1 = unpack("16s",datapayload[108:124])[0]
                    #print '???: $' + str(entityunknown1) + '$'
                    entityusername = unpack(str(len(datapayload[124:])) + "s",datapayload[124:])[0]
                    entityusername = entityusername.strip('\0')
                    #print 'username: $' + str(entityusername) + '$'
                    if entitytype == 0:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', 'joined flight in aircraft:', entityname, '\n    with ID:', entityid, 'IFF:', entityiff+1
                        User[self.client.Username].Flight["ID"] = entityid
                        User[self.client.Username].Flight["IFF"] = entityIFF
                        User[self.client.Username].Flight["xpos"] = 0.0
                        User[self.client.Username].Flight["ypos"] = 0.0
                        User[self.client.Username].Flight["zpos"] = 0.0
                        User[self.client.Username].Flight["xrot"] = 0.0
                        User[self.client.Username].Flight["yrot"] = 0.0
                        User[self.client.Username].Flight["zrot"] = 0.0
                        User[self.client.Username].Flight["xspd"] = 0.0
                        User[self.client.Username].Flight["yspd"] = 0.0
                        User[self.client.Username].Flight["zspd"] = 0.0
                        User[self.client.Username].Flight["Aircraft"] = entityname
                        User[self.client.Username].Flight["GroundID"] = 0
                        User[self.client.Username].Flight["Flag"] = 0
                        User[self.client.Username].Info["FlightsFlown"] += 1
                        User[self.client.Username].Flight["BeginFlag"] = True
                        self.client.Flying = True
                    elif entitytype == 65537:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Spawned ground object:', entityname, '\n    with ID:', entityid, 'IFF:', entityiff+1
                    #print str(len(datapayload[124:]))
                except:
                    pass
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 6):
            try:
                ##Reply?        
                #print 'got some sort of reply packet?'
                #print "Length: " + str(datalength)
                #print "Type: " + str(datatype)
                #print "Load: " + str(datapayload)
                #print "length of load:", str(len(datapayload))
                try:
                    ack1 = unpack("I",datapayload[0:4])[0]
                    ack2 = unpack("I",datapayload[4:8])[0]
                except:
                    pass
##                if ack1 == 9:
##                    print ack2
##                    print ServerInfo.WeaponsEnabledDefault
##                    ack2 == ServerInfo.WeaponsEnabledDefault
                #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Acknowledge:", str(ack1) + ',', str(ack2)
                #print Packet2Hex(datapayload)
                #print Packet2Hex(pack("I", ack1) + pack("I", ack2))
                self.other.sock.send(Data2Packet(datatype, pack("I", ack1) + pack("I", ack2)))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 7):
            try:
                ##Reply?
    ##            print 'got some sort of reply packet?'
    ##            print "Length: " + str(datalength)
    ##            print "Type: " + str(datatype)
    ##            print "Load: " + str(datapayload)
    ##            print "length of load:", str(len(datapayload))
    ##            try:
    ##                print "int 1:", str(unpack("I",datapayload[0:4])[0])
    ##                print "int 2:", str(unpack("I",datapayload[4:8])[0])
    ##            except:
    ##                pass
                entityid = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Acknowledges The Join Of ID:', str(entityid)
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 8):
            try:
                ##Join Flight Packet.
                if (User[self.Username].Info["Frozen"] >= 1):
                    m = "You are frozen and thus unable to join flight."
                    SendCommandBackward(User[self.Username].Info["ClientID"], m)
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sent A Join Request.'
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Join Request Rejected: Frozen.'
                    #self.other.sock.send(Data2Packet(datatype, datapayload))
                    self.sock.send(Data2Packet(6, pack("II",5,0)))
                    self.sock.send(Data2Packet(10, ''))
                else:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sent A Join Request.'
                    #print datapayload
                    self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 9):
            try:
                ##Approve Flight?
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Join Request Approved.'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 10):
            try:
                ##Deny Flight/Reject Request?
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Join Request Rejected.'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 11):
            try:
                FlightDataHost(self, datalength, datatype, datapayload)
            except:
                print 'Error'
                print sys.exc_info()
                pass;
        elif (datatype == 12):
            try:
                ##Self Terminate Flight?
                ident = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', ident, 'Ends Own Flight.'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 13):
            try:
                ##Aircraft Leaves Flight.
                endid = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', endid, 'Ends Flight.'
                for username in ServerInfo.UsersOnline:
                    #print username
                    #print User[username].Flight['ID']
                    #print endid
                    if (User[username].Flight['ID'] == endid) and (self.other == self.client):
                        #print "Matching"
                        #print '    Assist List: ', User[username].Kills["Assist"]
                        #print '    Last Assist: ', User[username].Kills["LastAssist"]
                        try:
                            test = User[User[username].Kills["LastAssist"]].Info["Kills"]
                            test = User[User[username].Kills["LastAssist"]].Info['DisplayedName']
                            if User[username].Kills["LastAssist"] == username:
                                m = 'You Commited Suicide!'
                                #print m
                                SendCommandBackward(User[username].Info["ClientID"], m)
                            User[User[username].Kills["LastAssist"]].Info["Kills"] += 1
                            m = 'Killed: ' + User[username].Info['DisplayedName'] + '. +100'
                            #print m
                            SendCommandBackward(User[User[username].Kills["LastAssist"]].Info["ClientID"], m)
                            m = 'Killed By: ' + User[User[username].Kills["LastAssist"]].Info['DisplayedName']
                            print m
                            SendCommandBackward(User[username].Info["ClientID"], m)
                            print '"' + username + '"Kills "' + User[username].Kills["LastAssist"] + '".'
                        except:
                            pass #list is empty.
                        for username2 in ServerInfo.UsersOnline:
                            if (username2 != User[username].Kills["LastAssist"]):
                                try:
                                    test = User[username].Kills["Assist"].index(username2)
                                    if User[username].Kills["Assist"].index(username2) == self.client.Username:
                                        pass
                                    else:
                                        m = 'Kill Assist:' + User[username].Info['DisplayedName'] + '. +20'
                                        #print m
                                        SendCommandBackward(User[username2].Info["ClientID"], m)
                                except:
                                    pass #not in the list
                        if not len(User[username].Kills["Assist"]) == 0 and len(User[username].Kills["LastAssist"]) == 0:
                            User[username].Info["Deaths"] += 1
##                        elif 0: #0 -> TotalSpeed(self) > 0:
##                            if 0: #0 -> Ejected(self):
##                                pass #pass -> spawn paratrooper
##                            else:
##                                User[self.client.Username].Info["Deaths"] += 1
                        #print "Wiping Data"
                        User[username].Kills["Assist"] = []
                        User[username].Kills["LastAssist"] = ''
                        User[username].FlightStart["ID"] = 0
                        User[username].FlightStart["IFF"] = 0
                        User[username].FlightStart["xpos"] = 0.0
                        User[username].FlightStart["ypos"] = 0.0
                        User[username].FlightStart["zpos"] = 0.0
                        User[username].FlightStart["xrot"] = 0.0
                        User[username].FlightStart["yrot"] = 0.0
                        User[username].FlightStart["zrot"] = 0.0
                        User[username].FlightStart["xspd"] = 0.0
                        User[username].FlightStart["yspd"] = 0.0
                        User[username].FlightStart["zspd"] = 0.0
                        User[username].FlightStart["Aircraft"] = ""
                        User[username].FlightStart["GroundID"] = 0
                        User[username].FlightStart["Flag"] = 0
                        User[username].Flight["ID"] = 0
                        User[username].Flight["IFF"] = 0
                        User[username].Flight["xpos"] = 0.0
                        User[username].Flight["ypos"] = 0.0
                        User[username].Flight["zpos"] = 0.0
                        User[username].Flight["xrot"] = 0.0
                        User[username].Flight["yrot"] = 0.0
                        User[username].Flight["zrot"] = 0.0
                        User[username].Flight["xspd"] = 0.0
                        User[username].Flight["yspd"] = 0.0
                        User[username].Flight["zspd"] = 0.0
                        User[username].Flight["Aircraft"] = ""
                        User[username].Flight["GroundID"] = 0
                        User[username].Flight["Flag"] = 0
                        User[username].Flying = False
                        #print '    Data Reset For:', username
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 16):
            ##End Aircraft List
            print '(' + self.Username + ' -> ' + self.other.Username + ')', "End Aircraft List"
            if self.client.Username.lower() == 'php bot':
                #PHP Bot does NOT need anything else. We force it to DC to avoid players joining as 'PHP Bot' and sneaking in. ;)
                m = 'As previously arranged, You have been automatically disconnected from the server now that you have completed downloading the server list.\nThanks for visiting the server, anonymous robot-san! :3\n\n    - Orb'
                SendCommandForward(self, m)
                self.client.close()
            else:
                try:
                    #SendCommandForward(self, ServerInfo.LogonMessage) #LogonComplete message here!
                    self.other.sock.send(Data2Packet(datatype, datapayload))
                except:
                    pass;
        elif (datatype == 17):
            try:
                ##Keep Alive Packet.
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 18):
            try:
                ##Locked Target.
                KillerID = unpack("I",datapayload[0:4])[0]
                KillerType =  unpack("I",datapayload[4:8])[0]
                VictimID = unpack("I",datapayload[8:12])[0]
                if VictimID == 4294967295: #returns ff:ff:ff:ff is NOTHING is locked.
                    VictimID = 'null'
                VictimType = unpack("I",datapayload[12:16])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', KillerID, "Locks onto", VictimID
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 19):
            try:
                ##Ground Destroyed.
                groid = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Ground Destroyed:', groid
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 20):
            try:
                ##Explosion/Flare Packet.
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sent An Explosion, Flare or Ordinance Packet."
                #print "    Load: " + str(datapayload)
                #print "    Hex: " + Packet2Hex(datapayload)
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 21):
            try:
                ##Acknowledge Packet?
                #print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sent An Acknowledgement/Keepalive.'
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 22):
            try:
                if self.Username == self.client.Username:
                    if User[self.Username].Info["Frozen"] >= 1:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', "Damage Signal Rejected (Frozen)"
                        return 0
                ##Damage Packet.
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sent A Damage Signal"
                #print datapayload
                victimtype = unpack("I",datapayload[0:4])[0]
                print 'Victim Type:', victimtype
                victimid = unpack("I",datapayload[4:8])[0]
                print 'Victim ID:', victimid
                killertype = unpack("I",datapayload[8:12])[0]
                print 'Killer Type', killertype
                damageammount = unpack("H",datapayload[12:14])[0]
                print 'Damage Amount:', damageammount
                damagetype = unpack("H",datapayload[14:16])[0]
                print 'Damage Type:', damagetype
                weaponused = unpack("H",datapayload[16:18])[0]
                print 'Weapon Used', weaponused
                unknown = unpack("I",datapayload[18:22])[0]
                print '???:', unknown, datapayload[18:22]
                victimname = ''
                killername = ''
                #print self.Username
                #print self.client.Username
                if (self == self.client):
                    for username in ServerInfo.UsersOnline:
                        #print username
                        if (str(User[username].Flight['ID']) == str(victimid)):
                            victimname = username
                            #print 'Victim:', username
                        if (username == self.client.Username):
                            killername = username
                            #print 'Killer:', username
                    if (victimname != '') and (killername != ''):
                        try:
                            test = User[victimname].Kills["Assist"].index(killername)
                        except:
                            User[victimname].Kills["Assist"].append(killername)
                            #print 'Added the killer,', killername, ', to the assist list of:', victimname
                        User[victimname].Kills["LastAssist"] = killername
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 29):
            try:
                ##YSFVersion.
                version = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "YSFlight Version:", version
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 30):
            #Set Air Commands
            try:
                #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sent An Air Command"
                #print datapayload
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 31):
            try:
                ##Missile Rules
                missilesenabled = unpack("I",datapayload[0:4])[0]
                if missilesenabled == 1:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Missiles Enabled"
                else:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Missiles Disabled"
                try:
                    test = ServerInfo.MissilesEnabledDefault
                except:
                    ServerInfo.MissilesEnabledDefault = missilesenabled
                if self.other.sock == self.client.sock:
                    print "    Setting Was: " + str(missilesenabled) + ", Replaced with: " + str(ServerInfo.MissilesEnabled)
                    self.other.sock.send(Data2Packet(31, pack("I", ServerInfo.MissilesEnabled)))
                else:
                    self.other.sock.send(Data2Packet(31, pack("I", ServerInfo.MissilesEnabledDefault)))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 32):
            try:
                if self.client.Username.lower() == 'php bot':
                    #PHP bot does NOT need to hear anything from the server. We stop the server sending it info to avoid spy issues.
                    return 0
                if self == self.server:
                    message_in = Message2String(datapayload)
                    message_out = message_in
                    message_in = message_in[len(self.Username)+2:]
                    Type32(self, message_in, message_out);
                    return 0
                #print "got type 32"
                message_in = Message2String(datapayload)
                #print message_in
                #print User[self.Username].Info['FeedName']
                #print len(User[self.Username].Info['FeedName'])
                #print len(User[self.Username].Info['FeedName'])+2
                message_out = message_in
                message_in = message_in[len(User[self.Username].Info['FeedName'])+2:]
                #print self.Username
                #print str((len(User[self.Username].Info['FeedName'])+2))
                #print "command: '" + message_in + "'"
                #print message_in
                Type32(self, message_in, message_out);
                #print "ready to return"
            except:
                print 'Error Parsing Message.\n'
                print sys.exc_info()
        elif (datatype == 33):
            ##Weather.
            try:
                if self == self.client:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weather Request."
                elif self == self.server:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weather."
                    daynight = unpack("I",datapayload[0:4])[0]
                    options = unpack("I",datapayload[4:8])[0]
                    options = bin(options)
                    windx = unpack("f",datapayload[8:12])[0]
                    windy = unpack("f",datapayload[12:16])[0]
                    windz = unpack("f",datapayload[16:20])[0]
                    fog = unpack("f",datapayload[20:24])[0]
                    print '    DayEnabled:', daynight
                    print '    BlackoutEnabled:', options[5]
                    print '    LandEverywhere:', options[1]
                    print '    CollisionsEnabled:', options[3]
                    print '    WindX:', windx
                    print '    WindY:', windy
                    print '    WindZ:', windz
                    print '    Fog:', fog
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass
        elif (datatype == 36):
            try:
                ##Weapon Loading
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weapon Loadout:"
                try:
                    entityid = unpack("I",datapayload[0:4])[0]
                    unknown = unpack("H",datapayload[4:6])[0]
                    #print "ID: $" + str(entityid) + "$"
                    #print "Unknown(2?): $" + str(unknown) + "$"
                    i = 6
                    while i <= len(datapayload)-4:
                        entitytype = unpack("H",datapayload[i:i+2])[0]
                        #print entitytype
                        entityload = unpack("H",datapayload[i+2:i+4])[0]
                        #print entityload
                        if (entitytype == 1):
                            print "    AAM(Short): " + str(entityload)
                        elif (entitytype == 2):
                            print "    AGM: " + str(entityload)
                        elif (entitytype == 3):
                            print "    Bomb(500lb): " + str(entityload)
                        elif (entitytype == 4):
                            print "    Rocket: " + str(entityload)
                        elif (entitytype == 6):
                            print "    AAM(Mid): " + str(entityload)
                        elif (entitytype == 7):
                            print "    Bomb(250lb): " + str(entityload)
                        elif (entitytype == 9):
                            print "    Bomb-HD(500lb): " + str(entityload)
                        elif (entitytype == 10):
                            print "    A-AAM(Short): " + str(entityload)
                        elif (entitytype == 12):
                            print "    Fuel Tank: " + str(entityload)
                        elif (entitytype == 200):
                            print "    Flare: " + str(entityload)
                        else:
                            print "    Unknown Type(" + str(entitytype) + "): " + str(entityload)
                        i += 4
                except:
                    print sys.exc_info()
                    pass
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 37):
            ##User List
            if (self == self.client):
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sends A List Request.'
                if self.client.Username.lower() == 'php bot':
                    self.other.sock.send(Data2Packet(datatype, datapayload))
                else:
                    Players(self)
            elif (self == self.server):
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Sends User Data.'
            try:
                temp = unpack("hhII"+str(len(datapayload)-12)+"s",datapayload)
                if temp[4].strip('\0') == self.server.Username:
                    self.other.sock.send(Data2Packet(datatype, datapayload))
                self.other.sock.send(Data2Packet(datatype, datapayload))
                #elif not User[temp[4].strip('\0')].Info["Hidden"]:
                    #self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass
        elif (datatype == 38):
            try:
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Query Airstate:'
                number = unpack("I",datapayload[0:4])[0]
                print "    Load: " + str(datapayload)
                print "    Hex: " + Packet2Hex(datapayload)
                print '    Number Of Aircraft:', number
            except:
                print sys.exc_info()
            try:
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
        elif (datatype == 39):
            try:
                ##Weapon Rules.
                state = unpack("I",datapayload[0:4])[0]
                if state == 0:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weapons Disabled" 
                elif state == 1:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Weapons Enabled"
                try:
                    test = ServerInfo.WeaponsEnabledDefault
                except:
                    ServerInfo.WeaponsEnabledDefault = state
                if self.other.sock == self.client.sock:
                    print "    Was: " + str(state) + ", Replaced with: "  + str(ServerInfo.WeaponsEnabled)
                    self.other.sock.send(Data2Packet(39, pack("I", ServerInfo.WeaponsEnabled)))
                else:
                    self.other.sock.send(Data2Packet(39, pack("I", ServerInfo.WeaponsEnabledDefault)))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 40):
            try:
                ##Rotatable Turret Data.
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 41):
            try:
                ##Username Distance.
                distance = unpack("I",datapayload[0:4])[0]
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Set Username Distance:", distance
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 43):
            ##Misc Command.
            try:
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sends a Misc Command"
                print '    ', datapayload[4:]
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        elif (datatype == 44):
            ##Aircraft List
            try:
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Sends Aircraft List"
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                pass;
        elif (datatype == 46):
            #Kill Confirmation
            try:
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Earned A Kill.'
                print 'VictimType:', unpack("I",datapayload[0:4])[0]
                print 'KillerType:', unpack("I",datapayload[4:8])[0]
                print '???:', unpack("I",datapayload[8:12])[0], datapayload[8:12], Packet2Hex(datapayload[8:12])
                print '???:', unpack("I",datapayload[12:16])[0], datapayload[12:16], Packet2Hex(datapayload[12:16])
                print 'UniqueKillID:', unpack("I",datapayload[16:20])[0], datapayload[16:20], Packet2Hex(datapayload[16:20])
                print 'Junk:', unpack("I",datapayload[20:24])[0]
                print 'KillerID:', unpack("I",datapayload[24:28])[0]
                print 'KillerName:', unpack("32s",datapayload[28:60])[0]
                print 'KillerObject:', unpack("32s",datapayload[60:92])[0]
                print 'Junk:', unpack("I",datapayload[92:96])[0]
                print 'VictimID:', unpack("I",datapayload[96:100])[0]
                print 'VictimName:', unpack("32s",datapayload[100:132])[0]
                print 'VictimObject:', unpack("32s",datapayload[132:164])[0]
                #self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
            # aircraft list
        #print self.other
        #print self.self
        else:
            try:
                print "Undeclared Packet Type. No action taken on packet:"
                print "Length: " + str(datalength)
                print "Type: " + str(datatype)
                print "Load: " + str(datapayload)
                print "Hex: " + Packet2Hex(datapayload)
                self.other.sock.send(Data2Packet(datatype, datapayload))
            except:
                print sys.exc_info()
                pass;
        #print "send the data away"
    except:
        print sys.exc_info()
        pass
def LogonComplete(self):
    if self.Username.lower() == 'php bot':
        return 0
    User[self.Username].Info["ClientID"] = self
    User[self.Username].Info["IPAddress"] = self.clientsock.getpeername()[0]
    for username in ServerInfo.UsersOnline:
        if (username == self.Username):
                if (User[username].Info["LoginCount"] > 0):
                    m = 'Welcome Back ' + User[username].Info["DisplayedName"] + '.'
                    m += '\nYour last visit was ' + tupletodate(User[username].Info["LastVisit"]) + '.'
                    SendCommandBackward(self, m)
                    User[username].Info["LoginCount"] += 1
                    if (User[username].Info["JoinDate"] == (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)):
                        m = "Logged in " + str(User[username].Info["LoginCount"]) + " time(s), joining today."
                    else:
                        m = "Logged in " + str(User[username].Info["LoginCount"]) + " time(s) since " + tupletodate(User[username].Info["JoinDate"]) + "."
                    if (User[username].Info["LoginCount"] == 2):
                        m += "\nThis is your 2nd Login! Glad to see you come back! :D"
                    if (User[username].Info["LoginCount"] == 10):
                        m += "\nThis is your 10th Login! Keep coming back and you can earn a PRIZE! (maybe)"
                    if (User[username].Info["LoginCount"] == 100):
                        m += "\nThis is your 100th Login! Let's all drink and party! YEAHHHHH!"
                    elif (User[username].Info["LoginCount"] == 500):
                        m += "\nThis is your 500th Login! Dude time to go play with the other  kids in your neighbourhood... right?"
                    elif (User[username].Info["LoginCount"] == 1000):
                        m += "\nMOTHER OF GOD! THIS IS YOUR 1000th LOGIN! CRAWL OUT OF YOUR MOTHERS BASEMENT MAN!"
                    elif (User[username].Info["LoginCount"] == 2000):
                        m += "\nThat's 2000 logins. Holy sheet."
                    elif (User[username].Info["LoginCount"] == 3000):
                        m += "\nThis is your 3000th Login! Congratulations?"
                    elif (User[username].Info["LoginCount"] == 4000):
                        m += "\nThis is your 4000th Login!!! PLEASE ENJOY THIS JOKE:"
                        m += "\nHow did the hipster burn his hand? He changed the lightbulb before it was cool!"
                        m += "\nHAHAHAHAHHA! THAT'S FUNNY, RIGHT?"
                    elif (User[username].Info["LoginCount"] == 5000):
                        m += "\nThis is your 5000th Login!!! You will now receive a complimentary login gift each time you rejoin! Cool huh?"
                    elif (User[username].Info["LoginCount"] > 5000 and User[username].Info["LoginCount"] < 9000):
                        m += "\nI logged in over 5000 times and all I got was this crappy login message."
                    elif (User[username].Info["LoginCount"] == 9000):
                        m += "\nThis is your 9000th Login!!! YOU'VE WON A PRIZE! NOW, EVERY TIME YOU LOG IN,  EVERYONE WILL KNOW YOUR POWER LEVEL IS OVER9000!"
                        m += "\n(By the way, this is the LAST login bonus based prize.)"
                    elif (User[username].Info["LoginCount"] > 9000):
                        m += "\nYour power level is OVER NINE THOUSSSSAAAAAAAAAAAAAAAAAAAAAAAAND!"
                        if not (User[self.Username].Info["Hidden"]):
                            a = "Vegeta! What's the scouter say about " + User[self.Username].Info["DisplayedName"] + "'s Power Level?"
                            a += "\nIT'S OVER NINE THOUUUUSSSAAAAAAAAAAAAAAAAAAANNNNND!!!!111ONE"
                            a += "\nWHAT!? OVER NINE THOUSAND!?"
                            SendCommandForward(self, a)
                    User[username].Info["LastVisit"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
                    WriteUserToDatabase(self.Username)
                else:
                    m = 'Welcome ' + User[username].Info["DisplayedName"] + '.'
                    User[username].Info["LoginCount"] += 1
                    User[username].Info["JoinDate"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
                    User[username].Info["LastVisit"] = (datetime.datetime.now().day, datetime.datetime.now().month, datetime.datetime.now().year)
                    WriteUserToDatabase(self.Username)
                if (User[username].Info["Hidden"]):
                    m += "\nYou've logged in HIDDEN. Use '/unhide' to show up to everyone else!"
                SendCommandBackward(self, m)
                Players(self)
        else:
            try:
                usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
            except:
                ##The logging in user is not a member of the master group.
                usersvalue = -1
            try:
                targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
            except:
                ##The target user is not a member of the master group.
                targetsvalue = -1
            #print User[username].Info["Hidden"]
            #print int(targetsvalue)
            #print int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"])
            #print int(User[username].Permission["CanHideFromRank"])
            #print int(usersvalue)
            #print int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"])
            if (User[self.Username].Info["Hidden"]):
                if (int(targetsvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(targetsvalue)].Permission["CanHideFromRank"]) + int(User[username].Permission["CanHideFromRank"]) >= int(usersvalue)):
                    m = User[self.Username].Info["DisplayedName"] + ' Logged in HIDDEN.'
                    SendCommandBackward(User[username].Info["ClientID"], m)
                else:
                    ##Do nothing! THE USER is HIDDEN!
                    pass;
            else:
                SendCommandBackward(User[username].Info["ClientID"], User[self.Username].Info["DisplayedName"] + ' joined the server.')
            
        

class Server:
    def JoinPlugs(self, client):
        #Absolute
        self.client = client
        self.server = self
        self.client.client = client
        self.client.server = self

        #Relative Others
        self.other = client
        self.client.other = self

        #Absolute Sockets
        self.client.clientsock = client.sock
        self.client.serversock = client.serversock
        self.clientsock = client.sock
        self.serversock = client.serversock

        #Relative Sockets
        self.sock = self.serversock
        self.other.sock = client.sock
        
        self.Username = "(Console Server)"
        self.other.Username = client.Username

        self.closing = False
        self.other.closing = False
    
    def __init__(self, client): #Need to send the socket to get data from, and socket to send it to.
        self.JoinPlugs(client) #Link the relatives and absolute references between the client and server objects.
        LogonComplete(self.client) #Client has been fully established, let everyone know the client has joined.
        self.serverthread = thread.start_new_thread(self.program, (self,))
        self.clientthread = thread.start_new_thread(client.program, (client,))
        client.serverthread = self.serverthread
        client.clientthread = self.clientthread
        

    def send(self, data):
        self.s.send(data)

    def recv(self, size):
        return self.s.recv(size)

    def close(self):
        self.closing = True
        self.sock.close()

    def program(self, null):
        if (Settings.VerboseDebug):
            while not self.closing:
                #print "Server Talking To Client"
                data = RecvPacket2Data(self)
                if (data[0] == -1) and not self.closing:
                    pass
                    #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Dropped A Bugged Packet."
                elif (data[0] == -2) and not self.closing:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Socket Closed. Cleaning."
                    self.close()
                elif not self.closing:
                    datalength = data[0]
                    datatype = data[1]
                    datapayload = data[2]
                    ProcessPacket(self, datalength, datatype, datapayload);
            print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Thread closed'
        else:
            try:
                while not self.closing:
                    #print "Server Talking To Client"
                    data = RecvPacket2Data(self)
                    if (data[0] == -1) and not self.closing:
                        #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Dropped A Bugged Packet."
                        try:
                            self.other.sock.send(Data2Packet(17, ''))
                        except:
                            self.close()
                    elif (data[0] == -2) and not self.closing:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', "Socket Closed. Cleaning."
                        self.close()
                    elif not self.closing:
                        datalength = data[0]
                        datatype = data[1]
                        datapayload = data[2]
                        ProcessPacket(self, datalength, datatype, datapayload);
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Thread closed'
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print '''
                WARNING!There has been a bug in the program! (OH NOES!)
                Please submit the following bug report via the bug report page:
                    http://sourceforge.net/p/orbforysflight/tickets/new/
                If you can accuratly reproduce the error, please reperform the error with 'Graceful Debug' turned OFF,
                    then submit the error produced via the same link above.

                Thanks for your report!

                Bug Data:'''
                print "    ", (exc_type, fname, exc_tb.tb_lineno)
                print "\nBecause of this bug, The client:", self.client.Username, "has been disconnected."
                self.client.close()
import sys, os

def Logoff(self):
    #print 'in the log off script'
    try:
        found = False;
        for username in ServerInfo.UsersOnline:
            if (username == self.Username):
                #print 'found myself'
                found = True
    except:
        found = False;
        
    if found:
        for username in ServerInfo.UsersOnline:
            if (username != self.Username):
                try:
                    usersvalue = User[self.Username].Group[ServerInfo.MasterGroup].Rank["Number"]
                except:
                    ##The logging in user is not a member of the master group.
                    usersvalue = -1
                try:
                    targetsvalue = User[username].Group[ServerInfo.MasterGroup].Rank["Number"]
                except:
                    ##The target user is not a member of the master group.
                    targetsvalue = -1

                if (User[self.Username].Info["Hidden"]):
                    #print 'hidden'
                    if not (int(usersvalue) + int(Group[ServerInfo.MasterGroup].Rank[int(usersvalue)].Permission["CanHideFromRank"]) + int(User[self.Username].Permission["CanHideFromRank"])  >= int(targetsvalue)):
                        #print 'this user can see me'
                        m = User[self.Username].Info["DisplayedName"] + ' left the server.'
                        try:
                            SendCommandBackward(User[username].Info["ClientID"], m)
                        except:
                            #The user may have dc'd at the same time?
                            pass
                else:
                    #print 'not hidden'
                    try:
                        SendCommandBackward(User[username].Info["ClientID"], User[self.Username].Info["DisplayedName"] + ' left the server.')
                    except:
                        #The user may have dc'd at the same time?
                        pass

        #print 'deleted my client id.'
        del User[self.Username].Info["ClientID"]
            
        

class Client:
    def CreatePlugs(self, newclient):
        #Absolute
        self.server = self #place holder

        #Relative Others
        self.other = self

        #Absolute Sockets
        self.clientsock = newclient
        self.serversock = newclient #place holder

        #Relative Sockets
        self.sock = newclient
        self.other.sock = newclient
        
        self.Username = "USERNAME"
        self.other.Username = self.Username

        self.closing = False
        self.other.closing = False
    def __init__(self, newclient): #Need to send the socket to get data from, and socket to send it to.
        self.CreatePlugs(newclient)
        self.timeouttime = 120
        self.sock.settimeout(self.timeouttime)
        self.closing = False
        self.Flying = False
        self.connect()
        
    def connect(self):
        response = ClientLogin(self)
        if response >= 0:
            self.server = Server(self)
        else:
            return -1

    def sendserver(self, data):
        self.serversock.send(data)

    def sendclient(self, data):
        self.clientsock.send(data)

    def recvserver(self, size):
        return self.serversock.recv(size)

    def recvclient(self, size):
        return self.clientsock.recv(size)

    def close(self):
        self.server.closing = True
        self.closing = True
        #print '(' + self.Username + ' -> ' + self.other.Username + ')', 'told to die'
        #SendCommandForward(self, self.Username + ' has left the server.') #DO NOT ENABLE THIS! THE LOG OFF SCRIPT SUPERCEDES IT!
        print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Logging off'
        Logoff(self)
        try:
            ServerInfo.UsersOnline.remove(self.Username)
            print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Removed self from online user list.'
            ServerInfo.UpdateOnlinePlayers = True
        except:
            pass;
        self.sock.close()
        print '(' + self.Username + ' -> ' + self.other.Username + ')', "Client Socket Cleaned."
        self.server.close()
        

    def program(self, null):
        if (Settings.VerboseDebug):
            while not self.closing:
                data = RecvPacket2Data(self)
                if (data[0] == -1) and not self.closing:
                    #print '(' + self.Username + ' -> ' + self.other.Username + ')', "Dropped A Bugged Packet."
                    try:
                        self.sock.send(Data2Packet(17, ''))
                    except:
                        self.close()
                elif (data[0] == -2) and not self.closing:
                    print '(' + self.Username + ' -> ' + self.other.Username + ')', "Socket Closed. Cleaning."
                    self.close()
                elif not self.closing:
                    datalength = data[0]
                    datatype = data[1]
                    datapayload = data[2]
                    ProcessPacket(self, datalength, datatype, datapayload);
            print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Thread closed'
        else:
            try:
                while not self.closing:
                    data = RecvPacket2Data(self)
                    if (data[0] == -1) and not self.closing:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', "Dropped A Bugged Packet."
                    elif (data[0] == -2) and not self.closing:
                        print '(' + self.Username + ' -> ' + self.other.Username + ')', "Socket Closed. Cleaning."
                        self.close()
                    elif not self.closing:
                        datalength = data[0]
                        datatype = data[1]
                        datapayload = data[2]
                        ProcessPacket(self, datalength, datatype, datapayload);
                print '(' + self.Username + ' -> ' + self.other.Username + ')', 'Thread closed'
            except Exception, e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]      
                print '''
                WARNING!There has been a bug in the program! (OH NOES!)
                Please submit the following bug report via the bug report page:
                    http://sourceforge.net/p/orbforysflight/tickets/new/
                If you can accuratly reproduce the error, please reperform the error with 'Graceful Debug' turned OFF,
                    then submit the error produced via the same link above.

                Thanks for your report!

                Bug Data:'''
                print "    ", (exc_type, fname, exc_tb.tb_lineno)
                print "\nBecause of this bug, The client:", self.client.Username, "has been disconnected."
                self.close()
def ClientLogin(self):
    """
    This will be hard, we need to get the packet data...
    """
    #we need to receive the packets still!
    self.LoginPacket = -1
    while (str(self.LoginPacket) == '-1'):
        self.LoginPacket = RecvPacket2Data(self)
    datalength = self.LoginPacket[0]
    datatype = self.LoginPacket[1]
    if (datatype == 1): #1 == loginpacket
        self.Username = unpack("16sI",self.LoginPacket[2])[0]
        self.version = unpack("16sI",self.LoginPacket[2])[1]
        ##Take Action on username here...
        #print self.username.lower()
        #print self.clientsock.getsockname()[0]
        self.Username = self.Username.strip("\0")
        print "New Client '" + self.Username + "' Connected From IP Address: " + self.clientsock.getpeername()[0]
        for username in ServerInfo.UsersOnline:
            if (username == self.Username):
                SendCommandBackward(self, 'User "' + self.Username + '" is already on the server. Your login has been denied.')
                print "New Client '" + self.Username + "' Was Rejected, Shared Username."
                self.closing = True
                self.sock.close()
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Client Socket Cleaned."
                del self
                return -1
        loginreturn = LoginUser(self.Username, self)
        if loginreturn:
            try:
                int(User[self.Username].Info["Banned"])
            except:
                print "Error with Users 'ban' info, not an integer: " + User[self.Username].Info["Banned"]
                User[self.Username].Info["Banned"] = 0
            if (User[self.Username].Info["Banned"] >= 1):
                print "New Client '" + self.Username + "' Was Rejected."
                SendCommandBackward(self, 'A ban has been placed on your username by: "' + User[self.Username].Info["BannedBy"] + '".\nReason: ' + User[self.Username].Info["BanReason"]+ '\nYou can not log in.')
                self.closing = True
                self.sock.close()
                print '(' + self.Username + ' -> ' + self.other.Username + ')', "Client Socket Cleaned."
                del self
                return -1
            print "New Client '" + self.Username + "' Was Accepted."
            Authorised(self)
            return 0
        else:
            print "New Client '" + self.Username + "' Was Rejected."
            #SendString(self.clientsock,"Username Not Authenticated. Please Log Into YSFHQ First, Then Rejoin This Server With Your YSFHQ Username.")
            self.clientsock.close()
            #self.serversock.close()
    else:
        #The initial packet is NOT a log in packet:
        print 'Orb received a ping from some server, somewhere.\nIgnoring.'
        try:
            SendCommandBackward(self, "Hello There! Nice to meet you! My Name is ORB, and I am the gatekeeper for this YSFlight server.\n\nIt sems you've tried to connect to my server, but have not sent the correct log on data packet.\n\nIf you're a YSFlight client, that probably means that your connection is damaged, or the server has broken.\nTry again? Sorry about this! D:")
        except:
            pass
        return -1

def Authorised(self):
    if self.Username.lower() != 'php bot' and self.Username.lower() != ServerInfo.ConsoleName.lower() :
        ServerInfo.UsersOnline.append(self.Username)
    self.authenticated = True
    ServerAddress = (Settings.ServerIP, Settings.ServerPort)
    self.serversock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    self.serversock.connect(ServerAddress)
    #self.serversock.settimeout(0) ##The server does not send response packets! It only listens for a keep alive!
    self.serversock.send(pack("II" + str(self.LoginPacket[0]-4) + "s", self.LoginPacket[0], self.LoginPacket[1], self.LoginPacket[2]))
import urllib
def LoginYSFHQ(self, username, password):
    self.result = 'Null'
    #print "Username: " + username
    #print "Password: " + "*" * len(password)
    url = "http://ysfhq.com/phpbb3/orblogin.php?user=" + username + "&pass=" + password
    try:
        urlfileobject = urllib.urlopen(url)
        try:
            response = urlfileobject.read()
            urlfileobject.close()
        except:
            response = "THE SERVER DID NOT REPLY IN TIME."
            urlfileobject.close()
    except:
        response = "FAILED TO OPEN THE URL. PERHAPS THE DOMAIN IS DOWN?"
    if (response == "INVALID"):
        #print "User NOT Authenticated."
        self.result = False
        print self.result
        return False
    else:
        try:
            int(response)
            if (response > 0):
                #print "Logged in as " + username
                self.result = True
                print self.result
                return True
        except:
            SendCommandBackward(self, "YSFHQ Userbase Lookup has broken! (Reply: '" + str(response[:64]) + "')")
            SendCommandBackward(self, "Please let Flake or EricT-15 know what the reply message above was!")
            self.result = False
            print self.result
            return False

def LoginUser(Username, self):
    try:
        test = User[self.Username]
    except:
        User[self.Username] = SpawnUser(self.Username)
        #print User
    if (self.Username.lower() == ServerInfo.ConsoleName.lower()) or (self.Username.lower() == ServerInfo.AdminName.lower()):
        return Administrator_Script(self)
    elif not Settings.UseYSFHQAuthentication:
        User[self.Username].Info['FeedName'] = self.Username
        return True
    if self.Username.lower() == 'php bot':
        SendCommandBackward(self, "You've joined the server as a bot: " + str(self.Username) + "\n\nThe bot aims to get information about the server, and then disconnects.\nTo avoid spy issues:\n    You will be AUTOMATICALLY DISCONNECTED once the server finishes sending the aircraft list\n    You will be denied the ability to send text messages, or receive them.\n\nHave a nice day! :D\n    - Orb")
        return True
    if (Settings.AlwaysAllowLocalHost) and (self.clientsock.getpeername()[0] == "127.0.0.1" or self.clientsock.getpeername()[0] == "localhost"):
        loggedin = True
        return True
    else:
        return YSFHQ_Script(self)

def YSFHQ_Script(self):
    SendCommandBackward(self, "Welcome to the Orb YSFHQ Login System!")
    SendCommandBackward(self, "To join the server, log in with your YSFHQ Username (Case Sensitive!)")
    SendCommandBackward(self, "You are currently attempting to log in as:" + self.Username)
    SendCommandBackward(self, "Please Enter your YSFHQ Password (Case Sensitive!). If this was 'lol' just type 'lol' then send, for example.")
    loggedin = False
    while not loggedin:
        SendCommandBackward(self, "Please Enter Password:")
        received32 = False
        while not received32:
            data = RecvPacket2Data(self)
            datalength = data[0]
            if datalength == -1:
                SendCommandBackward(self, "The Internet Broke Your Shit! I Didn't Understand That... Try Again Please?")
            if datalength == -2:
                SendCommandBackward(self, "It seems that your connection sucks, or this servers connection sucks, or you've deliberatly dc'd (I hope!), if not the latter, then we have an issue. Please speak to the server admin about the lag/packet jumbling.")
            datatype = data[1]
            datapayload = data[2]
            if (datatype == 32):
                received32 = True
                print "got a password from user: " + self.Username
                message_in = Message2String(datapayload)
                self.password = message_in[message_in.find(')')+1:]
                print "password from user " + self.Username + ": " + "*" * 16 #(16 WAS ORIGINALLY PASSWORD LENGTH, BUT THAT COULD PROVE PROBLEMATIC IF IT'S A SHORT PASSWORD!)
                SendCommandBackward(self, "Polling YSFHQ to see if your password matches...\nThis CAN take some time. Please be patient.:")
                self.result = 'Null'
                thread.start_new_thread(LoginYSFHQ, (self, self.Username, self.password,))
                while str(self.result) == 'Null':
                    time.sleep(5)
                    if str(self.result) == 'Null':
                        SendCommandBackward(self, 'Still waiting...')
                del self.password ##FOR PROTECTION ONCE THIS PROGRAM BECOMES SEMI-OPEN SOURCE!
                #PLEASE DO THE RIGHT THING AND *NOT* HACK THIS PROGRAM TO GATHER PEOPLES PASSWORDS! THANKS!
                if not self.result:
                    SendCommandBackward(self, "Password or username not recognised! BOTH ARE CASE SENSITIVE. Please try again.")
                elif self.result:
                    SendCommandBackward(self, "Sucessfully logged in as: " + self.Username)
                    loggedin = True
                    del self.result
    if loggedin:
        User[self.Username].Info['FeedName'] = message_in[1:message_in.find(')')]
        print str(self.Username) + "'s FeedName:" + User[self.Username].Info['FeedName']
        if User[self.Username].Info["DisplayedName"] == self.Username:
            User[self.Username].Info["DisplayedName"] = User[self.Username].Info['FeedName']
        return True
    else:
        User[self.Username].Info['FeedName'] = self.Username
        return False

def Administrator_Script(self):
    loggedin = False
    if ServerInfo.AdminPass == "":
        SendCommandBackward(self, "Sucessfully logged in as Administrator: " + self.Username)
        SendCommandBackward(self, "Consider setting a Server Password to protect your server, otherwise any user could log on under your name and have admin power!")
        loggedin = True
        message_in = "(" + str(self.Username) + ")"
    else:
        SendCommandBackward(self, "Welcome to the Orb Login System!")
        SendCommandBackward(self, "You Are Attempting To Log In As Administrator: " + self.Username)
    while not loggedin:
        SendCommandBackward(self, "Please Enter The Server Admin Password To Continue:")
        received32 = False
        while not received32 and not self.closing:
            data = RecvPacket2Data(self)
            datalength = data[0]
            try:
                if datalength == -1:
                    SendCommandBackward(self, "The Internet Broke Your Shit! I Didn't Understand That... Try Again Please?")
                if datalength == -2:
                    SendCommandBackward(self, "It seems that your connection sucks, or this servers connection sucks, or you've deliberatly dc'd (I hope!), if not the latter, then we have an issue. Please speak to the server admin about the lag/packet jumbling.")
            except:
                if not self.closing:
                    self.sock.close()
                    self.closing = True
                    return False
            datatype = data[1]
            datapayload = data[2]
            if (datatype == 32):
                received32 = True
                print "got a password from user: " + self.Username
                message_in = Message2String(datapayload)
                self.password = message_in[message_in.find(')')+1:]
                print "password from user " + self.Username + ": " + "*" * 16 #(16 WAS ORIGINALLY PASSWORD LENGTH, BUT THAT COULD PROVE PROBLEMATIC IF IT'S A SHORT PASSWORD!)
                if self.password == ServerInfo.AdminPass:
                    self.result = True
                else:
                    self.result = False
                del self.password ##FOR PROTECTION ONCE THIS PROGRAM BECOMES SEMI-OPEN SOURCE!
                #PLEASE DO THE RIGHT THING AND *NOT* HACK THIS PROGRAM TO GATHER PEOPLES PASSWORDS! THANKS!
                if not self.result:
                    SendCommandBackward(self, "Password Incorrect. Please try again.")
                elif self.result:
                    SendCommandBackward(self, "Sucessfully logged in as: " + self.Username)
                    loggedin = True
                    del self.result
    if loggedin:
        User[self.Username].Info['FeedName'] = message_in[1:message_in.find(')')]
        print str(self.Username) + "'s FeedName:" + User[self.Username].Info['FeedName']
        if User[self.Username].Info["DisplayedName"] == self.Username:
            User[self.Username].Info["DisplayedName"] = User[self.Username].Info['FeedName']
        return True
    else:
        User[self.Username].Info['FeedName'] = self.Username
        return False 
import datetime
def UpdateOnlinePlayers(null):
    try:
        test = ServerInfo.UpdateOnlinePlayers
    except:
        ServerInfo.UpdateOnlinePlayers = False
    while True:
        try:
            test = last
        except:
            last = datetime.datetime.now()
        time.sleep(5)
        if ServerInfo.UpdateOnlinePlayers == True:
            if len(ServerInfo.UsersOnline) == 0:
                print "Still Listening For Clients... No-One Online..."
            ServerInfo.UpdateOnlinePlayers = False
        for username in ServerInfo.UsersOnline:
            try:
                #print User[username].Info["PlayTime"]
                User[username].Info["PlayTime"] += (datetime.datetime.now() - last)
                if User[username].Info["ClientID"].Flying:
                    try:
                        User[username].Info["FlightHours"] += (datetime.datetime.now() - last)
                    except:
                        print username, 'Flight Not Read Correcty?'
                        print User[username].Info["FlightHours"]
                WriteUserToDatabase(username)
                #print 'Updated', username, 'Playtime:', User[username].Info["PlayTime"]
            except:
                print username, 'Time Not Read Correcty?'
                print User[username].Info["PlayTime"]
                #User[username].Info["PlayTime"] = (datetime.datetime.now() - last)
        last = datetime.datetime.now()

def bin(n):
    if n > 255:
        return n
    i = 7
    m = ''
    while i >= 0:
        m += str(n/pow(2, i))
        n = n - (n/pow(2, i)*pow(2, i))
        i -= 1
    return m


###START THE PROGRAM:
print "Started YSFlight Proxy Service..."
Proxy = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
if (Settings.LocalTestMode):
        print "WARNING: PROXY SERVICE IS IN 'LOCALTESTMODE'"
        ProxyAddress = ('localhost',Settings.ProxyPort)
else:
        ProxyAddress = ('',Settings.ProxyPort) #We need to leave this string empty, otherwise it listens to LOCALHOST ONLY. 
try:
        Proxy.bind(ProxyAddress)
except:
        MasterClose("\n\nERROR! Orb cannot start on the port you requested (" + str(Settings.ProxyPort) + ").\nCheck that nothing else is running on the port then restart the server!", 30)
#print Proxy
#client[Clients] = Client(Proxy)
#print Proxy
print "Listening for clients on: " + str(Settings.ProxyPort) + "\n..."
UpdatePlayerDB = thread.start_new_thread(UpdateOnlinePlayers, ('',))
while True:
    ##try:
        try:
           Proxy.listen(1)
        except:
           Proxy.close();
           Proxy.listen(1);
        time.sleep(1)
        newclient = Proxy.accept()[0]
        client = thread.start_new_thread(Client, (newclient,))
        #print "Thread Spawned"
    ##except:
        #print "Thread Crash."
        ##pass;
        
