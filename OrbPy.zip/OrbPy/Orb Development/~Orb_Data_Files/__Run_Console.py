##RUN YSPS SERVER!

execfile("__Run.pyw")                    #This is normally Console Less, so we're just forcing the console open!
