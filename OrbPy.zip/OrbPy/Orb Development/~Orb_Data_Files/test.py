import sys

def AutoGrieferAnnounce():
    #
    #Get the AMMOUNT of players to parse.
    #
    ServerSend("/Players")
    try:
        PlayerListMessage = GetMessage("players online:")
        if PlayerListMessage == -1: #GetMessage failed to match a result
            return -1
    except:
        #print "Error: PlayerList not returning correctly. Investigate the AutoGrieferAnnounce module."
        print "Error in the Get Server Message Component of the AutoGrieferAnnouncer Module:"
        print sys.exc_info()
        return -1 #broken, ignore this part.

    try:
        PlayerCount = PlayerListMessage[PlayerListMessage.index("There are ")+len("There are "):PlayerListMessage.index(" players online")]
        #The above line is complex, allow me to explain:
            #get's the position of "there are" and " players online", and returns the string with those in between, which will be the count.
        PlayerCount = int(PlayerCount)
    except:
        PlayerCount = 0 #Give up, something went wrong, don't wanna break the bot!
        print "Error in the Player Count Attainer Component of the AutoGrieferAnnouncer Module:"
        print sys.exc_info()
        return -1 #broken, ignore this part

    #
    #Get all the players NAMES.
    #
    try:
        PlayersString = PlayerListMessage[PlayerListMessage.index("online: ")+len("online: "):]
        if PlayerCount > 30:
            for x in range(PlayerCount/30):
                ServerSend("/Players " + str(x*30))
                try:
                    PlayerListMessage = GetMessage("players online:")
                    if PlayerListMessage == -1: #GetMessage failed to match a result
                        return -1
                except:
                    #print "Error: PlayerList not returning correctly. Investigate the AutoGrieferAnnounce module."
                    return -1 #broken, ignore this part.
                PlayersString += PlayerListMessage[PlayerListMessage.index("online: ")+len("online: "):PlayerListMessage.index("Showing ")+len("Showing ")]
        PlayersString = PlayersString.replace("\n","") #Cleans the newlines.
        PlayersString = PlayersString.replace("\r","") #Cleans the newlines.
        PlayersArray = PlayersString.split(" ") #Breaks into an array.
    except:
        print "Error in the PlayerIsolation Component of the AutoGrieferAnnouncer Module:"
        print sys.exc_info()
        return -1 #broken, ignore this part

    #
    #Process Each Player
    #
    for player in PlayersArray:
        try:
            ServerSend("/Players " + str(x*30))
            PlayerInfo = GetMessage("Spent a total of") #most unlikely message for a player to replicate.
            Built = int(PlayerInfo[PlayerInfo.index("Built ")+len("Built "):PlayerInfo.index(" and deleted")])
            Deleted = int(PlayerInfo[PlayerInfo.index("and deleted ")+len("and deleted "):PlayerInfo.index(" blocks,")])

            #
            #Examine the player.
            #
            if Built + 500 <= Deleted or float(Deleted)/float(Built) > 1.2:
                ServerSend("/Staff Player " + player + "is a possible griefer! (Built: " + str(Built) + ", Deleted: " + str(Deleted) + ".)")
        except:
            pass #if the script breaks, then move on, no need to give a false positive. Let the admins do ther're job the hard way.
            print "Error in the Comparison Component of the AutoGrieferAnnouncer Module:"
            print sys.exc_info()
            #DO NOT RETURN. WE MIGHT BE ABLE TO PROCESS THE OTHER PLAYERS AT LEAST!

    return 0

def GetMessage(messagecontains):
    for x in range(3): #3 attempts or fail.
        messagein = getmess(server.socket)
        
        try:
            test = messagein.index(messagecontains)
            return messagein #we need to return the message, which will stop this for loop too.
        except:
            pass #keep trying.
    return -1
        


